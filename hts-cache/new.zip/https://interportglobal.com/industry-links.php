<!DOCTYPE html>
<html lang="en">

		
 
<head>
    <meta charset="utf-8" />
    <meta name="author" content="Interport Global Logistics" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="keywords" content="Interport Global Logistics" />
    <meta name="description" content="Interport Global Logistics" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;900&display=swap" rel="stylesheet">
    <title>Industry Links - Interport Global Logistics</title>
    <meta name="description" content="Interport Global Logistics - Total Logistics Solutions Provider">
    <meta name="keywords" content="logistics, cargo, solutions, addons, sea freight, air freight, rail freight, cargo insurance, container freight station, custom clearance, import export consolidation, nvocc, door to door delivery, iso flexi tanks, project logistics, heavy lift, break bulk, warehousing, our packing, transportation and distribution, rfid solutions, warehouse management, turnkey projects, logistic solutions, exhibition cargo, hazardous cargo, project cargo, ivrs phone track, airlines, bankers, india info, container specification sea, container specification air, hazmat definitions, shipping glossary, iata codes, usa port codes, print your bill of lading, industry links, inco terms, air shipment, sea shipment" />
    <meta property="og:description" content="Interport Global Logistics - Total Logistics Solutions Provider">
    <meta property="og:site_name" content="Interport Global Logistics">
    <meta property="og:title" content="Interport Global Logistics">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://interportglobal.com/new/">
    <meta property="og:image" content="https://interportglobal.com/new/img/logos/logo-old.png" />
    <meta property="og:image:secure_url" content="https://interportglobal.com/new/img/logos/logo-old.png" />
    <meta property="og:image:width" content="1800" />
    <meta property="og:image:height" content="945" />
    <meta property="og:image:alt" content="Interport Global Logistics" />
    <meta property="og:image:type" content="image/png" />
    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="Interport Global Logistics">
    <meta name="twitter:creator" content="Interport Global Logistics">
    <meta name="twitter:title" content="Interport Global Logistics">
    <meta name="twitter:description" content="Interport Global Logistics - Total Logistics Solutions Provider">
    <link rel="shortcut icon" href="img/logos/logo-old.png" />
    <link rel="apple-touch-icon" href="img/logos/logo-old.png" />
    <link rel="apple-touch-icon" sizes="72x72" href="img/logos/logo-old.png" />
    <link rel="apple-touch-icon" sizes="114x114" href="img/logos/logo-old.png" />
    <link rel="stylesheet" href="css/plugins.css">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="css/mystyle.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link href="css/new-responsive.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/f70dd43e17.js" crossorigin="anonymous"></script>
    <script type="text/javascript">
        function googleTranslateElementInit2() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                autoDisplay: false
            }, 'google_translate_element2');
        }
    </script>
    <script type="text/javascript"
        src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2">
    </script>
    <script type="text/javascript">
        eval(function (p, a, c, k, e, r) {
            e = function (c) {
                return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) :
                    c
                    .toString(36))
            };
            if (!''.replace(/^/, String)) {
                while (c--) r[e(c)] = k[c] || e(c);
                k = [function (e) {
                    return r[e]
                }];
                e = function () {
                    return '\\w+'
                };
                c = 1
            };
            while (c--)
                if (k[c]) p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]);
            return p
        }('6 7(a,b){n{4(2.9){3 c=2.9("o");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s(\'t\'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a==\'\')v;3 b=a.w(\'|\')[1];3 c;3 d=2.x(\'y\');z(3 i=0;i<d.5;i++)4(d[i].A==\'B-C-D\')c=d[i];4(2.j(\'k\')==E||2.j(\'k\').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,\'m\');7(c,\'m\')}}',
            43, 43,
            '||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500'
            .split('|'), 0, {}))
    </script>
    <script>
        (function (w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-M9TZHXX');
    </script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-179148496-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-179148496-1');
    </script>
    <script>
        ! function (f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function () {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '420989926550304');
        fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
            src="https://www.facebook.com/tr?id=420989926550304&ev=PageView&noscript=1" /></noscript>
</head>

<body>
    <div id="preloader"></div>
    <div class="main-wrapper ">
        <header class="header-style1 menu_area-light">
            <div class="navbar-default">
                <div class="top-search bg-secondary">
                    <div class="container-fluid px-lg-1-6 px-xl-2-5 px-xxl-2-9">
                        <form class="search-form" action="" method="GET" accept-charset="utf-8">
                            <div class="input-group">
                                <span class="input-group-addon cursor-pointer">
                                    <button class="search-form_submit fas fa-search text-white" type="submit"></button>
                                </span>
                                <input type="text" class="search-form_input form-control" name="s" autocomplete="off"
                                    placeholder="Type &amp; hit enter...">
                                <span class="input-group-addon close-search mt-1"><i class="fas fa-times"></i></span>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="container-fluid px-lg-1-6 px-xl-2-5 px-xxl-2-9">
                    <div class="row align-items-center">
                        <div class="col-12 col-lg-12 p-0 px-lg-2">
                            <div class="menu_area alt-font">
                                <nav class="navbar navbar-expand-lg navbar-light p-0">
                                    <div class="navbar-header navbar-header-custom">
                                        <a href="index.php" class="navbar-brand logochange">
                                            <img id="logo" class="home-logo" src="img/logos/logo-w.png" alt="logo" />
                                            <img id="logo" class="other-logo" src="img/logos/logo-b.png" alt="logo" />
                                        </a>
                                    </div>
                                    <div class="navbar-toggler bg-primary"></div>
                                    <ul class="navbar-nav" id="nav" style="display: none;">
                                        <li
                                            >
                                            <a href="https://interportglobal.com/index.php">Home</a></li>
                                        <li >
                                            <a href="about.php">About Us</a>
                                        </li>
                                        <li
                                            class="d-none d-lg-block d-xl-block 
                                            ">
                                            <a href="https://interportglobal.com/services.php">Services</a>
                                            <ul class="row megamenu">
                                                <li class="col-lg-4 col-sm-12">
                                                    <ul>
                                                        <li><a href="freight-forwarding.php">Freight Forwarding</a></li>
                                                        <li><a href="ocean-freight.php">Ocean Freight</a></li>
                                                        <li><a href="air-freight.php">Air Freight</a></li>
                                                        <li><a href="rail-freight.php">Rail Freight</a></li>
                                                        <li><a href="road-freight.php">Road Freight</a></li>
                                                        <li><a href="3pl-warehousing.php">3PL Warehousing</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <ul>
                                                        <li><a href="custom-brokerage.php">Custom Brokerage</a></li>
                                                        <li><a href="hazardous-cargo.php">Hazardous Cargo</a></li>
                                                        <li><a href="project-cargo.php">Project Cargo</a></li>
                                                        <li><a href="heavy-lift.php">Heavy Lift</a></li>
                                                        <li><a href="door-to-door-program.php">Door To Door
                                                                Program</a></li>
                                                        <li><a href="vessel-handling.php">Vessel Handling</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <ul >
                                                        <li><a href="turnkey-projects.php">Turnkey Projects</a></li>
                                                        <li><a href="iso-flexi-tanks.php">ISO Tanks / Flexi Tanks</a>
                                                        </li>
                                                        <li><a href="cargo-insurance.php">Cargo Insurance</a></li>
                                                        <li><a href="nvocc.php">NVOCC</a></li>
                                                        <li><a href="import-export-consolidation.php">Import / Export
                                                                Consolidation</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                        <li
                                            class="d-block d-lg-none d-xl-none 
                                            ">
                                            <a href="services.php">Services</a>
                                            <ul class="scrollable-list" >
                                                <li><a href="services.php">Services</a></li>
                                                <li><a href="freight-forwarding.php">Freight Forwarding</a></li>
                                                <li><a href="ocean-freight.php">Ocean Freight</a></li>
                                                <li><a href="air-freight.php">Air Freight</a></li>
                                                <li><a href="rail-freight.php">Rail Freight</a></li>
                                                <li><a href="road-freight.php">Road Freight</a></li>
                                                <li><a href="3pl-warehousing.php">3PL Warehousing</a>
                                                </li>
                                                
                                                <li><a href="custom-brokerage.php">Custom Brokerage</a></li>
                                                <li><a href="hazardous-cargo.php">Hazardous Cargo</a></li>
                                                <li><a href="project-cargo.php">Project Cargo</a></li>
                                                <li><a href="heavy-lift.php">Heavy Lift</a></li>
                                                <li><a href="door-to-door-program.php">Door To Door
                                                        Program</a></li>
                                                <li><a href="vessel-handling.php">Vessel Handling</a></li>
                                                <li><a href="turnkey-projects.php">Turnkey Projects</a></li>
                                                <li><a href="iso-flexi-tanks.php">ISO Tanks / Flexi Tanks</a>
                                                </li>
                                                
                                                <li><a href="cargo-insurance.php">Cargo Insurance</a></li>
                                                <li><a href="nvocc.php">NVOCC</a></li>
                                                <li><a href="import-export-consolidation.php">Import / Export
                                                        Consolidation</a></li>
                                            </ul>
                                        </li>
                                        
                                        <li
                                            class="active">
                                            <a href="javascript:void(0)">Resources</a>
                                            <ul class="row megamenu">

                                                <li class="col-lg-4 col-sm-12">
                                                    <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Other
                                                        Links</span>
                                                    <ul>
                                                        <li><a href="airlines.php">Airlines</a></li>
                                                        <li><a href="bankers.php">Bankers</a></li>
                                                        <li><a href="2023-holiday-list.php">2024 Holiday List</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Important
                                                        Info</span>
                                                    <ul  class="">
                                                    <!-- scrollable-list -->
                                                        <li><a href="india-info.php">India Info</a></li>
                                                        <li><a href="container-specification-sea.php">Container
                                                                Specification-Sea</a></li>
                                                        <li><a href="container-specification-air.php">Container
                                                                Specification-Air</a></li>
                                                        <li><a href="hazmat-definitions.php">Hazmat Definifitons</a>
                                                        </li>
                                                        <li><a href="shipping-glossary.php">Shipping Glossary</a></li>
                                                        <li><a href="iata-codes.php">IATA Codes</a></li>
                                                        <li><a href="usa-port-codes.php">USA Port Codes</a></li>
                                                        <li><a href="print-your-bill-of-lading.php">Print Your Bill Of
                                                                Lading</a></li>
                                                    </ul>
                                                </li>


                                                <li class="col-lg-4 col-sm-12">
                                                    <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Important
                                                        Links</span>
                                                    <ul>
                                                        <li><a href="industry-links.php">Industry Links</a></li>
                                                        <li><a href="inco-terms.php">INCO Terms</a></li>
                                                    </ul>
                                                </li>

                                              
                                            <li class="col-lg-4 col-sm-12">
                                                <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Payments</span>
                                            <ul>
                                                <!-- <li>
                                                   <a href="#">For India</a>     
                                                   <li> -->
                                                <li>
                                                    <a href="https://app.paycargo.com/shipandpay?region=US&vendorld=281793" target="_blank">For USA</a>
                                                </li>
                                            </ul>
                                        </li>   

                                            </ul>
                                        </li>
                                        <li >
                                            <a href="careers.php">Careers</a>
                                        </li>
                                        <li >
                                            <a href="network.php">Network</a>
                                        </li>
                                        <li 
                                            >
                                            <a href="contact.php">Contact</a>
                                            <ul class="">
                                            <!-- scroll-ul -->
                                                <li 
                                                    class="d-block d-lg-none  ">
                                                    <a href="contact.php">Contact</a>
                                                </li>
                                                <li >
                                                    <a href="enquiry-form.php">Enquiry Form</a>
                                                </li>
                                                <li >
                                                    <a href="feedback-form.php">Feedback Form</a>
                                                </li>
                                                <li >
                                                    <a href="air-shipment.php">Air Shipment Bookings</a>
                                                </li>
                                                <li >
                                                    <a href="sea-shipment.php">Sea Shipment Bookings</a>
                                                </li>
                                    
                                            </ul>
                                        </li>
                                 

                                        <li
                                            class=" d-block d-lg-none">
                                            <a href="get-a-quote.php">Get a Quote</a>
                                        </li>
                                        <li class="d-block d-lg-none">
                                            <a target="_blank"
                                                href="http://www.interportglobal.net/Logisys/customervisibility/login.aspx">Track
                                                your shipment</a>
                                        </li>
                                        <li class="d-block d-lg-none">
                                                <select class="language-dropdown" onchange="doGTranslate(this);">
                                                    <option value="">Select a language</option>
                                                    <option value="en|af">Af</option>
                                                    <option value="en|sq">sq</option>
                                                    <option value="en|am">am</option>
                                                    <option value="en|ar">ar</option>
                                                    <option value="en|hy">hy</option>
                                                    <option value="en|az">az</option>
                                                    <option value="en|eu">eu</option>
                                                    <option value="en|be">be</option>
                                                    <option value="en|bn">bn</option>
                                                    <option value="en|bs">bs</option>
                                                    <option value="en|bg">bg</option>
                                                    <option value="en|ca">ca</option>
                                                    <option value="en|ceb">ceb</option>
                                                    <option value="en|ny">ny</option>
                                                    <option value="en|zh-CN">zh-CN</option>
                                                    <option value="en|zh-TW">zh-TW</option>
                                                    <option value="en|co">co</option>
                                                    <option value="en|hr">hr</option>
                                                    <option value="en|cs">cs</option>
                                                    <option value="en|da">da</option>
                                                    <option value="en|nl">nl</option>
                                                    <option value="en|en">en</option>
                                                    <option value="en|eo">eo</option>
                                                    <option value="en|et">et</option>
                                                    <option value="en|tl">tl</option>
                                                    <option value="en|fi">fi</option>
                                                    <option value="en|fr">fr</option>
                                                    <option value="en|fy">fy</option>
                                                    <option value="en|gl">gl </option>
                                                    <option value="en|ka">ka </option>
                                                    <option value="en|de">de </option>
                                                    <option value="en|el">el </option>
                                                    <option value="en|gu">gu </option>
                                                    <option value="en|ht">ht</option>
                                                    <option value="en|ha">ha </option>
                                                    <option value="en|haw">haw</option>
                                                    <option value="en|iw">iw </option>
                                                    <option value="en|hi">hi </option>
                                                    <option value="en|hmn">hmn</option>
                                                    <option value="en|hu">hu</option>
                                                    <option value="en|is">is</option>
                                                    <option value="en|ig">ig </option>
                                                    <option value="en|id">id</option>
                                                    <option value="en|ga">ga </option>
                                                    <option value="en|it">it </option>
                                                    <option value="en|ja">ja </option>
                                                    <option value="en|jw">jw </option>
                                                    <option value="en|kn">kn </option>
                                                    <option value="en|kk">kk </option>
                                                    <option value="en|km">km </option>
                                                    <option value="en|ko">ko </option>
                                                    <option value="en|ku">ku </option>
                                                    <option value="en|ky">ky </option>
                                                    <option value="en|lo">lo </option>
                                                    <option value="en|la">la </option>
                                                    <option value="en|lv">lv </option>
                                                    <option value="en|lt">lt </option>
                                                    <option value="en|lb">lb </option>
                                                    <option value="en|mk">mk </option>
                                                    <option value="en|mg">mg </option>
                                                    <option value="en|ms">ms </option>
                                                    <option value="en|ml">ml </option>
                                                    <option value="en|mt">mt </option>
                                                    <option value="en|mi">mi </option>
                                                    <option value="en|mr">mr </option>
                                                    <option value="en|mn">mn </option>
                                                    <option value="en|my">my </option>
                                                    <option value="en|ne">ne </option>
                                                    <option value="en|no">no </option>
                                                    <option value="en|ps">ps </option>
                                                    <option value="en|fa">fa </option>
                                                    <option value="en|pl">pl </option>
                                                    <option value="en|pt">pt </option>
                                                    <option value="en|pa">pa </option>
                                                    <option value="en|ro">ro </option>
                                                    <option value="en|ru">ru </option>
                                                    <option value="en|sm">sm </option>
                                                    <option value="en|gd">gd </option>
                                                    <option value="en|sr">sr </option>
                                                    <option value="en|st">st </option>
                                                    <option value="en|sn">sn </option>
                                                    <option value="en|sd">sd </option>
                                                    <option value="en|si">si </option>
                                                    <option value="en|sk">sk </option>
                                                    <option value="en|sl">sl </option>
                                                    <option value="en|so">so </option>
                                                    <option value="en|es">es </option>
                                                    <option value="en|su">su </option>
                                                    <option value="en|sw">sw </option>
                                                    <option value="en|sv">sv </option>
                                                    <option value="en|tg">tg </option>
                                                    <option value="en|ta">ta </option>
                                                    <option value="en|te">te </option>
                                                    <option value="en|th">th </option>
                                                    <option value="en|tr">tr </option>
                                                    <option value="en|uk">uk </option>
                                                    <option value="en|ur">ur </option>
                                                    <option value="en|uz">uz </option>
                                                    <option value="en|vi">vi </option>
                                                    <option value="en|cy">cy </option>
                                                    <option value="en|xh">xh </option>
                                                    <option value="en|yi">yi </option>
                                                    <option value="en|yo">yo </option>
                                                    <option value="en|zu">zu </option>
                                                </select>
                                                <div id="google_translate_element2"></div>

                                        </li>
                                    </ul>
                                    <div class="attr-nav align-items-xl-center main-font">
                                        <ul>
                                            <li class="d-none d-xl-inline-block">
                                                <a target="_blank"
                                                    href="https://app.fieldproxy.com/public/proxy-f329b4dc-1384-4812-b392-d3278cb60ba1/igital_visibility/igtaltrack"
                                                    class="butn outline me-3">
                                                    <span>Track a shipment</span>
                                                </a>
                                            </li>
                                            <li class="d-none d-xl-inline-block">
                                                <a href="get-a-quote.php" class="butn primary">
                                                    <span>Get a Quote</span>
                                                </a>
                                            </li>
                                            <li class="d-none d-xl-inline-block">
                                                <select class="language-dropdown" onchange="doGTranslate(this);">
                                                    <option value="">en</option>
                                                    <option value="en|af">Af</option>
                                                    <option value="en|sq">sq</option>
                                                    <option value="en|am">am</option>
                                                    <option value="en|ar">ar</option>
                                                    <option value="en|hy">hy</option>
                                                    <option value="en|az">az</option>
                                                    <option value="en|eu">eu</option>
                                                    <option value="en|be">be</option>
                                                    <option value="en|bn">bn</option>
                                                    <option value="en|bs">bs</option>
                                                    <option value="en|bg">bg</option>
                                                    <option value="en|ca">ca</option>
                                                    <option value="en|ceb">ceb</option>
                                                    <option value="en|ny">ny</option>
                                                    <option value="en|zh-CN">zh-CN</option>
                                                    <option value="en|zh-TW">zh-TW</option>
                                                    <option value="en|co">co</option>
                                                    <option value="en|hr">hr</option>
                                                    <option value="en|cs">cs</option>
                                                    <option value="en|da">da</option>
                                                    <option value="en|nl">nl</option>
                                                    <option value="en|en">en</option>
                                                    <option value="en|eo">eo</option>
                                                    <option value="en|et">et</option>
                                                    <option value="en|tl">tl</option>
                                                    <option value="en|fi">fi</option>
                                                    <option value="en|fr">fr</option>
                                                    <option value="en|fy">fy</option>
                                                    <option value="en|gl">gl </option>
                                                    <option value="en|ka">ka </option>
                                                    <option value="en|de">de </option>
                                                    <option value="en|el">el </option>
                                                    <option value="en|gu">gu </option>
                                                    <option value="en|ht">ht</option>
                                                    <option value="en|ha">ha </option>
                                                    <option value="en|haw">haw</option>
                                                    <option value="en|iw">iw </option>
                                                    <option value="en|hi">hi </option>
                                                    <option value="en|hmn">hmn</option>
                                                    <option value="en|hu">hu</option>
                                                    <option value="en|is">is</option>
                                                    <option value="en|ig">ig </option>
                                                    <option value="en|id">id</option>
                                                    <option value="en|ga">ga </option>
                                                    <option value="en|it">it </option>
                                                    <option value="en|ja">ja </option>
                                                    <option value="en|jw">jw </option>
                                                    <option value="en|kn">kn </option>
                                                    <option value="en|kk">kk </option>
                                                    <option value="en|km">km </option>
                                                    <option value="en|ko">ko </option>
                                                    <option value="en|ku">ku </option>
                                                    <option value="en|ky">ky </option>
                                                    <option value="en|lo">lo </option>
                                                    <option value="en|la">la </option>
                                                    <option value="en|lv">lv </option>
                                                    <option value="en|lt">lt </option>
                                                    <option value="en|lb">lb </option>
                                                    <option value="en|mk">mk </option>
                                                    <option value="en|mg">mg </option>
                                                    <option value="en|ms">ms </option>
                                                    <option value="en|ml">ml </option>
                                                    <option value="en|mt">mt </option>
                                                    <option value="en|mi">mi </option>
                                                    <option value="en|mr">mr </option>
                                                    <option value="en|mn">mn </option>
                                                    <option value="en|my">my </option>
                                                    <option value="en|ne">ne </option>
                                                    <option value="en|no">no </option>
                                                    <option value="en|ps">ps </option>
                                                    <option value="en|fa">fa </option>
                                                    <option value="en|pl">pl </option>
                                                    <option value="en|pt">pt </option>
                                                    <option value="en|pa">pa </option>
                                                    <option value="en|ro">ro </option>
                                                    <option value="en|ru">ru </option>
                                                    <option value="en|sm">sm </option>
                                                    <option value="en|gd">gd </option>
                                                    <option value="en|sr">sr </option>
                                                    <option value="en|st">st </option>
                                                    <option value="en|sn">sn </option>
                                                    <option value="en|sd">sd </option>
                                                    <option value="en|si">si </option>
                                                    <option value="en|sk">sk </option>
                                                    <option value="en|sl">sl </option>
                                                    <option value="en|so">so </option>
                                                    <option value="en|es">es </option>
                                                    <option value="en|su">su </option>
                                                    <option value="en|sw">sw </option>
                                                    <option value="en|sv">sv </option>
                                                    <option value="en|tg">tg </option>
                                                    <option value="en|ta">ta </option>
                                                    <option value="en|te">te </option>
                                                    <option value="en|th">th </option>
                                                    <option value="en|tr">tr </option>
                                                    <option value="en|uk">uk </option>
                                                    <option value="en|ur">ur </option>
                                                    <option value="en|uz">uz </option>
                                                    <option value="en|vi">vi </option>
                                                    <option value="en|cy">cy </option>
                                                    <option value="en|xh">xh </option>
                                                    <option value="en|yi">yi </option>
                                                    <option value="en|yo">yo </option>
                                                    <option value="en|zu">zu </option>
                                                </select>
                                                <div id="google_translate_element2"></div>
                                            </li>
                                        </ul>
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <div class="modal fade" id="getaquote_modal" tabindex="-1" aria-labelledby="centeredLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title" id="centeredLabel">Get a Quote</h3>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <form class="row g-3">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_name" placeholder="Name">
                                            <label for="quote_name">Name</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-1">
                                            <input type="email" class="form-control" id="quote_email"
                                                placeholder="Email">
                                            <label for="quote_email">Email</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_phone"
                                                placeholder="Phone">
                                            <label for="quote_phone">Phone</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected>Freight Type</option>
                                                <option value="1">Freight Type 1</option>
                                                <option value="2">Freight Type 2</option>
                                                <option value="3">Freight Type 3</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_city_of_departure"
                                                placeholder="City of Departure">
                                            <label for="quote_city_of_departure">City of Departure</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_delivery_city"
                                                placeholder="Delivery City">
                                            <label for="quote_delivery_city">Delivery City</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected>Incoterms</option>
                                                <option value="1">Incoterms 1</option>
                                                <option value="2">Incoterms 2</option>
                                                <option value="3">Incoterms 3</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_weight"
                                                placeholder="Weight (kg)">
                                            <label for="quote_weight">Weight (kg)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_height"
                                                placeholder="Height (cm)">
                                            <label for="quote_height">Height (cm)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_width"
                                                placeholder="Width (cm)">
                                            <label for="quote_width">Width (cm)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_length"
                                                placeholder="Length (cm)">
                                            <label for="quote_length">Length (cm)</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="quote_fragile">
                                            <label class="form-check-label" for="quote_fragile">
                                                Fragile
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="quote_express_delivery">
                                            <label class="form-check-label" for="quote_express_delivery">
                                                Express Delivery
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="quote_insurance">
                                            <label class="form-check-label" for="quote_insurance">
                                                Insurance
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="quote_packaging">
                                            <label class="form-check-label" for="quote_packaging">
                                                Packaging
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>
                    <div class="modal-footer justify-content-center">
                        <button type="button" class="butn primary">Save</button>
                    </div>
                </div>
            </div>
        </div>
<section class="page-title-section main-title-section bg-light">
    <div class="container title-container">
        <div class="row">
            <div class="col-md-12">
                <ul class="wow fadeInUp breadcrump-list" data-wow-delay="400ms">
                    <li><a href="index.php">Home</a></li>
                    <li><a>Resources</a></li>
                    <li>Industry Links</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title mb-3 mt-4">
                    <h3 class="h5 mb-3">General 3rd party information</h3>
                </div>
            </div>
            <div class="col-md-6">


                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">
                    <li><a href="#industry_links_down">Important Links</a></li>
                    <li><a href="#dictionary_of_shipping">Dictionary of Shipping / Logistics Terms</a></li>
                    <li><a href="#customs_houses">Customs Houses of India</a></li>
                    <li><a href="#india_links">India Links</a></li>
                    <li><a href="#insurance_companies">Insurance Companies</a></li>
                    <li>World Links</li>
                    <li>Portals</li>
                    <li><a href="#news_knowledge">News, Knowledge &amp; Information on Shipping, Transportation &amp;
                            Logistics</a></li>
                </ul>

            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">
                    <li><a href="#government_security">Government, Security, Statutory, Organizations &amp;
                            Associations</a></li>
                    <li><a href="#international_links">International Links</a></li>
                    <li><a href="#banking_financial">Banking, Financial and Insurance</a></li>
                    <li>State Bank Of India & Associates</li>
                    <li>Financial Institutions</li>
                    <li>Securities And Exchanges</li>
                    <li>Port Trusts Of India</li>
                    <li>Valuable Information</li>

                </ul>

            </div>

            <div class="col-md-12" id="news_knowledge">
                <div class="section-title mb-3 mt-4">
                    <h3 class="h5 mb-3">News, knowledge & information on shipping, transportation and logistics</h3>
                </div>
            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">
                    <li><a class="main-txt" href="http://www.joc.com" target="_blank">Journal of Commerce</a></li>
                    <li><a class="main-txt" href="http://www.maritime.com" target="_blank"> Maritime.com latest news
                            from WN network</a></li>
                    <li><a class="main-txt" href="http://www.lloydslist.com" target="_blank">Lloyds List</a></li>
                    <li><a class="main-txt" href="http://www.ci-online.co.uk" target="_blank">Containerization
                            International</a>
                        << /li> <li><a class="main-txt" href="http://www.americanshipper.com" target="_blank"> American
                                Shipper</a>
                    </li>
                    <li><a class="main-txt" href="http://www.cargosystems.net/freightpubs/cs/index.htm"
                            target="_blank">Port and cargo industry intelligence</a></li>
                    <li><a class="main-txt" href="http://www.containerhandbuch.de" target="_blank">Container Handbook
                            &#8211; cargo loss prevention information</a></li>
                </ul>

            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">
                    <li><a class="main-txt" href="http://www.exim-india.com" target="_parent">EXIM India</a></li>
                    <li><a class="main-txt" href="http://www.fairplay.co.uk" target="_blank"> Fairplay</a></li>
                    <li><a class="main-txt" href="http://business-times.asia1.com.sg/shippingtimes/0,4565,,00.html"
                            target="_parent">The Business Times &#8211; Shipping News</a></li>
                    <li><a class="main-txt" href="http://www.main-txtdleastlogistics.com/index.asp" target="_blank">
                            main-txtdle East Logistics</a></li>
                    <li><a class="main-txt" href="http://www.ipa.nic.in" target="_blank"> Indian Ports Association</a>
                    </li>
                    <li>Bolero</li>
                    <li><a class="main-txt" href="http://www.bolero.net" target="_blank">Bolero</a></li>
                </ul>

            </div>

            <div class="col-md-12" id="government_security">
                <div class="section-title mb-3 mt-4">
                    <h3 class="h5 mb-3">Government, security, statutory, organizations and associations</h3>
                </div>
            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">
                    <li><a class="main-txt" href="http://www.aesdirect.gov" target="_blank">Automated Export System
                            (AES)</a></li>
                    <li><a class="main-txt" href="http://www.fmc.gov" target="_blank">Federal Maritime Commission</a>
                    </li>
                    <li><a class="main-txt" href="http://www.iata.org/index.htm" target="_blank">International Air
                            Transport Association (IATA)</a></li>
                    <li><a class="main-txt" href="http://www.wcoomd.org/home.htm" target="_blank">World Customs
                            Organization</a></li>
                    <li><a class="main-txt" href="http://www.iccwbo.org" target="_blank">International Chamber of
                            Commerce</a></li>
                </ul>

            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">
                    <li><a class="main-txt" href="http://www.iccwbo.org/incoterms/preambles.asp"
                            target="_blank">INCOTERMS</a></li>
                    <li><a class="main-txt" href="http://www.imo.org/index.htm" target="_blank">International Maritime
                            Organization</a></li>
                    <li><a class="main-txt" href="http://www.bimco.org" target="_blank">BIMCO</a></li>
                    <li><a class="main-txt" href="http://www.bic-code.org/html-gb/homepage.html" target="_blank">Bureau
                            International de Containers</a></li>
                </ul>

            </div>

            <div class="col-md-12" id="international_links">
                <div class="section-title mb-3 mt-4">
                    <h3 class="h5 mb-3">International links</h3>
                </div>
            </div>

            <div class="col-md-6">
                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">
                    <li><a href="http://www.fidi.org/" target="_blank"> Federation of International Moving Companies</a>
                    </li>
                    <li><a href="http://www.iata.org/index.htm" target="_blank"> International Air Transport Association
                            (IATA)</a></li>
                    <li><a href="http://www.icao.int/" target="_blank"> International Civil Aviation Organization
                            (ICAO)</a></li>
                    <li><a href="http://www.iecc.ch/" target="_blank"> International Express Carriers Conference
                            (IECC)</a></li>
                    <li><a href="http://www.fiata.com/" target="_blank"> International Federation of Freight Forwarders
                            Associations</a></li>
                </ul>

            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">
                    <li><a href="http://www.imo.org/" target="_blank"> International Maritime Organization</a></li>
                    <li><a href="http://www.iru.org/" target="_blank"> International Road Transport Union</a></li>
                    <li><a href="http://www.wcoomd.org/" target="_blank"> World Customs Organisation </a></li>
                    <li><a href="http://www.ports.com/" target="_blank"> World Ports</a></li>
                </ul>

            </div>

            <div class="col-md-12" id="banking_financial">
                <div class="section-title mb-3 mt-4">
                    <h3 class="h5 mb-3">Banking, financial & insurance</h3>
                </div>
            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">
                    <li><a href="http://www.allahabadbank.com/" target="_blank">Allahabad Bank</a></li>
                    <li><a href="http://www.andhrabank-india.com/" target="_blank"> Andhra Bank</a></li>
                    <li><a href="http://www.bankofbaroda.com/" target="_blank"> Bank of Baroda </a></li>
                    <li><a href="http://www.bankofindia.com/" target="_blank"> Bank of India </a></li>
                    <li><a href="http://www.maharashtrabank.com/" target="_blank"> Bank of Maharashtra</a></li>
                </ul>

            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a href="http://www.canbankindia.com/" target="_blank"> Canara Bank</a></li>
                    <li><a href="http://www.corpbank.com/" target="_blank"> Corporation Bank </a></li>
                    <li><a href="http://www.denabank.com/" target="_blank">Dena Bank </a></li>
                    <li><a href="http://www.indian-bank.com/" target="_blank"> Indian Bank</a></li>
                    <li><a href="http://www.iob.com/" target="_blank"> Indian Overseas Bank </a></li>
                </ul>

            </div>

            <div class="col-md-12" id="industry_links_down">
                <div class="section-title mb-3 mt-4">
                    <h3 class="h5 mb-3">Important links
                    </h3>
                </div>
            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a class="main-txt" href="http://www.bendresfarm.com/" target="_blank">Bendres Farm</a></li>
                    <li><a class="main-txt" href="http://www.export.gov/exportbasics/ticredirect.asp"
                            target="_blank">HS/Schedule B Numbers</a></li>
                    <li><a class="main-txt" href="http://www.bis.doc.gov/complianceandenforcement/index.htm"
                            target="_blank">Export Compliance and Enforcement</a></li>
                    <li><a class="main-txt" href="https://www.epls.gov/" target="_blank">Excluded Parties List</a></li>
                    <li><a class="main-txt" href="http://www.etfinancial.com/export_glossary.htm" target="_blank">Export
                            Glossary</a></li>
                    <li><a class="main-txt" href="http://www.projectstoday.com/" target="_blank">Projects Today</a></li>
                    <li><a class="main-txt" href="http://www.customs.ustreas.gov/xp/cgov/home.xml" target="_blank">US
                            Customs</a></li>
                    <li><a class="main-txt" href="http://www.aphis.usda.gov/404.shtml" target="_blank">Wood Packing
                            Material</a></li>
                    <li><a class="main-txt" href="http://www.bis.doc.gov/complianceandenforcement/liststocheck.htm"
                            target="_blank">Denied Parties List</a></li>
                    <li><a class="main-txt" href="http://www.commerce.gov/" target="_blank">US Department of
                            Commerce</a>
                    <li>
                    <li><a href="http://www.fibre2fashion.com/texterms/incoterms/incotermsglossary1.htm"
                            target="_blank">Trade Terms</a></li>
                    <li><a class="main-txt" href="http://www.accmumbai.gov.in/" target="_blank"> Air Cargo Mumbai</a>
                    </li>
                    <li><a class="main-txt" href="http://www.cbec.gov.in/" target="_blank"> Central Board of Excise
                            &amp; Customs</a></li>
                </ul>

            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a class="main-txt" href="http://www.fieo.com/cwc" target="_blank">Central Warehousing
                            Corporation</a></li>
                    <li><a class="main-txt" href="http://www.concorindia.com/" target="_blank">Container Corporation of
                            India</a></li>
                    <li><a class="main-txt" href="http://dgft.delhi.nic.in/" target="_blank">Director General of Foreign
                            Trade</a></li>
                    <li><a class="main-txt" href="http://www.dov.gov.in/" target="_blank">Directorate of Valuation</a>
                    </li>
                    <li><a class="main-txt" href="http://dgshipping.nic.in/" target="_blank">Director General of
                            Shipping</a></li>
                    <li><a class="main-txt" href="http://www.finmin.nic.in/" target="_blank">Finance Ministry</a></li>
                    <li><a class="main-txt" href="http://www.ieport.com/" target="_blank">Important Industry Website</a>
                    </li>
                    <li><a class="main-txt" href="http://www.exim-india.com/" target="_blank">Industry Newspaper</a>
                    </li>
                    <li><a class="main-txt" href="http://www.iomou.org/" target="_blank">Indian Ocean Memorandum of
                            Understanding on port state control</a></li>
                    <li><a class="main-txt" href="http://www.nipmchennai.com/" target="_blank">National Institute of
                            Port Management</a></li>
                    <li><a class="main-txt" href="http://shipping.nic.in/" target="_blank">Ministry of Shipping</a></li>
                    <li><a class="main-txt" href="http://www.merical.ac.in/" target="_blank">Marine Engineering and
                            Research Institute</a></li>

                </ul>

            </div>

            <div class="col-md-12" id="dictionary_of_shipping">
                <div class="section-title mb-3 mt-4">
                    <h3 class="h5 mb-3">Dictionary of shipping / logistics terms
                    </h3>
                </div>
            </div>

            <div class="col-md-12">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a class="main-txt" href="http://www.logisticsworld.com/logistics/glossary.htm"
                            target="_blank">ww virtual library &#8211; Logistics</a></li>
                    <li><a class="main-txt" href="http://www.maerskline.com/link/?page=brochure&amp;path=/glossary/a"
                            target="_blank"> English Shipping Glossary</a></li>
                    <li><a class="main-txt"
                            href="http://www.canadiancontent.net/dir/Top/Reference/Dictionaries/By_Subject/Business/Logistics"
                            target="_blank"> Explore Logistics</a></li>

                </ul>

            </div>

            <div class="col-md-12" id="customs_houses">
                <div class="section-title mb-3 mt-4">
                    <h3 class="h5 mb-3">Customs houses of india
                    </h3>
                </div>
            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a class="main-txt" href="http://ori.nic.in/cenexbbsr/" target="_blank"> Bhuvaneshwar Customs
                        </a></li>
                    <li><a class="main-txt" href="http://www.cochincustoms.nic.in/" target="_blank">Bangalore Customs
                        </a></li>
                    <li><a class="main-txt" href="http://www.chennaicustoms.org/" target="_blank"> Chennai Customs</a>
                    </li>
                    <li><a class="main-txt" href="http://www.cochincustoms.nic.in/" target="_blank">Cochin Customs</a>
                    </li>

                </ul>

            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a class="main-txt" href="http://www.kolkatacustoms.com/" target="_blank"> Kolkata Customs</a>
                    </li>
                    <li><a class="main-txt" href="http://mangalorecustoms.kar.nic.in/" target="_blank"> Mangalore
                            Customs</a></li>
                    <li><a class="main-txt" href="http://www.mumbaicustoms.gov.in/" target="_blank"> Mumbai Customs</a>
                    </li>
                    <li><a class="main-txt" href="http://www.jawaharcustoms.gov.in/" target="_blank"> Navi Mumbai
                            Customs</a></li>

                </ul>

            </div>

            <div class="col-md-12" id="india_links">
                <div class="section-title mb-3 mt-4">
                    <h3 class="h5 mb-3">India links
                    </h3>
                </div>
            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a href="http://www.aepcindia.com/" target="_blank"> Apparel Export Promotion Council</a></li>
                    <li><a href="http://indiabudget.nic.in/" target="_blank"> Budget of India </a></li>
                    <li><a href="http://bis.org.in" target="_blank"> Bureau of Indian Standard (BIS)</a></li>
                    <li><a href="http://www.ciae.org/index.asp" target="_blank"> Confederation of Indian Apparel
                            Exporters </a></li>
                    <li><a href="http://www.education.nic.in/htmlweb/copyright.htm" target="_blank"> Copyright Law</a>
                    </li>
                    <li><a href="http://www.ciionline.org/" target="_blank"> Confederation of Indian Industry </a></li>
                    <li><a href="http://www.dipp.nic.in/" target="_blank"> Department of Industrial Policy &amp;
                            Promotion</a></li>
                    <li><a href="http://siadipp.nic.in/publicat/ip/ipact01.htm" target="_blank"> Development and
                            Regulation Act, 1951</a></li>
                    <li><a href="http://districts.nic.in/" target="_blank"> Districts of India</a></li>
                    <li><a href="http://www.fieo.com/" target="_blank"> Federation of Indian Exporters Organisation </a>
                    </li>
                    <li><a href="http://www.fema.rbi.org.in/" target="_blank"> FEMA Regulation</a></li>

                </ul>

            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a href="http://indianimage.nic.in/" target="_blank"> Govt. of India </a></li>
                    <li><a href="http://goidirectory.nic.in/" target="_blank"> Govt. of India Directory </a></li>
                    <li><a href="http://www.education.nic.in/htmlweb/copyright.htm" target="_blank"> Income Tax Dept
                        </a></li>
                    <li><a href="http://www.imcnet.org/v2/index.asp" target="_blank"> Indian Merchant’s Chamber</a></li>
                    <li><a href="http://www.indiapost.org/" target="_blank"> Indian Postal Department</a></li>
                    <li><a href="http://www.imd.ernet.in/main_new.htm" target="_blank"> Indian Weather Bureau</a></li>
                    <li><a href="http://home.nic.in/" target="_blank"> National Information Centre </a></li>
                    <li><a href="http://www.patentoffice.nic.in/index.htm" target="_blank"> Patent Office </a></li>
                    <li><a href="http://ssi.nic.in/" target="_blank"> Small Scale Industry</a></li>
                    <li><a href="http://www.indiapost.org/_Track/Track.html" target="_blank">Speed Post Tracking</a>
                    </li>
                    <li><a href="http://fcamin.nic.in/wm_ind.htm" target="_blank"> Weights and Measures Bureau </a></li>

                </ul>

            </div>

            <div class="col-md-12" id="insurance_companies">
                <div class="section-title mb-3 mt-4">
                    <h3 class="h5 mb-3">Insurance companies
                    </h3>
                </div>
            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a href="http://aicofindia.nic.in/" target="_blank"> Agriculture Insurance Company of India
                            Limited </a></li>
                    <li><a href="http://esic.nic.in/" target="_blank"> Employees’ State Insurance Corporation (ESIC)</a>
                    </li>
                    <li><a href="http://www.ecgcindia.com/" target="_blank"> Export Credit Guarantee Corporation of
                            India Limited (ECGC)</a></li>
                    <li><a href="http://www.irdaindia.org/" target="_blank"> Insurance Regulatory and Development
                            Authority</a></li>

                </ul>

            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a href="http://www.licindia.com/" target="_blank"> Life Insurance Corporation of India (LIC)
                        </a></li>
                    <li><a href="http://www.nationalinsuranceindia.com/" target="_blank"> National Insurance Company
                            Limited (NICL)</a></li>
                    <li><a href="http://orientalinsurance.nic.in/" target="_blank"> Oriental Insurance Company Limited
                            (OICL)</a></li>

                </ul>

            </div>

            <div class="col-md-12">
                <div class="section-title mb-3 mt-4">
                    <h3 class="h5 mb-3">World links
                    </h3>
                </div>
            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a href="http://www.apecsec.org.sg/" target="_blank">Asia Pacific Economic Co-operation
                            (APEC)</a></li>
                    <li><a href="http://www.wcoasiapacific.org/" target="_blank">Asia Pacific Region</a></li>
                    <li><a href="http://www.adbindia.org" target="_blank">Asian Development Bank (ADB)</a></li>
                    <li><a href="http://www.aseansec.org/home.htm" target="_blank">Association of Southeast Asian
                            Nations (ASEAN)</a></li>
                    <li><a href="http://europe.eu.int/" target="_blank">EU European Union</a></li>
                    <li><a href="http://www.tiaca.org/" target="_blank">International Air Cargo Association</a></li>
                    <li><a href="http://www.iccwbo.org/" target="_blank">International Chamber of Commerce (ICC)</a>
                    </li>
                    <li><a href="http://www.ilo.org/" target="_blank">International Labor Organization</a></li>
                    <li><a href="http://www.imf.org/" target="_blank">International Monetary Fund (IMF)</a></li>
                    <li><a href="http://www.immta.org/index0.html" target="_blank">International Multimodal Transport
                            Association</a></li>
                    <li><a href="http://www.iso.ch/" target="_blank">International Organization for Standardization</a>
                    </li>
                    <li><a href="http://www.itf.org.uk/" target="_blank">International Transport Workers&#8217;
                            Federation</a></li>
                </ul>

            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a href="http://www.oecd.org/" target="_blank">Organization for Economic Co-operation and
                            Development (OECD)</a></li>
                    <li><a href="http://www.opec.org/homepage/frame.htm" target="_blank">Organization of the Petroleum
                            Exporting Companies (OPEC)</a></li>
                    <li><a href="http://www.unctad.org/" target="_blank">UN Conference on Trade and Development</a></li>
                    <li><a href="http://www.undp.org/" target="_blank">UN Development Program</a></li>
                    <li><a href="http://www.un.org/ecosocdev/" target="_blank">UN Economic and Social Council</a></li>
                    <li><a href="http://www.uncitral.org/" target="_blank">United Nations Commission on International
                            Trade Law (UNCIT)</a></li>
                    <li><a href="http://www.unctad.org/" target="_blank">United Nations Conference on Trade and
                            Development (UNCTAD)</a></li>
                    <li><a href="http://www.upu.int/" target="_blank">Universal Postal Union (UPU)</a></li>
                    <li><a href="http://www.worldbank.org/" target="_blank">World Bank</a></li>
                    <li><a href="http://www.who.ch/" target="_blank">World Health Organization</a></li>
                    <li><a href="http://www.wto.org/" target="_blank">World Trade Organization</a></li>


                </ul>

            </div>

            <div class="col-md-12">
                <div class="section-title mb-3 mt-4">
                    <h3 class="h5 mb-3">Portals
                    </h3>
                </div>
            </div>

            <div class="col-md-12">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">
                    <li><a href="http://www.inttra.com/home/home.aspx" target="_blank">INTTRA</a></li>
                    <li><a href="http://www.freightnet.com" target="_blank">Freight net</a></li>




                </ul>

            </div>

            <div class="col-md-12">
                <div class="section-title mb-3 mt-4">
                    <h3 class="h5 mb-3">Securities & exchanges
                    </h3>
                </div>
            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a href="http://www.iseindia.com/" target="_blank">Inter-connected Stock Exchange of India
                            Limited (ISE)</a></li>
                    <li><a href="http://www.nsdl.co.in/" target="_blank">National Securities Depository Limited
                            (NSDL)</a></li>
                    <li><a href="http://www.nse-india.com/" target="_blank">National Stock Exchange (NSE), India</a>
                    </li>
                    <li><a href="http://www.otcindia.com/" target="_blank">Over The Counter Stock Exchange</a></li>




                </ul>

            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">




                    <li><a href="http://www.sebi.gov.in/" target="_blank">Securities and Exchange Board of India
                            (SEBI)</a></li>
                    <li><a href="http://www.cse-india.com/" target="_blank">Stock Exchange, Kolkata</a></li>
                    <li><a href="http://www.bseindia.com/" target="_blank">Stock Exchange, Mumbai (BSE)</a></li>
                    <li><a href="http://www.punestockexchange.com/" target="_blank">Stock Exchange, Pune</a></li>


                </ul>

            </div>

            <div class="col-md-12">
                <div class="section-title mb-3 mt-4">
                    <h3 class="h5 mb-3">Port trust of india
                    </h3>
                </div>
            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a href="http://www.gatewayterminals.com/" target="_blank">GTI</a></li>
                    <li><a href="http://www.mumbaiporttrust.com/" target="_blank">Mumbai Port Trust</a></li>
                    <li><a href="http://www.waterservicesindia.com/client9.htm/&quot; name=&quot;C163"
                            target="_blank">Mundra Port (MICT)</a></li>
                    <li><a href="http://www.mundraport.com" target="_blank">Mundra Port ( MPSEZ )</a></li>
                    <li><a href="&quot;http://www.nsict.co.in/&quot; name=&quot;C166&quot;" target="_blank">NSICT</a>
                    </li>
                    <li><a href="http://www.portofcalcutta.com/" target="_blank">Kolkata Port Trust</a></li>
                    <li><a href="http://www.chennaiporttrust.com/" target="_blank">Chennai Port Trust</a></li>
                    <li><a href="http://www.cochinport.com/" target="_blank">Cochin Port Trust</a></li>

                </ul>

            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a href="http://www.mptgoa.com/" target="_blank">Goa Port Trust (Mormugao)</a></li>
                    <li><a href="http://www.jnport.com/" target="_blank">Jawaharlal Nehru Port Trust</a></li>
                    <li><a href="http://www.kandlaport.com/" target="_blank">Kandla Port Trust</a></li>
                    <li><a href="http://www.paradipport.com/" target="_blank">Paradip Port Trust</a></li>
                    <li><a href="http://www.pipavav.com/" target="_blank">Pipavav Port Trust</a></li>
                    <li><a href="http://www.tuticorinport.com/index.asp" target="_blank">Tuticorin Port Trust</a></li>
                    <li><a href="http://www.vizagport.com/home.htm" target="_blank">Vizag Port Trust</a></li>
                    <li><a href="http://ports.com/" target="_blank">Ports</a></li>


                </ul>

            </div>

            <div class="col-md-12">
                <div class="section-title mb-3 mt-4">
                    <h3 class="h5 mb-3">Valuable information
                    </h3>
                </div>
            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a href="http://www.xe.com/ucc/full.shtml" target="_blank">Currency Converter</a></li>
                    <li><a href="http://dictionary.reference.com&quot;" target="_blank">Dictionary / Thesaurus</a></li>
                    <li><a href="http://www.fibre2fashion.com/TEXTERMS/EXIM/exim_terms1.htm" target="_blank">EXIM
                            Terms</a></li>
                    <li><a href="http://www.infoplease.com/" target="_blank">General Knowledge</a></li>
                    <li><a href="http://www.itds.treas.gov/incoterms.html" target="_blank">Incoterms</a></li>
                    <li><a href="http://www.itds.treas.gov/glossaryfrm.html" target="_blank">International Trade
                            Terms</a></li>


                </ul>

            </div>

            <div class="col-md-6">

                <ul class="list-style1 ps-0 wow fadeIn" data-wow-duration="2s"
                    style="visibility: visible; animation-duration: 2s; animation-name: fadeIn;">


                    <li><a href="http://www.questia.com/" target="_blank">Questia</a></li>
                    <li><a href="http://www.alfa.com/alf/msds_search.htm" target="_blank">Search MSDS</a></li>
                    <li><a href="http://www.staralliance.com/en/services/visa-and-health/" target="_blank">Visa and
                            Health</a></li>
                    <li><a href="http://www.timeanddate.com/worldclock/full.html" target="_blank">World Time Zones</a>
                    </li>
                    <li><a href="http://www.bbc.co.uk/weather/world/" target="_blank">World Weather</a></li>
                    <li><a href="http://www.jours-feries.com/index.php3?id_langue=2" target="_blank">World Bank
                            Holidays</a></li>


                </ul>

            </div>
        </div>
    </div>
</section>

<section class="p-0 mb-n10 bg-transparent cta-overlay mt-1">
    <div class="row">
        <div class="col-lg-1 col-xl-3">
        </div>
        <div class="col-lg-11 col-xl-9">
            <div class="px-1-9 px-sm-6 px-lg-9 py-5 py-sm-8 z-index-3 bg-primary contact-block half-border-radius">
                <div class="row align-items-center position-relative z-index-3">
                    <div class="col-lg-7 col-xxl-7 mb-lg-0">
                        <h3 class="text-white mb-0">Let's make your supply chain easy
                        </h3>
                    </div>
                    <div class="col-lg-5 col-xxl-5 mt-3 text-lg-end">
                        <h5 class="text-white mb-3">If you have any questions.</h5>
                        <a href="contact.php" class="butn transparent"><span>Get In Touch</span></a>
                    </div>
                </div>
                <img src="img/bg/bg-03.png" class="position-absolute top-0 left-n5" alt="...">
            </div>
        </div>
    </div>
</section>
<div class="footer-light footer-new">
    <div class="ftr-bg">
        <div class="footer-top">
            <div class="container">
                <div class="row">

                    <div class="col-lg-4 col-md-12">

                        <div class="widget widget_about">
                            <div>
                                <h3 class="widget-title">Interport Global Logistics</h3>
                            </div>
                            <p>Today, IGL has established offices in major cities and ports in India with
                                warehousing facilities and transport equipment to handle any cargo
                                independently. The company also has access to major international ports through
                                its branch offices.</p>
                            <ul class="social-icon-style1 mb-0">

                                <li>
                                    <a target="_blank" href="https://www.linkedin.com/company/1897064"><i
                                            class="fab fa-linkedin-in"></i></a>
                                </li>

                            </ul>
                        </div>

                    </div>

                    <div class="col-lg-2 col-md-6 col-6">
                        <div class="widget widget_services ftr-list-center">
                            <h3 class="widget-title">Contact Us</h3>
                            <ul>
                                <li><a href="contact.php">Contact</a></li>
                                <li><a href="enquiry-form.php">Enquiry Form</a></li>
                                <li><a href="feedback-form.php">Feedback Form</a></li>
                                <li><a href="air-shipment.php">Air Shipment Bookings</a></li>
                                <li><a href="sea-shipment.php">Sea Shipment Bookings</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6 col-6">
                        <div class="widget widget_services ftr-list-center">
                            <h3 class="widget-title">Important Links</h3>
                            <ul>
                                <li><a href="about.php">About</a></li>
                                <li><a href="careers.php">Careers</a></li>
                                <li><a href="terms-and-conditions.php">Terms & Conditions</a></li>
                                <li><a href="certifications.php">Certifications</a></li>
                                <li><a href="advertisements.php">Advertisements</a></li>
                                <li><a href="sitemap.php">Sitemap</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-12">
                        <div class="widget widget_services ftr-list-center connect-details">
                            <h3 class="widget-title">Online Support</h3>
                            <ul>
                                <p>Everyday is a new day for us and we work really hard to satisfy
                                    our customers everywhere.</p>
                                <li><a href="tel:+91-22 6951 6951"><i class="fa fa-phone"></i><strong> India: T-
                                        </strong> +91-22 6951 6951</a></li>
                                <li><a href="tel:+1 (732) 422-3870"><i class="fa fa-phone"></i><strong> USA: T-
                                        </strong> +1 (732) 422-3870</a></li>
                            </ul>
                            <ul class="mt-md-3">
                                <li><a href="tel:+91-22 6951 6800"><i class="fa fa-fax"></i><strong> India: F-
                                        </strong> +91-22 6951 6800</a></li>
                                <li><a href="tel:+1 (732) 422-3878"><i class="fa fa-fax"></i><strong> USA: F- </strong>
                                        +1 (732) 422-3878</a></li>
                            </ul>
                            <ul class="mt-md-3">
                                <li><a href="mailto:info@interportglobal.com"><i class="fa fa-envelope"></i><strong>
                                            India: E- </strong>info@interportglobal.com</a></li>
                                <li><a href="mailto:usa@interportglobal.com"><i class="fa fa-envelope"></i><strong>
                                            USA: E- </strong>usa@interportglobal.com</a></li>
                            </ul>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <div class="footer-bottom-info">
                    <div class="footer-copy-right">
                        <span class="copyrights-text cpt-txt">Interport Global Logistics &copy; 2023. All rights reserved.
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

</div>
<a href="javascript:void(0)" class="scroll-to-top"><i class="fas fa-angle-up" aria-hidden="true"></i></a>
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/core.min.js"></script>
<script src="js/main.js"></script>
<script>
    $(document).ready(function () {
        $(".hide").click(function () {
            $(".hide-show-block").hide();
        });
        $(".show").click(function () {
            $(".hide-show-block").show();
        });
    });

    $(document).ready(function () {
        $(".hide-one").click(function () {
            $(".hide-show-block-one").hide();
        });
        $(".show-one").click(function () {
            $(".hide-show-block-one").show();
        });
    });
</script>
</body>

</html>
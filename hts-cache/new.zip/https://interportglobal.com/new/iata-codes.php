<!DOCTYPE html>
<html lang="en">

		
 
<head>
    <meta charset="utf-8" />
    <meta name="author" content="Interport Global Logistics" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="keywords" content="Interport Global Logistics" />
    <meta name="description" content="Interport Global Logistics" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;900&display=swap" rel="stylesheet">
    <title>IATA codes - Interport Global Logistics</title>
    <meta name="description" content="Interport Global Logistics - Total Logistics Solutions Provider">
    <meta name="keywords" content="logistics, cargo, solutions, addons, sea freight, air freight, rail freight, cargo insurance, container freight station, custom clearance, import export consolidation, nvocc, door to door delivery, iso flexi tanks, project logistics, heavy lift, break bulk, warehousing, our packing, transportation and distribution, rfid solutions, warehouse management, turnkey projects, logistic solutions, exhibition cargo, hazardous cargo, project cargo, ivrs phone track, airlines, bankers, india info, container specification sea, container specification air, hazmat definitions, shipping glossary, iata codes, usa port codes, print your bill of lading, industry links, inco terms, air shipment, sea shipment" />
    <meta property="og:description" content="Interport Global Logistics - Total Logistics Solutions Provider">
    <meta property="og:site_name" content="Interport Global Logistics">
    <meta property="og:title" content="Interport Global Logistics">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://interportglobal.com/new/">
    <meta property="og:image" content="https://interportglobal.com/new/img/logos/logo-old.png" />
    <meta property="og:image:secure_url" content="https://interportglobal.com/new/img/logos/logo-old.png" />
    <meta property="og:image:width" content="1800" />
    <meta property="og:image:height" content="945" />
    <meta property="og:image:alt" content="Interport Global Logistics" />
    <meta property="og:image:type" content="image/png" />
    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="Interport Global Logistics">
    <meta name="twitter:creator" content="Interport Global Logistics">
    <meta name="twitter:title" content="Interport Global Logistics">
    <meta name="twitter:description" content="Interport Global Logistics - Total Logistics Solutions Provider">
    <link rel="shortcut icon" href="img/logos/logo-old.png" />
    <link rel="apple-touch-icon" href="img/logos/logo-old.png" />
    <link rel="apple-touch-icon" sizes="72x72" href="img/logos/logo-old.png" />
    <link rel="apple-touch-icon" sizes="114x114" href="img/logos/logo-old.png" />
    <link rel="stylesheet" href="css/plugins.css">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="css/mystyle.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link href="css/new-responsive.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/f70dd43e17.js" crossorigin="anonymous"></script>
    <script type="text/javascript">
        function googleTranslateElementInit2() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                autoDisplay: false
            }, 'google_translate_element2');
        }
    </script>
    <script type="text/javascript"
        src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2">
    </script>
    <script type="text/javascript">
        eval(function (p, a, c, k, e, r) {
            e = function (c) {
                return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) :
                    c
                    .toString(36))
            };
            if (!''.replace(/^/, String)) {
                while (c--) r[e(c)] = k[c] || e(c);
                k = [function (e) {
                    return r[e]
                }];
                e = function () {
                    return '\\w+'
                };
                c = 1
            };
            while (c--)
                if (k[c]) p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]);
            return p
        }('6 7(a,b){n{4(2.9){3 c=2.9("o");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s(\'t\'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a==\'\')v;3 b=a.w(\'|\')[1];3 c;3 d=2.x(\'y\');z(3 i=0;i<d.5;i++)4(d[i].A==\'B-C-D\')c=d[i];4(2.j(\'k\')==E||2.j(\'k\').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,\'m\');7(c,\'m\')}}',
            43, 43,
            '||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500'
            .split('|'), 0, {}))
    </script>
    <script>
        (function (w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-M9TZHXX');
    </script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-179148496-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-179148496-1');
    </script>
    <script>
        ! function (f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function () {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '420989926550304');
        fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
            src="https://www.facebook.com/tr?id=420989926550304&ev=PageView&noscript=1" /></noscript>
</head>

<body>
    <div id="preloader"></div>
    <div class="main-wrapper">
        <header class="header-style1 menu_area-light">
            <div class="navbar-default">
                <div class="top-search bg-secondary">
                    <div class="container-fluid px-lg-1-6 px-xl-2-5 px-xxl-2-9">
                        <form class="search-form" action="" method="GET" accept-charset="utf-8">
                            <div class="input-group">
                                <span class="input-group-addon cursor-pointer">
                                    <button class="search-form_submit fas fa-search text-white" type="submit"></button>
                                </span>
                                <input type="text" class="search-form_input form-control" name="s" autocomplete="off"
                                    placeholder="Type &amp; hit enter...">
                                <span class="input-group-addon close-search mt-1"><i class="fas fa-times"></i></span>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="container-fluid px-lg-1-6 px-xl-2-5 px-xxl-2-9">
                    <div class="row align-items-center">
                        <div class="col-12 col-lg-12 p-0 px-lg-2">
                            <div class="menu_area alt-font">
                                <nav class="navbar navbar-expand-lg navbar-light p-0">
                                    <div class="navbar-header navbar-header-custom">
                                        <a href="index.php" class="navbar-brand logochange">
                                            <img id="logo" class="home-logo" src="img/logos/logo-w.png" alt="logo" />
                                            <img id="logo" class="other-logo" src="img/logos/logo-b.png" alt="logo" />
                                        </a>
                                    </div>
                                    <div class="navbar-toggler bg-primary"></div>
                                    <ul class="navbar-nav" id="nav" style="display: none;">
                                        <li
                                            >
                                            <a href="https://interportglobal.com/new/index.php">Home</a></li>
                                        <li >
                                            <a href="about.php">About Us</a>
                                        </li>
                                        <li
                                            class="d-none d-lg-block d-xl-block 
                                            ">
                                            <a href="https://interportglobal.com/new/services.php">Services</a>
                                            <ul class="row megamenu">
                                                <li class="col-lg-4 col-sm-12">
                                                    <ul>
                                                        <li><a href="freight-forwarding.php">Freight Forwarding</a></li>
                                                        <li><a href="ocean-freight.php">Ocean Freight</a></li>
                                                        <li><a href="air-freight.php">Air Freight</a></li>
                                                        <li><a href="rail-freight.php">Rail Freight</a></li>
                                                        <li><a href="road-freight.php">Road Freight</a></li>
                                                        <li><a href="3pl-warehousing.php">3PL Warehousing</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <ul>
                                                        <li><a href="custom-brokerage.php">Custom Brokerage</a></li>
                                                        <li><a href="hazardous-cargo.php">Hazardous Cargo</a></li>
                                                        <li><a href="project-cargo.php">Project Cargo</a></li>
                                                        <li><a href="heavy-lift.php">Heavy Lift</a></li>
                                                        <li><a href="door-to-door-program.php">Door To Door
                                                                Program</a></li>
                                                        <li><a href="vessel-handling.php">Vessel Handling</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <ul>
                                                        <li><a href="turnkey-projects.php">Turnkey Projects</a></li>
                                                        <li><a href="iso-flexi-tanks.php">ISO Tanks / Flexi Tanks</a>
                                                        </li>
                                                        <li><a href="cargo-insurance.php">Cargo Insurance</a></li>
                                                        <li><a href="nvocc.php">NVOCC</a></li>
                                                        <li><a href="import-export-consolidation.php">Import / Export
                                                                Consolidation</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                        <li
                                            class="d-block d-lg-none d-xl-none 
                                            ">
                                            <a href="services.php">Services</a>
                                            <ul>
                                                <li><a href="services.php">Services</a></li>
                                                <li><a href="freight-forwarding.php">Freight Forwarding</a></li>
                                                <li><a href="ocean-freight.php">Ocean Freight</a></li>
                                                <li><a href="air-freight.php">Air Freight</a></li>
                                                <li><a href="rail-freight.php">Rail Freight</a></li>
                                                <li><a href="road-freight.php">Road Freight</a></li>
                                                <li><a href="3pl-warehousing.php">3PL Warehousing</a>
                                                </li>
                                                <li><a href="custom-brokerage.php">Custom Brokerage</a></li>
                                                <li><a href="hazardous-cargo.php">Hazardous Cargo</a></li>
                                                <li><a href="project-cargo.php">Project Cargo</a></li>
                                                <li><a href="heavy-lift.php">Heavy Lift</a></li>
                                                <li><a href="door-to-door-program.php">Door To Door
                                                        Program</a></li>
                                                <li><a href="vessel-handling.php">Vessel Handling</a></li>
                                                <li><a href="turnkey-projects.php">Turnkey Projects</a></li>
                                                <li><a href="iso-flexi-tanks.php">ISO Tanks / Flexi Tanks</a>
                                                </li>
                                                <li><a href="cargo-insurance.php">Cargo Insurance</a></li>
                                                <li><a href="nvocc.php">NVOCC</a></li>
                                                <li><a href="import-export-consolidation.php">Import / Export
                                                        Consolidation</a></li>
                                            </ul>
                                        </li>
                                        <li
                                            class="active">
                                            <a href="javascript:void(0)">Resources</a>
                                            <ul class="row megamenu">
                                                <li class="col-lg-4 col-sm-12">
                                                    <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Other
                                                        Links</span>
                                                    <ul>
                                                        <li><a href="airlines.php">Airlines</a></li>
                                                        <li><a href="bankers.php">Bankers</a></li>
                                                        <li><a href="2023-holiday-list.php">2023 Holiday List</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Important
                                                        Info</span>
                                                    <ul>
                                                        <li><a href="india-info.php">India Info</a></li>
                                                        <li><a href="container-specification-sea.php">Container
                                                                Specification-Sea</a></li>
                                                        <li><a href="container-specification-air.php">Container
                                                                Specification-Air</a></li>
                                                        <li><a href="hazmat-definitions.php">Hazmat Definifitons</a>
                                                        </li>
                                                        <li><a href="shipping-glossary.php">Shipping Glossary</a></li>
                                                        <li><a href="iata-codes.php">IATA Codes</a></li>
                                                        <li><a href="usa-port-codes.php">USA Port Codes</a></li>
                                                        <li><a href="print-your-bill-of-lading.php">Print Your Bill Of
                                                                Lading</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Important
                                                        Links</span>
                                                    <ul>
                                                        <li><a href="industry-links.php">Industry Links</a></li>
                                                        <li><a href="inco-terms.php">INCO Terms</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                        <li >
                                            <a href="careers.php">Careers</a>
                                        </li>
                                        <li >
                                            <a href="network.php">Network</a>
                                        </li>
                                        <li
                                            >
                                            <a href="contact.php">Contact</a>
                                            <ul>
                                                <li
                                                    class="d-block d-lg-none ">
                                                    <a href="contact.php">Contact</a>
                                                </li>
                                                <li >
                                                    <a href="enquiry-form.php">Enquiry Form</a>
                                                </li>
                                                <li >
                                                    <a href="feedback-form.php">Feedback Form</a>
                                                </li>
                                                <li >
                                                    <a href="air-shipment.php">Air Shipment Bookings</a>
                                                </li>
                                                <li >
                                                    <a href="sea-shipment.php">Sea Shipment Bookings</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li
                                            class=" d-block d-lg-none">
                                            <a href="get-a-quote.php">Get a Quote</a>
                                        </li>
                                        <li class="d-block d-lg-none">
                                            <a target="_blank"
                                                href="http://www.interportglobal.net/Logisys/customervisibility/login.aspx">Track
                                                your shipment</a>
                                        </li>
                                        <li class="d-block d-lg-none">
                                                <select class="language-dropdown" onchange="doGTranslate(this);">
                                                    <option value="">Select a language</option>
                                                    <option value="en|af">Af</option>
                                                    <option value="en|sq">sq</option>
                                                    <option value="en|am">am</option>
                                                    <option value="en|ar">ar</option>
                                                    <option value="en|hy">hy</option>
                                                    <option value="en|az">az</option>
                                                    <option value="en|eu">eu</option>
                                                    <option value="en|be">be</option>
                                                    <option value="en|bn">bn</option>
                                                    <option value="en|bs">bs</option>
                                                    <option value="en|bg">bg</option>
                                                    <option value="en|ca">ca</option>
                                                    <option value="en|ceb">ceb</option>
                                                    <option value="en|ny">ny</option>
                                                    <option value="en|zh-CN">zh-CN</option>
                                                    <option value="en|zh-TW">zh-TW</option>
                                                    <option value="en|co">co</option>
                                                    <option value="en|hr">hr</option>
                                                    <option value="en|cs">cs</option>
                                                    <option value="en|da">da</option>
                                                    <option value="en|nl">nl</option>
                                                    <option value="en|en">en</option>
                                                    <option value="en|eo">eo</option>
                                                    <option value="en|et">et</option>
                                                    <option value="en|tl">tl</option>
                                                    <option value="en|fi">fi</option>
                                                    <option value="en|fr">fr</option>
                                                    <option value="en|fy">fy</option>
                                                    <option value="en|gl">gl </option>
                                                    <option value="en|ka">ka </option>
                                                    <option value="en|de">de </option>
                                                    <option value="en|el">el </option>
                                                    <option value="en|gu">gu </option>
                                                    <option value="en|ht">ht</option>
                                                    <option value="en|ha">ha </option>
                                                    <option value="en|haw">haw</option>
                                                    <option value="en|iw">iw </option>
                                                    <option value="en|hi">hi </option>
                                                    <option value="en|hmn">hmn</option>
                                                    <option value="en|hu">hu</option>
                                                    <option value="en|is">is</option>
                                                    <option value="en|ig">ig </option>
                                                    <option value="en|id">id</option>
                                                    <option value="en|ga">ga </option>
                                                    <option value="en|it">it </option>
                                                    <option value="en|ja">ja </option>
                                                    <option value="en|jw">jw </option>
                                                    <option value="en|kn">kn </option>
                                                    <option value="en|kk">kk </option>
                                                    <option value="en|km">km </option>
                                                    <option value="en|ko">ko </option>
                                                    <option value="en|ku">ku </option>
                                                    <option value="en|ky">ky </option>
                                                    <option value="en|lo">lo </option>
                                                    <option value="en|la">la </option>
                                                    <option value="en|lv">lv </option>
                                                    <option value="en|lt">lt </option>
                                                    <option value="en|lb">lb </option>
                                                    <option value="en|mk">mk </option>
                                                    <option value="en|mg">mg </option>
                                                    <option value="en|ms">ms </option>
                                                    <option value="en|ml">ml </option>
                                                    <option value="en|mt">mt </option>
                                                    <option value="en|mi">mi </option>
                                                    <option value="en|mr">mr </option>
                                                    <option value="en|mn">mn </option>
                                                    <option value="en|my">my </option>
                                                    <option value="en|ne">ne </option>
                                                    <option value="en|no">no </option>
                                                    <option value="en|ps">ps </option>
                                                    <option value="en|fa">fa </option>
                                                    <option value="en|pl">pl </option>
                                                    <option value="en|pt">pt </option>
                                                    <option value="en|pa">pa </option>
                                                    <option value="en|ro">ro </option>
                                                    <option value="en|ru">ru </option>
                                                    <option value="en|sm">sm </option>
                                                    <option value="en|gd">gd </option>
                                                    <option value="en|sr">sr </option>
                                                    <option value="en|st">st </option>
                                                    <option value="en|sn">sn </option>
                                                    <option value="en|sd">sd </option>
                                                    <option value="en|si">si </option>
                                                    <option value="en|sk">sk </option>
                                                    <option value="en|sl">sl </option>
                                                    <option value="en|so">so </option>
                                                    <option value="en|es">es </option>
                                                    <option value="en|su">su </option>
                                                    <option value="en|sw">sw </option>
                                                    <option value="en|sv">sv </option>
                                                    <option value="en|tg">tg </option>
                                                    <option value="en|ta">ta </option>
                                                    <option value="en|te">te </option>
                                                    <option value="en|th">th </option>
                                                    <option value="en|tr">tr </option>
                                                    <option value="en|uk">uk </option>
                                                    <option value="en|ur">ur </option>
                                                    <option value="en|uz">uz </option>
                                                    <option value="en|vi">vi </option>
                                                    <option value="en|cy">cy </option>
                                                    <option value="en|xh">xh </option>
                                                    <option value="en|yi">yi </option>
                                                    <option value="en|yo">yo </option>
                                                    <option value="en|zu">zu </option>
                                                </select>
                                                <div id="google_translate_element2"></div>

                                        </li>
                                    </ul>
                                    <div class="attr-nav align-items-xl-center main-font">
                                        <ul>
                                            <li class="d-none d-xl-inline-block">
                                                <a target="_blank"
                                                    href="http://www.interportglobal.net/Logisys/customervisibility/login.aspx"
                                                    class="butn outline me-3">
                                                    <span>Track a shipment</span>
                                                </a>
                                            </li>
                                            <li class="d-none d-xl-inline-block">
                                                <a href="get-a-quote.php" class="butn primary">
                                                    <span>Get a Quote</span>
                                                </a>
                                            </li>
                                            <li class="d-none d-xl-inline-block">
                                                <select class="language-dropdown" onchange="doGTranslate(this);">
                                                    <option value="">en</option>
                                                    <option value="en|af">Af</option>
                                                    <option value="en|sq">sq</option>
                                                    <option value="en|am">am</option>
                                                    <option value="en|ar">ar</option>
                                                    <option value="en|hy">hy</option>
                                                    <option value="en|az">az</option>
                                                    <option value="en|eu">eu</option>
                                                    <option value="en|be">be</option>
                                                    <option value="en|bn">bn</option>
                                                    <option value="en|bs">bs</option>
                                                    <option value="en|bg">bg</option>
                                                    <option value="en|ca">ca</option>
                                                    <option value="en|ceb">ceb</option>
                                                    <option value="en|ny">ny</option>
                                                    <option value="en|zh-CN">zh-CN</option>
                                                    <option value="en|zh-TW">zh-TW</option>
                                                    <option value="en|co">co</option>
                                                    <option value="en|hr">hr</option>
                                                    <option value="en|cs">cs</option>
                                                    <option value="en|da">da</option>
                                                    <option value="en|nl">nl</option>
                                                    <option value="en|en">en</option>
                                                    <option value="en|eo">eo</option>
                                                    <option value="en|et">et</option>
                                                    <option value="en|tl">tl</option>
                                                    <option value="en|fi">fi</option>
                                                    <option value="en|fr">fr</option>
                                                    <option value="en|fy">fy</option>
                                                    <option value="en|gl">gl </option>
                                                    <option value="en|ka">ka </option>
                                                    <option value="en|de">de </option>
                                                    <option value="en|el">el </option>
                                                    <option value="en|gu">gu </option>
                                                    <option value="en|ht">ht</option>
                                                    <option value="en|ha">ha </option>
                                                    <option value="en|haw">haw</option>
                                                    <option value="en|iw">iw </option>
                                                    <option value="en|hi">hi </option>
                                                    <option value="en|hmn">hmn</option>
                                                    <option value="en|hu">hu</option>
                                                    <option value="en|is">is</option>
                                                    <option value="en|ig">ig </option>
                                                    <option value="en|id">id</option>
                                                    <option value="en|ga">ga </option>
                                                    <option value="en|it">it </option>
                                                    <option value="en|ja">ja </option>
                                                    <option value="en|jw">jw </option>
                                                    <option value="en|kn">kn </option>
                                                    <option value="en|kk">kk </option>
                                                    <option value="en|km">km </option>
                                                    <option value="en|ko">ko </option>
                                                    <option value="en|ku">ku </option>
                                                    <option value="en|ky">ky </option>
                                                    <option value="en|lo">lo </option>
                                                    <option value="en|la">la </option>
                                                    <option value="en|lv">lv </option>
                                                    <option value="en|lt">lt </option>
                                                    <option value="en|lb">lb </option>
                                                    <option value="en|mk">mk </option>
                                                    <option value="en|mg">mg </option>
                                                    <option value="en|ms">ms </option>
                                                    <option value="en|ml">ml </option>
                                                    <option value="en|mt">mt </option>
                                                    <option value="en|mi">mi </option>
                                                    <option value="en|mr">mr </option>
                                                    <option value="en|mn">mn </option>
                                                    <option value="en|my">my </option>
                                                    <option value="en|ne">ne </option>
                                                    <option value="en|no">no </option>
                                                    <option value="en|ps">ps </option>
                                                    <option value="en|fa">fa </option>
                                                    <option value="en|pl">pl </option>
                                                    <option value="en|pt">pt </option>
                                                    <option value="en|pa">pa </option>
                                                    <option value="en|ro">ro </option>
                                                    <option value="en|ru">ru </option>
                                                    <option value="en|sm">sm </option>
                                                    <option value="en|gd">gd </option>
                                                    <option value="en|sr">sr </option>
                                                    <option value="en|st">st </option>
                                                    <option value="en|sn">sn </option>
                                                    <option value="en|sd">sd </option>
                                                    <option value="en|si">si </option>
                                                    <option value="en|sk">sk </option>
                                                    <option value="en|sl">sl </option>
                                                    <option value="en|so">so </option>
                                                    <option value="en|es">es </option>
                                                    <option value="en|su">su </option>
                                                    <option value="en|sw">sw </option>
                                                    <option value="en|sv">sv </option>
                                                    <option value="en|tg">tg </option>
                                                    <option value="en|ta">ta </option>
                                                    <option value="en|te">te </option>
                                                    <option value="en|th">th </option>
                                                    <option value="en|tr">tr </option>
                                                    <option value="en|uk">uk </option>
                                                    <option value="en|ur">ur </option>
                                                    <option value="en|uz">uz </option>
                                                    <option value="en|vi">vi </option>
                                                    <option value="en|cy">cy </option>
                                                    <option value="en|xh">xh </option>
                                                    <option value="en|yi">yi </option>
                                                    <option value="en|yo">yo </option>
                                                    <option value="en|zu">zu </option>
                                                </select>
                                                <div id="google_translate_element2"></div>
                                            </li>
                                        </ul>
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <div class="modal fade" id="getaquote_modal" tabindex="-1" aria-labelledby="centeredLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title" id="centeredLabel">Get a Quote</h3>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <form class="row g-3">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_name" placeholder="Name">
                                            <label for="quote_name">Name</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-1">
                                            <input type="email" class="form-control" id="quote_email"
                                                placeholder="Email">
                                            <label for="quote_email">Email</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_phone"
                                                placeholder="Phone">
                                            <label for="quote_phone">Phone</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected>Freight Type</option>
                                                <option value="1">Freight Type 1</option>
                                                <option value="2">Freight Type 2</option>
                                                <option value="3">Freight Type 3</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_city_of_departure"
                                                placeholder="City of Departure">
                                            <label for="quote_city_of_departure">City of Departure</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_delivery_city"
                                                placeholder="Delivery City">
                                            <label for="quote_delivery_city">Delivery City</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected>Incoterms</option>
                                                <option value="1">Incoterms 1</option>
                                                <option value="2">Incoterms 2</option>
                                                <option value="3">Incoterms 3</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_weight"
                                                placeholder="Weight (kg)">
                                            <label for="quote_weight">Weight (kg)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_height"
                                                placeholder="Height (cm)">
                                            <label for="quote_height">Height (cm)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_width"
                                                placeholder="Width (cm)">
                                            <label for="quote_width">Width (cm)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_length"
                                                placeholder="Length (cm)">
                                            <label for="quote_length">Length (cm)</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="quote_fragile">
                                            <label class="form-check-label" for="quote_fragile">
                                                Fragile
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="quote_express_delivery">
                                            <label class="form-check-label" for="quote_express_delivery">
                                                Express Delivery
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="quote_insurance">
                                            <label class="form-check-label" for="quote_insurance">
                                                Insurance
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="quote_packaging">
                                            <label class="form-check-label" for="quote_packaging">
                                                Packaging
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>
                    <div class="modal-footer justify-content-center">
                        <button type="button" class="butn primary">Save</button>
                    </div>
                </div>
            </div>
        </div>
<section class="page-title-section main-title-section bg-light">
    <div class="container title-container">
        <div class="row">
            <div class="col-md-12">
                <ul class="wow fadeInUp breadcrump-list" data-wow-delay="400ms">
                    <li><a href="index.php">Home</a></li>
                    <li><a>Resources</a></li>
                    <li><a>IATA Codes</a></li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <ul class="nav nav-tabs" id="iatacodesTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="a-tab" data-bs-toggle="tab" data-bs-target="#a" type="button"
                    role="tab" aria-controls="a" aria-selected="true">A</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="ab-tab" data-bs-toggle="tab" data-bs-target="#ab" type="button" role="tab"
                    aria-controls="ab" aria-selected="false">B</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="c-tab" data-bs-toggle="tab" data-bs-target="#c" type="button" role="tab"
                    aria-controls="c" aria-selected="false">C</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="d-tab" data-bs-toggle="tab" data-bs-target="#d" type="button" role="tab"
                    aria-controls="d" aria-selected="false">D</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="e-tab" data-bs-toggle="tab" data-bs-target="#e" type="button" role="tab"
                    aria-controls="e" aria-selected="false">E</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="f-tab" data-bs-toggle="tab" data-bs-target="#f" type="button" role="tab"
                    aria-controls="f" aria-selected="false">F</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="g-tab" data-bs-toggle="tab" data-bs-target="#g" type="button" role="tab"
                    aria-controls="g" aria-selected="false">G</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="h-tab" data-bs-toggle="tab" data-bs-target="#h" type="button" role="tab"
                    aria-controls="h" aria-selected="false">H</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="i-tab" data-bs-toggle="tab" data-bs-target="#i" type="button" role="tab"
                    aria-controls="i" aria-selected="false">I</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="j-tab" data-bs-toggle="tab" data-bs-target="#j" type="button" role="tab"
                    aria-controls="j" aria-selected="false">J</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="k-tab" data-bs-toggle="tab" data-bs-target="#k" type="button" role="tab"
                    aria-controls="k" aria-selected="false">K</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="l-tab" data-bs-toggle="tab" data-bs-target="#l" type="button" role="tab"
                    aria-controls="l" aria-selected="false">L</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="m-tab" data-bs-toggle="tab" data-bs-target="#m" type="button" role="tab"
                    aria-controls="m" aria-selected="false">M</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="n-tab" data-bs-toggle="tab" data-bs-target="#n" type="button" role="tab"
                    aria-controls="n" aria-selected="false">N</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="o-tab" data-bs-toggle="tab" data-bs-target="#o" type="button" role="tab"
                    aria-controls="o" aria-selected="false">O</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="p-tab" data-bs-toggle="tab" data-bs-target="#p" type="button" role="tab"
                    aria-controls="p" aria-selected="false">P</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="q-tab" data-bs-toggle="tab" data-bs-target="#q" type="button" role="tab"
                    aria-controls="q" aria-selected="false">Q</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="r-tab" data-bs-toggle="tab" data-bs-target="#r" type="button" role="tab"
                    aria-controls="r" aria-selected="false">R</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="s-tab" data-bs-toggle="tab" data-bs-target="#s" type="button" role="tab"
                    aria-controls="s" aria-selected="false">S</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="t-tab" data-bs-toggle="tab" data-bs-target="#t" type="button" role="tab"
                    aria-controls="t" aria-selected="false">T</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="u-tab" data-bs-toggle="tab" data-bs-target="#u" type="button" role="tab"
                    aria-controls="u" aria-selected="false">U</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="v-tab" data-bs-toggle="tab" data-bs-target="#v" type="button" role="tab"
                    aria-controls="v" aria-selected="false">V</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="w-tab" data-bs-toggle="tab" data-bs-target="#w" type="button" role="tab"
                    aria-controls="w" aria-selected="false">W</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="x-tab" data-bs-toggle="tab" data-bs-target="#x" type="button" role="tab"
                    aria-controls="x" aria-selected="false">X</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="y-tab" data-bs-toggle="tab" data-bs-target="#y" type="button" role="tab"
                    aria-controls="y" aria-selected="false">Y</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="z-tab" data-bs-toggle="tab" data-bs-target="#z" type="button" role="tab"
                    aria-controls="z" aria-selected="false">Z</button>
            </li>
        </ul>
        <div class="tab-content" id="iatacodesTabContent">
            <div class="tab-pane fade show active" id="a" role="tabpanel" aria-labelledby="a-tab">
                <div class="table-responsive">
                    <table class="table text-left red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Aalborg</td>
                                <td>AAL</td>
                                <td>AAL</td>
                                <td>Anchorage</td>
                                <td>ANC</td>
                                <td>ANC</td>
                            </tr>
                            <tr>
                                <td>Aarhus</td>
                                <td>AAR</td>
                                <td>AAR</td>
                                <td>Anchorage, Merrill Field</td>
                                <td>ANC</td>
                                <td>MRI</td>
                            </tr>
                            <tr>
                                <td>Abadan</td>
                                <td>ABD</td>
                                <td>ABD</td>
                                <td>Ancona</td>
                                <td>AOI</td>
                                <td>AOI</td>
                            </tr>
                            <tr>
                                <td>Abakan</td>
                                <td>ABA</td>
                                <td>ABA</td>
                                <td>Andahuaylas</td>
                                <td>ANS</td>
                                <td>ANS</td>
                            </tr>
                            <tr>
                                <td>Aberdeen</td>
                                <td>ABR</td>
                                <td>ABR</td>
                                <td>Anguilla</td>
                                <td>AZA</td>
                                <td>AZA</td>
                            </tr>
                            <tr>
                                <td>Aberdeen</td>
                                <td>ABZ</td>
                                <td>ABZ</td>
                                <td>Aniak</td>
                                <td>ANI</td>
                                <td>ANI</td>
                            </tr>
                            <tr>
                                <td>Abha</td>
                                <td>AHB</td>
                                <td>AHB</td>
                                <td>Ankang</td>
                                <td>AKA</td>
                                <td>AKA</td>
                            </tr>
                            <tr>
                                <td>Abu Dhabi</td>
                                <td>AUH</td>
                                <td>AUH</td>
                                <td>Ankara</td>
                                <td>ANK</td>
                                <td>ANK</td>
                            </tr>
                            <tr>
                                <td>Abidjan</td>
                                <td>ABJ</td>
                                <td>ABJ</td>
                                <td>Ankara, Esenboga</td>
                                <td>ANK</td>
                                <td>ESB</td>
                            </tr>
                            <tr>
                                <td>Abilene</td>
                                <td>ABI</td>
                                <td>ABI</td>
                                <td>Annecy</td>
                                <td>NCY</td>
                                <td>NCY</td>
                            </tr>
                            <tr>
                                <td>Abuja</td>
                                <td>ABV</td>
                                <td>ABV</td>
                                <td>Antalya</td>
                                <td>AYT</td>
                                <td>AYT</td>
                            </tr>
                            <tr>
                                <td>Acapulco</td>
                                <td>ACA</td>
                                <td>ACA</td>
                                <td>Antananarivo</td>
                                <td>TNR</td>
                                <td>TNR</td>
                            </tr>
                            <tr>
                                <td>Acarigua</td>
                                <td>AGV</td>
                                <td>AGV</td>
                                <td>Antigua</td>
                                <td>ANU</td>
                                <td>ANU</td>
                            </tr>
                            <tr>
                                <td>Accra</td>
                                <td>ACC</td>
                                <td>ACC</td>
                                <td>Antofagasta</td>
                                <td>ANF</td>
                                <td>ANF</td>
                            </tr>
                            <tr>
                                <td>Adak Island</td>
                                <td>ADK</td>
                                <td>ADK</td>
                                <td>Antwerp</td>
                                <td>ANR</td>
                                <td>ANR</td>
                            </tr>
                            <tr>
                                <td>Adana</td>
                                <td>ADA</td>
                                <td>ADA</td>
                                <td>Anvik</td>
                                <td>ANV</td>
                                <td>ANV</td>
                            </tr>
                            <tr>
                                <td>Addis Ababa</td>
                                <td>ADD</td>
                                <td>ADD</td>
                                <td>Aomori</td>
                                <td>AOJ</td>
                                <td>AOJ</td>
                            </tr>
                            <tr>
                                <td>Adelaide</td>
                                <td>ADL</td>
                                <td>ADL</td>
                                <td>Apia</td>
                                <td>APW</td>
                                <td>APW</td>
                            </tr>
                            <tr>
                                <td>Aden</td>
                                <td>ADE</td>
                                <td>ADE</td>
                                <td>Appleton</td>
                                <td>ATW</td>
                                <td>ATW</td>
                            </tr>
                            <tr>
                                <td>Adler</td>
                                <td>AER</td>
                                <td>AER</td>
                                <td>Aqaba</td>
                                <td>AQJ</td>
                                <td>AQJ</td>
                            </tr>
                            <tr>
                                <td>Agadir</td>
                                <td>AGA</td>
                                <td>AGA</td>
                                <td>Arcata, Eureka</td>
                                <td>ACV</td>
                                <td>ACV</td>
                            </tr>
                            <tr>
                                <td>Aguascaliente</td>
                                <td>AGU</td>
                                <td>AGU</td>
                                <td>Arctic Village</td>
                                <td>ARC</td>
                                <td>ARC</td>
                            </tr>
                            <tr>
                                <td>Ahmedabad</td>
                                <td>AMD</td>
                                <td>AMD</td>
                                <td>Arecibo</td>
                                <td>ARE</td>
                                <td>ARE</td>
                            </tr>
                            <tr>
                                <td>Ajaccio</td>
                                <td>AJA</td>
                                <td>AJA</td>
                                <td>Arequipa</td>
                                <td>AQP</td>
                                <td>AQP</td>
                            </tr>
                            <tr>
                                <td>Akiachak</td>
                                <td>KKI</td>
                                <td>KKI</td>
                                <td>Arica</td>
                                <td>ARI</td>
                                <td>ARI</td>
                            </tr>
                            <tr>
                                <td>Akiak</td>
                                <td>AKI</td>
                                <td>AKI</td>
                                <td>Aruba</td>
                                <td>AUA</td>
                                <td>AUA</td>
                            </tr>
                            <tr>
                                <td>Akita</td>
                                <td>AXT</td>
                                <td>AXT</td>
                                <td>Ascension</td>
                                <td>ASC</td>
                                <td>ASC</td>
                            </tr>
                            <tr>
                                <td>Akron/Canton</td>
                                <td>CAK</td>
                                <td>CAK</td>
                                <td>Asheville</td>
                                <td>AVL</td>
                                <td>AVL</td>
                            </tr>
                            <tr>
                                <td>Al-Baha</td>
                                <td>ABT</td>
                                <td>ABT</td>
                                <td>Ashikawa</td>
                                <td>AKJ</td>
                                <td>AKJ</td>
                            </tr>
                            <tr>
                                <td>Al-Fujairah</td>
                                <td>FJR</td>
                                <td>FJR</td>
                                <td>Ashland, Huntington</td>
                                <td>HTS</td>
                                <td>HTS</td>
                            </tr>
                            <tr>
                                <td>Albany</td>
                                <td>ABY</td>
                                <td>ABY</td>
                                <td>Asmara</td>
                                <td>ASM</td>
                                <td>ASM</td>
                            </tr>
                            <tr>
                                <td>Albany</td>
                                <td>ALB</td>
                                <td>ALB</td>
                                <td>Asturias</td>
                                <td>OVD</td>
                                <td>OVD</td>
                            </tr>
                            <tr>
                                <td>Albert Bay</td>
                                <td>YAL</td>
                                <td>YAL</td>
                                <td>Asuncion</td>
                                <td>ASU</td>
                                <td>ASU</td>
                            </tr>
                            <tr>
                                <td>Albuquerque</td>
                                <td>ABQ</td>
                                <td>ABQ</td>
                                <td>Aswan</td>
                                <td>ASW</td>
                                <td>ASW</td>
                            </tr>
                            <tr>
                                <td>Aleandroupolis</td>
                                <td>AXD</td>
                                <td>AXD</td>
                                <td>Athens</td>
                                <td>ATH</td>
                                <td>ATH</td>
                            </tr>
                            <tr>
                                <td>Aleppo</td>
                                <td>ALP</td>
                                <td>ALP</td>
                                <td>Atlanta</td>
                                <td>ATL</td>
                                <td>ATL</td>
                            </tr>
                            <tr>
                                <td>Alexandria</td>
                                <td>ESF</td>
                                <td>ESF</td>
                                <td>Atlanta, Beaver Ruin</td>
                                <td>ATL</td>
                                <td>JAO</td>
                            </tr>
                            <tr>
                                <td>Algiers</td>
                                <td>ALG</td>
                                <td>ALG</td>
                                <td>Atlanta, Perimeter Mall</td>
                                <td>ATL</td>
                                <td>JAJ</td>
                            </tr>
                            <tr>
                                <td>Alicante</td>
                                <td>ALC</td>
                                <td>ALC</td>
                                <td>Atlantic City</td>
                                <td>AIY</td>
                                <td>AIY</td>
                            </tr>
                            <tr>
                                <td>Allakaket</td>
                                <td>AET</td>
                                <td>AET</td>
                                <td>Atlantic City, Pomona Field</td>
                                <td>AIY</td>
                                <td>ACY</td>
                            </tr>
                            <tr>
                                <td>Allentown</td>
                                <td>ABE</td>
                                <td>ABE</td>
                                <td>Atmautluak</td>
                                <td>ATT</td>
                                <td>ATT</td>
                            </tr>
                            <tr>
                                <td>Alma Ata</td>
                                <td>ALA</td>
                                <td>ALA</td>
                                <td>Auckland</td>
                                <td>AKL</td>
                                <td>AKL</td>
                            </tr>
                            <tr>
                                <td>Alor Setar</td>
                                <td>AOR</td>
                                <td>AOR</td>
                                <td>Augusta</td>
                                <td>AGS</td>
                                <td>AGS</td>
                            </tr>
                            <tr>
                                <td>Altoona</td>
                                <td>AOO</td>
                                <td>AOO</td>
                                <td>Austin</td>
                                <td>AUS</td>
                                <td>AUS</td>
                            </tr>
                            <tr>
                                <td>Amarillo</td>
                                <td>AMA</td>
                                <td>AMA</td>
                                <td>Ayacucho</td>
                                <td>AYP</td>
                                <td>AYP</td>
                            </tr>
                            <tr>
                                <td>Amchitka</td>
                                <td>AHT</td>
                                <td>AHT</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Amman</td>
                                <td>AMM</td>
                                <td>AMM</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Amritsar</td>
                                <td>ATQ</td>
                                <td>ATQ</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Amsterdam</td>
                                <td>AMS</td>
                                <td>AMS</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Amsterdam, Schiphol Airport</td>
                                <td>AMS</td>
                                <td>SPL</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="ab" role="tabpanel" aria-labelledby="ab-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Baghdad, Al Muthana</td>
                                <td>BGW</td>
                                <td>BGW</td>
                                <td>Biak</td>
                                <td>BIK</td>
                                <td>BIK</td>
                            </tr>
                            <tr>
                                <td>Baghdad, Saddam International</td>
                                <td>BGW</td>
                                <td>SDA</td>
                                <td>Biarritz</td>
                                <td>BIQ</td>
                                <td>BIQ</td>
                            </tr>
                            <tr>
                                <td>Bahrain</td>
                                <td>BAH</td>
                                <td>BAH</td>
                                <td>Bilbao</td>
                                <td>BIO</td>
                                <td>BIO</td>
                            </tr>
                            <tr>
                                <td>Bakersfield</td>
                                <td>BFL</td>
                                <td>BFL</td>
                                <td>Billings</td>
                                <td>BIL</td>
                                <td>BIL</td>
                            </tr>
                            <tr>
                                <td>Bali Island, Denpasar</td>
                                <td>DPS</td>
                                <td>DPS</td>
                                <td>Billund</td>
                                <td>BLL</td>
                                <td>BLL</td>
                            </tr>
                            <tr>
                                <td>Balmaceda</td>
                                <td>BBA</td>
                                <td>BBA</td>
                                <td>Binghamton</td>
                                <td>BGM</td>
                                <td>BGM</td>
                            </tr>
                            <tr>
                                <td>Baltimore</td>
                                <td>BWI</td>
                                <td>BWI</td>
                                <td>Bintulu</td>
                                <td>BTU</td>
                                <td>BTU</td>
                            </tr>
                            <tr>
                                <td>Baltimore, Gl. Martin</td>
                                <td>BWI</td>
                                <td>MTN</td>
                                <td>Birmingham</td>
                                <td>BHM</td>
                                <td>BHM</td>
                            </tr>
                            <tr>
                                <td>Bamako</td>
                                <td>BKO</td>
                                <td>BKO</td>
                                <td>Birmingham</td>
                                <td>BHX</td>
                                <td>BHX</td>
                            </tr>
                            <tr>
                                <td>Bandar Abbas</td>
                                <td>BND</td>
                                <td>BND</td>
                                <td>Bissau</td>
                                <td>BXO</td>
                                <td>BXO</td>
                            </tr>
                            <tr>
                                <td>Bandar Seri Bagawan</td>
                                <td>BWN</td>
                                <td>BWN</td>
                                <td>Blantyre</td>
                                <td>BLZ</td>
                                <td>BLZ</td>
                            </tr>
                            <tr>
                                <td>Bangalore</td>
                                <td>BLR</td>
                                <td>BLR</td>
                                <td>Bloemfontein</td>
                                <td>BFN</td>
                                <td>BFN</td>
                            </tr>
                            <tr>
                                <td>Bangkok</td>
                                <td>BKK</td>
                                <td>BKK</td>
                                <td>Bloomington</td>
                                <td>BMI</td>
                                <td>BMI</td>
                            </tr>
                            <tr>
                                <td>Bangor</td>
                                <td>BGR</td>
                                <td>BGR</td>
                                <td>Boa Vista</td>
                                <td>BVB</td>
                                <td>BVB</td>
                            </tr>
                            <tr>
                                <td>Bangui</td>
                                <td>BGF</td>
                                <td>BGF</td>
                                <td>Bodo</td>
                                <td>BOO</td>
                                <td>BOO</td>
                            </tr>
                            <tr>
                                <td>Banjul</td>
                                <td>BJL</td>
                                <td>BJL</td>
                                <td>Bogota</td>
                                <td>BOG</td>
                                <td>BOG</td>
                            </tr>
                            <tr>
                                <td>Baotou</td>
                                <td>BAV</td>
                                <td>BAV</td>
                                <td>Boise</td>
                                <td>BOI</td>
                                <td>BOI</td>
                            </tr>
                            <tr>
                                <td>Barbados</td>
                                <td>BGI</td>
                                <td>BGI</td>
                                <td>Bologna</td>
                                <td>BLQ</td>
                                <td>BLQ</td>
                            </tr>
                            <tr>
                                <td>Barcelona</td>
                                <td>BCN</td>
                                <td>BCN</td>
                                <td>Bombay</td>
                                <td>BOM</td>
                                <td>BOM</td>
                            </tr>
                            <tr>
                                <td>Barcelona</td>
                                <td>BLA</td>
                                <td>BLA</td>
                                <td>Bonaire</td>
                                <td>BON</td>
                                <td>BON</td>
                            </tr>
                            <tr>
                                <td>Bardufoss</td>
                                <td>BDU</td>
                                <td>BDU</td>
                                <td>Bordeaux</td>
                                <td>BOD</td>
                                <td>BOD</td>
                            </tr>
                            <tr>
                                <td>Bari</td>
                                <td>BRI</td>
                                <td>BRI</td>
                                <td>Boston</td>
                                <td>BOS</td>
                                <td>BOS</td>
                            </tr>
                            <tr>
                                <td>Barinas</td>
                                <td>BNS</td>
                                <td>BNS</td>
                                <td>Boulder</td>
                                <td>WBU</td>
                                <td>WBU</td>
                            </tr>
                            <tr>
                                <td>Barquisimeto</td>
                                <td>BRM</td>
                                <td>BRM</td>
                                <td>Bourlamaq/Val D’or</td>
                                <td>YVO</td>
                                <td>YVO</td>
                            </tr>
                            <tr>
                                <td>Barranquilla</td>
                                <td>BAQ</td>
                                <td>BAQ</td>
                                <td>Bournemouth</td>
                                <td>BOH</td>
                                <td>BOH</td>
                            </tr>
                            <tr>
                                <td>Barrow</td>
                                <td>BRW</td>
                                <td>BRW</td>
                                <td>Bozeman</td>
                                <td>BZN</td>
                                <td>BZN</td>
                            </tr>
                            <tr>
                                <td>Basle</td>
                                <td>BSL</td>
                                <td>BSL</td>
                                <td>Bradley</td>
                                <td>BDL</td>
                                <td>BDL</td>
                            </tr>
                            <tr>
                                <td>Basra</td>
                                <td>BSR</td>
                                <td>BSR</td>
                                <td>Brainerd</td>
                                <td>BRD</td>
                                <td>BRD</td>
                            </tr>
                            <tr>
                                <td>Bastia</td>
                                <td>BIA</td>
                                <td>BIA</td>
                                <td>Brasilia</td>
                                <td>BSB</td>
                                <td>BSB</td>
                            </tr>
                            <tr>
                                <td>Bastia, Biak</td>
                                <td>BIA</td>
                                <td>BIK</td>
                                <td>Bratislava</td>
                                <td>BTS</td>
                                <td>BTS</td>
                            </tr>
                            <tr>
                                <td>Baton Rouge</td>
                                <td>BTR</td>
                                <td>BTR</td>
                                <td>Brazzaville</td>
                                <td>BZV</td>
                                <td>BZV</td>
                            </tr>
                            <tr>
                                <td>Battle Creek</td>
                                <td>BTL</td>
                                <td>BTL</td>
                                <td>Bremen</td>
                                <td>BRE</td>
                                <td>BRE</td>
                            </tr>
                            <tr>
                                <td>Bay City/Saginaw</td>
                                <td>MBS</td>
                                <td>MBS</td>
                                <td>Brest</td>
                                <td>BES</td>
                                <td>BES</td>
                            </tr>
                            <tr>
                                <td>Beaumont</td>
                                <td>BPT</td>
                                <td>BPT</td>
                                <td>Bridgeport</td>
                                <td>BDR</td>
                                <td>BDR</td>
                            </tr>
                            <tr>
                                <td>Beaver</td>
                                <td>WBQ</td>
                                <td>WBQ</td>
                                <td>Brisbane</td>
                                <td>BNE</td>
                                <td>BNE</td>
                            </tr>
                            <tr>
                                <td>Beef Island, Tortola</td>
                                <td>EIS</td>
                                <td>EIS</td>
                                <td>Bristol</td>
                                <td>BRS</td>
                                <td>BRS</td>
                            </tr>
                            <tr>
                                <td>Beijing</td>
                                <td>BJS</td>
                                <td>BJS</td>
                                <td>Brownsville</td>
                                <td>BRO</td>
                                <td>BRO</td>
                            </tr>
                            <tr>
                                <td>Beijing</td>
                                <td>BJS</td>
                                <td>PEK</td>
                                <td>Brussels</td>
                                <td>BRU</td>
                                <td>BRU</td>
                            </tr>
                            <tr>
                                <td>Beijing, Nanyuan Airport</td>
                                <td>BJS</td>
                                <td>NAY</td>
                                <td>Bucaramanga</td>
                                <td>BGA</td>
                                <td>BGA</td>
                            </tr>
                            <tr>
                                <td>Beira</td>
                                <td>BEW</td>
                                <td>BEW</td>
                                <td>Bucharest</td>
                                <td>BUH</td>
                                <td>BUH</td>
                            </tr>
                            <tr>
                                <td>Beirut</td>
                                <td>BEY</td>
                                <td>BEY</td>
                                <td>Bucharest, Baneasa</td>
                                <td>BUH</td>
                                <td>BBU</td>
                            </tr>
                            <tr>
                                <td>Belem</td>
                                <td>BEL</td>
                                <td>BEL</td>
                                <td>Bucharest, Otopeni</td>
                                <td>BUH</td>
                                <td>OTP</td>
                            </tr>
                            <tr>
                                <td>Belfast</td>
                                <td>BFS</td>
                                <td>BFS</td>
                                <td>Budapest</td>
                                <td>BUD</td>
                                <td>BUD</td>
                            </tr>
                            <tr>
                                <td>Belfast, Belfast City</td>
                                <td>BFS</td>
                                <td>BHD</td>
                                <td>Buenos Aires</td>
                                <td>BUE</td>
                                <td>BUE</td>
                            </tr>
                            <tr>
                                <td>Belgrade</td>
                                <td>BEG</td>
                                <td>BEG</td>
                                <td>Buenos Aires, Ministro Pistarini</td>
                                <td>BUE</td>
                                <td>EZE</td>
                            </tr>
                            <tr>
                                <td>Belize</td>
                                <td>BZE</td>
                                <td>BZE</td>
                                <td>Buenos Aires, Jorge Newbery</td>
                                <td>BUE</td>
                                <td>AEP</td>
                            </tr>
                            <tr>
                                <td>Belize, Municipal</td>
                                <td>BZE</td>
                                <td>TZA</td>
                                <td>Bujumbura</td>
                                <td>BJM</td>
                                <td>BJM</td>
                            </tr>
                            <tr>
                                <td>Bellingham</td>
                                <td>BLI</td>
                                <td>BLI</td>
                                <td>Bulawayo</td>
                                <td>BUQ</td>
                                <td>BUQ</td>
                            </tr>
                            <tr>
                                <td>Belo Horizonte</td>
                                <td>BHZ</td>
                                <td>BHZ</td>
                                <td>Bundaberg, Blanding</td>
                                <td>BDG</td>
                                <td>BDG</td>
                            </tr>
                            <tr>
                                <td>Benghazi</td>
                                <td>BEN</td>
                                <td>BEN</td>
                                <td>Burbank</td>
                                <td>BUR</td>
                                <td>BUR</td>
                            </tr>
                            <tr>
                                <td>Bergen</td>
                                <td>BGO</td>
                                <td>BGO</td>
                                <td>Burlington</td>
                                <td>BTV</td>
                                <td>BTV</td>
                            </tr>
                            <tr>
                                <td>Berlin</td>
                                <td>BER</td>
                                <td>BER</td>
                                <td>Bushehr</td>
                                <td>BUZ</td>
                                <td>BUZ</td>
                            </tr>
                            <tr>
                                <td>Berlin, Schonefeld</td>
                                <td>SXF</td>
                                <td>SXF</td>
                                <td>Butte</td>
                                <td>BTM</td>
                                <td>BTM</td>
                            </tr>
                            <tr>
                                <td>Berlin, Tegel</td>
                                <td>BER</td>
                                <td>TXL</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Berlin, Tempelhof</td>
                                <td>BER</td>
                                <td>THF</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Bermuda</td>
                                <td>BDA</td>
                                <td>BDA</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Bern</td>
                                <td>BRN</td>
                                <td>BRN</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Bethel</td>
                                <td>BET</td>
                                <td>BET</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Bettles</td>
                                <td>BTT</td>
                                <td>BTT</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="c" role="tabpanel" aria-labelledby="c-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Cairns</td>
                                <td>CNS</td>
                                <td>CNS</td>
                                <td>Chongqing</td>
                                <td>CKG</td>
                                <td>CKG</td>
                            </tr>
                            <tr>
                                <td>Cairo</td>
                                <td>CAI</td>
                                <td>CAI</td>
                                <td>Christchurch</td>
                                <td>CHC</td>
                                <td>CHC</td>
                            </tr>
                            <tr>
                                <td>Cajamarca</td>
                                <td>CJA</td>
                                <td>CJA</td>
                                <td>Chuathbaluk</td>
                                <td>CHU</td>
                                <td>CHU</td>
                            </tr>
                            <tr>
                                <td>Calama</td>
                                <td>CJC</td>
                                <td>CJC</td>
                                <td>Cincinnati</td>
                                <td>CVG</td>
                                <td>CVG</td>
                            </tr>
                            <tr>
                                <td>Calcutta</td>
                                <td>CCU</td>
                                <td>CCU</td>
                                <td>Ciudad Del Carmen</td>
                                <td>CME</td>
                                <td>CME</td>
                            </tr>
                            <tr>
                                <td>Calgary</td>
                                <td>YYC</td>
                                <td>YYC</td>
                                <td>Cleveland</td>
                                <td>CLE</td>
                                <td>CLE</td>
                            </tr>
                            <tr>
                                <td>Cali</td>
                                <td>CLO</td>
                                <td>CLO</td>
                                <td>Cleveland, Burke Lakefront</td>
                                <td>CLE</td>
                                <td>BKL</td>
                            </tr>
                            <tr>
                                <td>Calicut</td>
                                <td>CCJ</td>
                                <td>CCJ</td>
                                <td>Cochabamba</td>
                                <td>CBB</td>
                                <td>CBB</td>
                            </tr>
                            <tr>
                                <td>Calvi</td>
                                <td>CLY</td>
                                <td>CLY</td>
                                <td>Cochin</td>
                                <td>COK</td>
                                <td>COK</td>
                            </tr>
                            <tr>
                                <td>Cambridge Bay</td>
                                <td>YCB</td>
                                <td>YCB</td>
                                <td>Coeur D’Alene</td>
                                <td>COE</td>
                                <td>COE</td>
                            </tr>
                            <tr>
                                <td>Campo Grande</td>
                                <td>CGR</td>
                                <td>CGR</td>
                                <td>Cold Bay</td>
                                <td>CDB</td>
                                <td>CDB</td>
                            </tr>
                            <tr>
                                <td>Canaima</td>
                                <td>CAJ</td>
                                <td>CAJ</td>
                                <td>Colima</td>
                                <td>CLQ</td>
                                <td>CLQ</td>
                            </tr>
                            <tr>
                                <td>Cancun</td>
                                <td>CUN</td>
                                <td>CUN</td>
                                <td>College Station</td>
                                <td>CLL</td>
                                <td>CLL</td>
                            </tr>
                            <tr>
                                <td>Cape Girardeau</td>
                                <td>CGI</td>
                                <td>CGI</td>
                                <td>Cologne</td>
                                <td>CGN</td>
                                <td>CGN</td>
                            </tr>
                            <tr>
                                <td>Cape Town</td>
                                <td>CPT</td>
                                <td>CPT</td>
                                <td>Colombo</td>
                                <td>CMB</td>
                                <td>CMB</td>
                            </tr>
                            <tr>
                                <td>Caracas</td>
                                <td>CCS</td>
                                <td>CCS</td>
                                <td>Colorado Springs</td>
                                <td>COS</td>
                                <td>COS</td>
                            </tr>
                            <tr>
                                <td>Cardiff</td>
                                <td>CWL</td>
                                <td>CWL</td>
                                <td>Columbia</td>
                                <td>CAE</td>
                                <td>CAE</td>
                            </tr>
                            <tr>
                                <td>Carlsbad</td>
                                <td>CNM</td>
                                <td>CNM</td>
                                <td>Columbia</td>
                                <td>COU</td>
                                <td>COU</td>
                            </tr>
                            <tr>
                                <td>Cartagena</td>
                                <td>CTG</td>
                                <td>CTG</td>
                                <td>Columbus</td>
                                <td>CMH</td>
                                <td>CMH</td>
                            </tr>
                            <tr>
                                <td>Carupano</td>
                                <td>CUP</td>
                                <td>CUP</td>
                                <td>Columbus</td>
                                <td>CSG</td>
                                <td>CSG</td>
                            </tr>
                            <tr>
                                <td>Casablanca</td>
                                <td>CAS</td>
                                <td>AAA</td>
                                <td>Columbus</td>
                                <td>UBS</td>
                                <td>UBS</td>
                            </tr>
                            <tr>
                                <td>Casablanca, Mohamed V</td>
                                <td>CAS</td>
                                <td>CMN</td>
                                <td>Conakry</td>
                                <td>CKY</td>
                                <td>CKY</td>
                            </tr>
                            <tr>
                                <td>Casablanca, Anfa</td>
                                <td>CAS</td>
                                <td>CAS</td>
                                <td>Concepcion</td>
                                <td>CCP</td>
                                <td>CCP</td>
                            </tr>
                            <tr>
                                <td>Casper</td>
                                <td>CPR</td>
                                <td>CPR</td>
                                <td>Copenhagen</td>
                                <td>CPH</td>
                                <td>CPH</td>
                            </tr>
                            <tr>
                                <td>Catania</td>
                                <td>CTA</td>
                                <td>CTA</td>
                                <td>Copenhagen, Roskilde</td>
                                <td>CPH</td>
                                <td>RKE</td>
                            </tr>
                            <tr>
                                <td>Cayenne</td>
                                <td>CAY</td>
                                <td>CAY</td>
                                <td>Copiapo</td>
                                <td>CPO</td>
                                <td>CPO</td>
                            </tr>
                            <tr>
                                <td>Cebu</td>
                                <td>CEB</td>
                                <td>CEB</td>
                                <td>Cordova</td>
                                <td>CDV</td>
                                <td>CDV</td>
                            </tr>
                            <tr>
                                <td>Cedar City</td>
                                <td>CDC</td>
                                <td>CDC</td>
                                <td>Cork</td>
                                <td>ORK</td>
                                <td>ORK</td>
                            </tr>
                            <tr>
                                <td>Cedar Rapids / Iowa City</td>
                                <td>CID</td>
                                <td>CID</td>
                                <td>Corning, Elmira</td>
                                <td>ELM</td>
                                <td>ELM</td>
                            </tr>
                            <tr>
                                <td>Chachapoyas</td>
                                <td>CHH</td>
                                <td>CHH</td>
                                <td>Coro</td>
                                <td>CZE</td>
                                <td>CZE</td>
                            </tr>
                            <tr>
                                <td>Chalkyits</td>
                                <td>CIK</td>
                                <td>CIK</td>
                                <td>Corpus Christie</td>
                                <td>CRP</td>
                                <td>CRP</td>
                            </tr>
                            <tr>
                                <td>Champaign</td>
                                <td>CMI</td>
                                <td>CMI</td>
                                <td>Corpus Christie, Cabaniss Field</td>
                                <td>CRP</td>
                                <td>NGW</td>
                            </tr>
                            <tr>
                                <td>Changchun</td>
                                <td>CGQ</td>
                                <td>CGQ</td>
                                <td>Corpus Christie, Cuddihy Field</td>
                                <td>CRP</td>
                                <td>CUX</td>
                            </tr>
                            <tr>
                                <td>Changsha</td>
                                <td>CSX</td>
                                <td>CSX</td>
                                <td>Cotonou</td>
                                <td>COO</td>
                                <td>COO</td>
                            </tr>
                            <tr>
                                <td>Charleston</td>
                                <td>CHS</td>
                                <td>CHS</td>
                                <td>Coyhaique</td>
                                <td>GXQ</td>
                                <td>GXQ</td>
                            </tr>
                            <tr>
                                <td>Charlotte</td>
                                <td>CLT</td>
                                <td>CLT</td>
                                <td>Cozumel</td>
                                <td>CZM</td>
                                <td>CZM</td>
                            </tr>
                            <tr>
                                <td>Chattanooga</td>
                                <td>CHA</td>
                                <td>CHA</td>
                                <td>Crokked Creek</td>
                                <td>CKD</td>
                                <td>CKD</td>
                            </tr>
                            <tr>
                                <td>Chefornak</td>
                                <td>CYF</td>
                                <td>CYF</td>
                                <td>Cruzeiro Do Sul</td>
                                <td>CZS</td>
                                <td>CZS</td>
                            </tr>
                            <tr>
                                <td>Cheju</td>
                                <td>CJU</td>
                                <td>CJU</td>
                                <td>Cuenca</td>
                                <td>CUE</td>
                                <td>CUE</td>
                            </tr>
                            <tr>
                                <td>Chengdu</td>
                                <td>CTU</td>
                                <td>CTU</td>
                                <td>Cuiaba</td>
                                <td>CGB</td>
                                <td>CGB</td>
                            </tr>
                            <tr>
                                <td>Chetumal</td>
                                <td>CTM</td>
                                <td>CTM</td>
                                <td>Culebra</td>
                                <td>CPX</td>
                                <td>CPX</td>
                            </tr>
                            <tr>
                                <td>Chevak</td>
                                <td>VAK</td>
                                <td>VAK</td>
                                <td>Culiacan</td>
                                <td>CUL</td>
                                <td>CUL</td>
                            </tr>
                            <tr>
                                <td>Chiang Mai</td>
                                <td>CNX</td>
                                <td>CNX</td>
                                <td>Cumana</td>
                                <td>CUM</td>
                                <td>CUM</td>
                            </tr>
                            <tr>
                                <td>Chicago</td>
                                <td>CHI</td>
                                <td>CHI</td>
                                <td>Curacao</td>
                                <td>CUR</td>
                                <td>CUR</td>
                            </tr>
                            <tr>
                                <td>Chicago, Merill C. Meigs</td>
                                <td>CHI</td>
                                <td>CGX</td>
                                <td>Curitiba</td>
                                <td>CWB</td>
                                <td>CWB</td>
                            </tr>
                            <tr>
                                <td>Chicago, Midway</td>
                                <td>CHI</td>
                                <td>MDW</td>
                                <td>Cusco</td>
                                <td>CUZ</td>
                                <td>CUZ</td>
                            </tr>
                            <tr>
                                <td>Chicago, O’Hare</td>
                                <td>CHI</td>
                                <td>ORD</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Chichenitza</td>
                                <td>CZA</td>
                                <td>CZA</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Chiclayo</td>
                                <td>CIX</td>
                                <td>CIX</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Chico</td>
                                <td>CIC</td>
                                <td>CIC</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Chignik</td>
                                <td>KCL</td>
                                <td>KCL</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Chihuahua</td>
                                <td>CUU</td>
                                <td>CUU</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Chisholm</td>
                                <td>HIB</td>
                                <td>HIB</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Chittagong</td>
                                <td>CGP</td>
                                <td>CGP</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="d" role="tabpanel" aria-labelledby="d-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Dakar</td>
                                <td>DKR</td>
                                <td>DKR</td>
                                <td>Detroit</td>
                                <td>DTT</td>
                                <td>DTW</td>
                            </tr>
                            <tr>
                                <td>Dalaman</td>
                                <td>DLM</td>
                                <td>DLM</td>
                                <td>Detroit City</td>
                                <td>DTT</td>
                                <td>DET</td>
                            </tr>
                            <tr>
                                <td>Dalian</td>
                                <td>DLC</td>
                                <td>DLC</td>
                                <td>Detroit, Willow Run</td>
                                <td>DTT</td>
                                <td>YIP</td>
                            </tr>
                            <tr>
                                <td>Dallas/Ft. Worth</td>
                                <td>DFW</td>
                                <td>DFW</td>
                                <td>Dhahran</td>
                                <td>DHA</td>
                                <td>DHA</td>
                            </tr>
                            <tr>
                                <td>Dallas, Love Field</td>
                                <td>DAL</td>
                                <td>DAL</td>
                                <td>Dhaka</td>
                                <td>DAC</td>
                                <td>DAC</td>
                            </tr>
                            <tr>
                                <td>Damascus</td>
                                <td>DAM</td>
                                <td>DAM</td>
                                <td>Dillingham</td>
                                <td>DLG</td>
                                <td>DLG</td>
                            </tr>
                            <tr>
                                <td>Danville</td>
                                <td>DNV</td>
                                <td>DNV</td>
                                <td>Djerba</td>
                                <td>DJE</td>
                                <td>DJE</td>
                            </tr>
                            <tr>
                                <td>Dar Es Salaam</td>
                                <td>DAR</td>
                                <td>DAR</td>
                                <td>Djibouti</td>
                                <td>JIB</td>
                                <td>JIB</td>
                            </tr>
                            <tr>
                                <td>Darwin</td>
                                <td>DRW</td>
                                <td>DRW</td>
                                <td>Doha</td>
                                <td>DOH</td>
                                <td>DOH</td>
                            </tr>
                            <tr>
                                <td>Davao</td>
                                <td>DVO</td>
                                <td>DVO</td>
                                <td>Dominica, Cane Field</td>
                                <td>DOM</td>
                                <td>DCF</td>
                            </tr>
                            <tr>
                                <td>Dayton</td>
                                <td>DAY</td>
                                <td>DAY</td>
                                <td>Dominica, Melville Hall</td>
                                <td>DOM</td>
                                <td>DOM</td>
                            </tr>
                            <tr>
                                <td>Daytona Beach</td>
                                <td>DAB</td>
                                <td>DAB</td>
                                <td>Dothan</td>
                                <td>DHN</td>
                                <td>DHN</td>
                            </tr>
                            <tr>
                                <td>Decatur</td>
                                <td>DEC</td>
                                <td>DEC</td>
                                <td>Douala</td>
                                <td>DLA</td>
                                <td>DLA</td>
                            </tr>
                            <tr>
                                <td>Deer Lake</td>
                                <td>YDF</td>
                                <td>YDF</td>
                                <td>Dresden</td>
                                <td>DRS</td>
                                <td>DRS</td>
                            </tr>
                            <tr>
                                <td>Delhi</td>
                                <td>DEL</td>
                                <td>DEL</td>
                                <td>Dubai</td>
                                <td>DXB</td>
                                <td>DXB</td>
                            </tr>
                            <tr>
                                <td>Delta</td>
                                <td>DTA</td>
                                <td>DTA</td>
                                <td>Dublin</td>
                                <td>DUB</td>
                                <td>DUB</td>
                            </tr>
                            <tr>
                                <td>Denver</td>
                                <td>DEN</td>
                                <td>DEN</td>
                                <td>Duluth</td>
                                <td>DLH</td>
                                <td>DLH</td>
                            </tr>
                            <tr>
                                <td>Des Moines</td>
                                <td>DSM</td>
                                <td>DSM</td>
                                <td>Durango</td>
                                <td>DGO</td>
                                <td>DGO</td>
                            </tr>
                            <tr>
                                <td>Detroit</td>
                                <td>DTT</td>
                                <td>DTT</td>
                                <td>Durango</td>
                                <td>DRO</td>
                                <td>DRO</td>
                            </tr>
                            <tr>
                                <td>Detroit</td>
                                <td>DTT</td>
                                <td>DTW</td>
                                <td>Durban</td>
                                <td>DUR</td>
                                <td>DUR</td>
                            </tr>
                            <tr>
                                <td>Detroit City</td>
                                <td>DTT</td>
                                <td>DET</td>
                                <td>Dusseldorf</td>
                                <td>DUS</td>
                                <td>DUS</td>
                            </tr>
                            <tr>
                                <td>Detroit, Willow Run</td>
                                <td>DTT</td>
                                <td>YIP</td>
                                <td>Dutch Harbor</td>
                                <td>DUT</td>
                                <td>DUT</td>
                            </tr>
                            <tr>
                                <td>Dhahran</td>
                                <td>DHA</td>
                                <td>DHA</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="e" role="tabpanel" aria-labelledby="e-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>East London</td>
                                <td>ELS</td>
                                <td>ELS</td>
                                <td>Enschede</td>
                                <td>ENS</td>
                                <td>ENS</td>
                            </tr>
                            <tr>
                                <td>East Midlands</td>
                                <td>EMA</td>
                                <td>EMA</td>
                                <td>Entebbe</td>
                                <td>EBB</td>
                                <td>EBB</td>
                            </tr>
                            <tr>
                                <td>Easter Island</td>
                                <td>IPC</td>
                                <td>IPC</td>
                                <td>Ercan</td>
                                <td>ECN</td>
                                <td>ECN</td>
                            </tr>
                            <tr>
                                <td>Edinburgh</td>
                                <td>EDI</td>
                                <td>EDI</td>
                                <td>Erevan</td>
                                <td>EVN</td>
                                <td>EVN</td>
                            </tr>
                            <tr>
                                <td>Edmonton</td>
                                <td>YEA</td>
                                <td>YEA</td>
                                <td>Erfurt</td>
                                <td>ERF</td>
                                <td>ERF</td>
                            </tr>
                            <tr>
                                <td>Edmonton, Albert Int’l</td>
                                <td>YEA</td>
                                <td>YEG</td>
                                <td>Erie</td>
                                <td>ERI</td>
                                <td>ERI</td>
                            </tr>
                            <tr>
                                <td>Edmonton, Municipal</td>
                                <td>YEA</td>
                                <td>YXD</td>
                                <td>Eugene</td>
                                <td>EUG</td>
                                <td>EUG</td>
                            </tr>
                            <tr>
                                <td>Edmonton, Namao Field</td>
                                <td>YEA</td>
                                <td>YED</td>
                                <td>Evansville</td>
                                <td>EVV</td>
                                <td>EVV</td>
                            </tr>
                            <tr>
                                <td>Eek</td>
                                <td>EEK</td>
                                <td>EEK</td>
                                <td>Evenes</td>
                                <td>EVE</td>
                                <td>EVE</td>
                            </tr>
                            <tr>
                                <td>Eglin Afb/Valparaiso</td>
                                <td>VPS</td>
                                <td>VPS</td>
                                <td>Exeter</td>
                                <td>EXT</td>
                                <td>EXT</td>
                            </tr>
                            <tr>
                                <td>Eindhoven</td>
                                <td>EIN</td>
                                <td>EIN</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>El Paso</td>
                                <td>ELP</td>
                                <td>ELP</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>El Salvador</td>
                                <td>ESR</td>
                                <td>ESR</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Elat</td>
                                <td>ETH</td>
                                <td>ETH</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Elko</td>
                                <td>EKO</td>
                                <td>EKO</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Ely</td>
                                <td>ELY</td>
                                <td>ELY</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="f" role="tabpanel" aria-labelledby="f-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Fairbanks</td>
                                <td>FAI</td>
                                <td>FAI</td>
                                <td>Frankfurt</td>
                                <td>FRA</td>
                                <td>FRA</td>
                            </tr>
                            <tr>
                                <td>Fall River, New Bedford</td>
                                <td>EWB</td>
                                <td>EWB</td>
                                <td>Fredericton</td>
                                <td>YFC</td>
                                <td>YFC</td>
                            </tr>
                            <tr>
                                <td>False Pass</td>
                                <td>KFP</td>
                                <td>KFP</td>
                                <td>Freeport</td>
                                <td>FPO</td>
                                <td>FPO</td>
                            </tr>
                            <tr>
                                <td>Fargo</td>
                                <td>FAR</td>
                                <td>FAR</td>
                                <td>Freetown</td>
                                <td>FNA</td>
                                <td>FNA</td>
                            </tr>
                            <tr>
                                <td>Faro</td>
                                <td>FAO</td>
                                <td>FAO</td>
                                <td>Freetown, Hastings</td>
                                <td>FNA</td>
                                <td>HGS</td>
                            </tr>
                            <tr>
                                <td>Fayetteville</td>
                                <td>FAY</td>
                                <td>FAY</td>
                                <td>Fresno</td>
                                <td>FAT</td>
                                <td>FAT</td>
                            </tr>
                            <tr>
                                <td>Fayetteville</td>
                                <td>FYV</td>
                                <td>FYV</td>
                                <td>Friedrichshafen</td>
                                <td>FDH</td>
                                <td>FDH</td>
                            </tr>
                            <tr>
                                <td>Fez</td>
                                <td>FEZ</td>
                                <td>FEZ</td>
                                <td>Ft de France</td>
                                <td>FDF</td>
                                <td>FDF</td>
                            </tr>
                            <tr>
                                <td>Fillmore</td>
                                <td>FIL</td>
                                <td>FIL</td>
                                <td>Ft Pierce</td>
                                <td>FPR</td>
                                <td>FPR</td>
                            </tr>
                            <tr>
                                <td>Flagstaff</td>
                                <td>FLG</td>
                                <td>FLG</td>
                                <td>Ft Simpson</td>
                                <td>YFS</td>
                                <td>YFS</td>
                            </tr>
                            <tr>
                                <td>Flint</td>
                                <td>FNT</td>
                                <td>FNT</td>
                                <td>Ft Smith</td>
                                <td>FSM</td>
                                <td>FSM</td>
                            </tr>
                            <tr>
                                <td>Florence</td>
                                <td>FLR</td>
                                <td>FLR</td>
                                <td>Ft Wayne</td>
                                <td>FWA</td>
                                <td>FWA</td>
                            </tr>
                            <tr>
                                <td>Florence</td>
                                <td>MSL</td>
                                <td>MSL</td>
                                <td>Ft Yukon</td>
                                <td>FYU</td>
                                <td>FYU</td>
                            </tr>
                            <tr>
                                <td>Flores</td>
                                <td>FRS</td>
                                <td>FRS</td>
                                <td>Fukuoka</td>
                                <td>FUK</td>
                                <td>FUK</td>
                            </tr>
                            <tr>
                                <td>Fort Chima</td>
                                <td>YVP</td>
                                <td>YVP</td>
                                <td>Funchal</td>
                                <td>FNC</td>
                                <td>FNC</td>
                            </tr>
                            <tr>
                                <td>Fort Myers</td>
                                <td>FMY</td>
                                <td>FMY</td>
                                <td>Fuzhou</td>
                                <td>FOC</td>
                                <td>FOC</td>
                            </tr>
                            <tr>
                                <td>Fort Nelson</td>
                                <td>YYE</td>
                                <td>YYE</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Fort St. John</td>
                                <td>YXJ</td>
                                <td>YXJ</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Fortaleza</td>
                                <td>FOR</td>
                                <td>FOR</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="g" role="tabpanel" aria-labelledby="g-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Gainesvile</td>
                                <td>GNV</td>
                                <td>GNV</td>
                                <td>Great Falls</td>
                                <td>GTF</td>
                                <td>GTF</td>
                            </tr>
                            <tr>
                                <td>Galena</td>
                                <td>GAL</td>
                                <td>GAL</td>
                                <td>Green Bay</td>
                                <td>GRB</td>
                                <td>GRB</td>
                            </tr>
                            <tr>
                                <td>Garoua</td>
                                <td>GOU</td>
                                <td>GOU</td>
                                <td>Greensboro</td>
                                <td>GSO</td>
                                <td>GSO</td>
                            </tr>
                            <tr>
                                <td>Gassim</td>
                                <td>ELQ</td>
                                <td>ELQ</td>
                                <td>Greenville</td>
                                <td>GLH</td>
                                <td>GLH</td>
                            </tr>
                            <tr>
                                <td>Gauhati</td>
                                <td>GAU</td>
                                <td>GAU</td>
                                <td>Greenville</td>
                                <td>GSP</td>
                                <td>GSP</td>
                            </tr>
                            <tr>
                                <td>Gemena</td>
                                <td>GMA</td>
                                <td>GMA</td>
                                <td>Greenville</td>
                                <td>PGV</td>
                                <td>PGV</td>
                            </tr>
                            <tr>
                                <td>Geneva</td>
                                <td>GVA</td>
                                <td>GVA</td>
                                <td>Grenada</td>
                                <td>GND</td>
                                <td>GND</td>
                            </tr>
                            <tr>
                                <td>Genoa</td>
                                <td>GOA</td>
                                <td>GOA</td>
                                <td>Grenoble</td>
                                <td>GNB</td>
                                <td>GNB</td>
                            </tr>
                            <tr>
                                <td>Gladewater, Longview</td>
                                <td>GGG</td>
                                <td>GGG</td>
                                <td>Groningen</td>
                                <td>GRQ</td>
                                <td>GRQ</td>
                            </tr>
                            <tr>
                                <td>Glasgow</td>
                                <td>GLA</td>
                                <td>GLA</td>
                                <td>Guadalajara</td>
                                <td>GDL</td>
                                <td>GDL</td>
                            </tr>
                            <tr>
                                <td>Glasgow, Prestwick</td>
                                <td>GLA</td>
                                <td>PIK</td>
                                <td>Guam</td>
                                <td>GUM</td>
                                <td>GUM</td>
                            </tr>
                            <tr>
                                <td>Goma</td>
                                <td>GOM</td>
                                <td>GOM</td>
                                <td>Guangzhou</td>
                                <td>CAN</td>
                                <td>CAN</td>
                            </tr>
                            <tr>
                                <td>Goodnew Bay</td>
                                <td>GNU</td>
                                <td>GNU</td>
                                <td>Guatemala City</td>
                                <td>GUA</td>
                                <td>GUA</td>
                            </tr>
                            <tr>
                                <td>Goose Bay</td>
                                <td>YYR</td>
                                <td>YYR</td>
                                <td>Guayaquil</td>
                                <td>GYE</td>
                                <td>GYE</td>
                            </tr>
                            <tr>
                                <td>Goroka</td>
                                <td>GKA</td>
                                <td>GKA</td>
                                <td>Guernsey</td>
                                <td>GCI</td>
                                <td>GCI</td>
                            </tr>
                            <tr>
                                <td>Gothenburg</td>
                                <td>GOT</td>
                                <td>GOT</td>
                                <td>Guilin</td>
                                <td>KWL</td>
                                <td>KWL</td>
                            </tr>
                            <tr>
                                <td>Gran Canaria</td>
                                <td>LPA</td>
                                <td>LPA</td>
                                <td>Guiyang</td>
                                <td>KWE</td>
                                <td>KWE</td>
                            </tr>
                            <tr>
                                <td>Grand Cayman</td>
                                <td>GCM</td>
                                <td>GCM</td>
                                <td>Gulfport</td>
                                <td>GPT</td>
                                <td>GPT</td>
                            </tr>
                            <tr>
                                <td>Grand Fork</td>
                                <td>GFK</td>
                                <td>GFK</td>
                                <td>Gunnison</td>
                                <td>GUC</td>
                                <td>GUC</td>
                            </tr>
                            <tr>
                                <td>Grand Rapids</td>
                                <td>GRR</td>
                                <td>GRR</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Grand Turk</td>
                                <td>GDT</td>
                                <td>GDT</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Grande Prairie</td>
                                <td>YQU</td>
                                <td>YQU</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Grayling</td>
                                <td>KGX</td>
                                <td>KGX</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Graz</td>
                                <td>GRZ</td>
                                <td>GRZ</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="h" role="tabpanel" aria-labelledby="h-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Hagen</td>
                                <td>HAG</td>
                                <td>HAG</td>
                                <td>Hilo</td>
                                <td>ITO</td>
                                <td>ITO</td>
                            </tr>
                            <tr>
                                <td>Haikou</td>
                                <td>HAK</td>
                                <td>HAK</td>
                                <td>Hiroshima</td>
                                <td>HIJ</td>
                                <td>HIJ</td>
                            </tr>
                            <tr>
                                <td>Hail</td>
                                <td>HAS</td>
                                <td>HAS</td>
                                <td>Ho Chi Minh City</td>
                                <td>SGN</td>
                                <td>SGN</td>
                            </tr>
                            <tr>
                                <td>Hakodate</td>
                                <td>HKD</td>
                                <td>HKD</td>
                                <td>Hohhot</td>
                                <td>HET</td>
                                <td>HET</td>
                            </tr>
                            <tr>
                                <td>Halifax</td>
                                <td>YHZ</td>
                                <td>YHZ</td>
                                <td>Holy Cross</td>
                                <td>HCR</td>
                                <td>HCR</td>
                            </tr>
                            <tr>
                                <td>Hall Beach</td>
                                <td>YUX</td>
                                <td>YUX</td>
                                <td>Homer</td>
                                <td>HOM</td>
                                <td>HOM</td>
                            </tr>
                            <tr>
                                <td>Hamburg</td>
                                <td>HAM</td>
                                <td>HAM</td>
                                <td>Hong Kong</td>
                                <td>HKG</td>
                                <td>HKG</td>
                            </tr>
                            <tr>
                                <td>Hamilton</td>
                                <td>YHM</td>
                                <td>YHM</td>
                                <td>Honolulu</td>
                                <td>HNL</td>
                                <td>HNL</td>
                            </tr>
                            <tr>
                                <td>Hampton / Williamsburg</td>
                                <td>PHF</td>
                                <td>PHF</td>
                                <td>Hoolehua</td>
                                <td>MKK</td>
                                <td>MKK</td>
                            </tr>
                            <tr>
                                <td>Hangzhou</td>
                                <td>HGH</td>
                                <td>HGH</td>
                                <td>Hooper Bay</td>
                                <td>HPB</td>
                                <td>HPB</td>
                            </tr>
                            <tr>
                                <td>Hanoi</td>
                                <td>HAN</td>
                                <td>HAN</td>
                                <td>Hoskins</td>
                                <td>HKN</td>
                                <td>HKN</td>
                            </tr>
                            <tr>
                                <td>Hanover</td>
                                <td>HAJ</td>
                                <td>HAJ</td>
                                <td>Houston</td>
                                <td>HOU</td>
                                <td>HOU</td>
                            </tr>
                            <tr>
                                <td>Harare</td>
                                <td>HRE</td>
                                <td>HRE</td>
                                <td>Houston, Intercontinental</td>
                                <td>HOU</td>
                                <td>IAH</td>
                            </tr>
                            <tr>
                                <td>Harbin</td>
                                <td>HRB</td>
                                <td>HRB</td>
                                <td>Houston, Hull Field</td>
                                <td>HOU</td>
                                <td>SGR</td>
                            </tr>
                            <tr>
                                <td>Harlingen</td>
                                <td>HRL</td>
                                <td>HRL</td>
                                <td>Hughes</td>
                                <td>HUS</td>
                                <td>HUS</td>
                            </tr>
                            <tr>
                                <td>Harrisburg</td>
                                <td>HAR</td>
                                <td>HAR</td>
                                <td>Humberside</td>
                                <td>HUY</td>
                                <td>HUY</td>
                            </tr>
                            <tr>
                                <td>Hartford</td>
                                <td>HFD</td>
                                <td>HFD</td>
                                <td>Huntsville</td>
                                <td>HSV</td>
                                <td>HSV</td>
                            </tr>
                            <tr>
                                <td>Hartford, Barnes</td>
                                <td>HFD</td>
                                <td>BNH</td>
                                <td>Huslia</td>
                                <td>HSL</td>
                                <td>HSL</td>
                            </tr>
                            <tr>
                                <td>Hartford, Bradford</td>
                                <td>HFD</td>
                                <td>BDL</td>
                                <td>Hyannis</td>
                                <td>HYA</td>
                                <td>HYA</td>
                            </tr>
                            <tr>
                                <td>Hat Yai</td>
                                <td>HDY</td>
                                <td>HDY</td>
                                <td>Hyderabad</td>
                                <td>HYD</td>
                                <td>HYD</td>
                            </tr>
                            <tr>
                                <td>Haugesund</td>
                                <td>HAU</td>
                                <td>HAU</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Havana</td>
                                <td>HAV</td>
                                <td>HAV</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Hay River</td>
                                <td>YHY</td>
                                <td>YHY</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Hefei</td>
                                <td>HFE</td>
                                <td>HFE</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Helena</td>
                                <td>HLN</td>
                                <td>HLN</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Helsingborg</td>
                                <td>AGH</td>
                                <td>AGH</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Helsinki</td>
                                <td>HEL</td>
                                <td>HEL</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Heraklion</td>
                                <td>HER</td>
                                <td>HER</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Hermosillo</td>
                                <td>HMO</td>
                                <td>HMO</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="i" role="tabpanel" aria-labelledby="i-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Iguassu Falls</td>
                                <td>IGU</td>
                                <td>IGU</td>
                                <td>Istanbul</td>
                                <td>IST</td>
                                <td>IST</td>
                            </tr>
                            <tr>
                                <td>Iliamna</td>
                                <td>ILI</td>
                                <td>ILI</td>
                                <td>Islip, Long Island Macarthur</td>
                                <td>ISP</td>
                                <td>ISP</td>
                            </tr>
                            <tr>
                                <td>Indianapolis</td>
                                <td>IND</td>
                                <td>IND</td>
                                <td>Ithaca</td>
                                <td>ITH</td>
                                <td>ITH</td>
                            </tr>
                            <tr>
                                <td>Innsbruck</td>
                                <td>INN</td>
                                <td>INN</td>
                                <td>Ivanoff Bay</td>
                                <td>KIB</td>
                                <td>KIB</td>
                            </tr>
                            <tr>
                                <td>Inuvik</td>
                                <td>YEV</td>
                                <td>YEV</td>
                                <td>Izmir</td>
                                <td>IZM</td>
                                <td>IZM</td>
                            </tr>
                            <tr>
                                <td>Ipoh</td>
                                <td>IPH</td>
                                <td>IPH</td>
                                <td>Izmir, Adnan Menderes</td>
                                <td>IZM</td>
                                <td>ADB</td>
                            </tr>
                            <tr>
                                <td>Iqaluit</td>
                                <td>YFB</td>
                                <td>YFB</td>
                                <td>Izmir, Cigli Military</td>
                                <td>IZM</td>
                                <td>IGL</td>
                            </tr>
                            <tr>
                                <td>Iquique</td>
                                <td>IQQ</td>
                                <td>IQQ</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Iron Mountain</td>
                                <td>IMT</td>
                                <td>IMT</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Isfahan</td>
                                <td>IFN</td>
                                <td>IFN</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Isiro</td>
                                <td>IRP</td>
                                <td>IRP</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Islamabad</td>
                                <td>ISB</td>
                                <td>ISB</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Isles of Scil, St. Mary’s</td>
                                <td>ISC</td>
                                <td>ISC</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Isles of Scil, Tresco</td>
                                <td>ISC</td>
                                <td>TSO</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="j" role="tabpanel" aria-labelledby="j-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Jackson</td>
                                <td>JAC</td>
                                <td>JAC</td>
                                <td>Jinan</td>
                                <td>TNA</td>
                                <td>TNA</td>
                            </tr>
                            <tr>
                                <td>Jackson</td>
                                <td>JAN</td>
                                <td>JAN</td>
                                <td>Johannesburg</td>
                                <td>JNB</td>
                                <td>JNB</td>
                            </tr>
                            <tr>
                                <td>Jacksonville</td>
                                <td>JAX</td>
                                <td>JAX</td>
                                <td>Johnston Island</td>
                                <td>JON</td>
                                <td>JON</td>
                            </tr>
                            <tr>
                                <td>Jaipur</td>
                                <td>JAI</td>
                                <td>JAI</td>
                                <td>Johor Bahru</td>
                                <td>JHB</td>
                                <td>JHB</td>
                            </tr>
                            <tr>
                                <td>Jakarta</td>
                                <td>JKT</td>
                                <td>CGK</td>
                                <td>Jonkoping</td>
                                <td>JKG</td>
                                <td>JKG</td>
                            </tr>
                            <tr>
                                <td>Jakarta</td>
                                <td>JKT</td>
                                <td>JKT</td>
                                <td>Juanjui</td>
                                <td>JJI</td>
                                <td>JJI</td>
                            </tr>
                            <tr>
                                <td>Jakarta, Halim Perdana Kusuma</td>
                                <td>JKT</td>
                                <td>HLP</td>
                                <td>Juba</td>
                                <td>JUB</td>
                                <td>JUB</td>
                            </tr>
                            <tr>
                                <td>Janesville</td>
                                <td>JVL</td>
                                <td>JVL</td>
                                <td>Juliaca</td>
                                <td>JUL</td>
                                <td>JUL</td>
                            </tr>
                            <tr>
                                <td>Jeddah</td>
                                <td>JED</td>
                                <td>JED</td>
                                <td>Juneau</td>
                                <td>JNU</td>
                                <td>JNU</td>
                            </tr>
                            <tr>
                                <td>Jersey</td>
                                <td>JER</td>
                                <td>JER</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="k" role="tabpanel" aria-labelledby="k-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Kabul</td>
                                <td>KBL</td>
                                <td>KBL</td>
                                <td>King Cover</td>
                                <td>KVC</td>
                                <td>KVC</td>
                            </tr>
                            <tr>
                                <td>Kaduna</td>
                                <td>KAD</td>
                                <td>KAD</td>
                                <td>King Salm</td>
                                <td>AKN</td>
                                <td>AKN</td>
                            </tr>
                            <tr>
                                <td>Kagoshima</td>
                                <td>KOJ</td>
                                <td>KOJ</td>
                                <td>Kingston</td>
                                <td>KIN</td>
                                <td>KIN</td>
                            </tr>
                            <tr>
                                <td>Kahului</td>
                                <td>OGG</td>
                                <td>OGG</td>
                                <td>Kingston, Tinson</td>
                                <td>KIN</td>
                                <td>KTP</td>
                            </tr>
                            <tr>
                                <td>Kailua</td>
                                <td>KOA</td>
                                <td>KOA</td>
                                <td>Kinshasa</td>
                                <td>FIH</td>
                                <td>FIH</td>
                            </tr>
                            <tr>
                                <td>Kalamazoo</td>
                                <td>AZO</td>
                                <td>AZO</td>
                                <td>Kipnuk</td>
                                <td>KPN</td>
                                <td>KPN</td>
                            </tr>
                            <tr>
                                <td>Kalispell</td>
                                <td>FCA</td>
                                <td>FCA</td>
                                <td>Kiruna</td>
                                <td>KRN</td>
                                <td>KRN</td>
                            </tr>
                            <tr>
                                <td>Kalskag</td>
                                <td>KLG</td>
                                <td>KLG</td>
                                <td>Kisangani</td>
                                <td>FKI</td>
                                <td>FKI</td>
                            </tr>
                            <tr>
                                <td>Kaltag</td>
                                <td>KAL</td>
                                <td>KAL</td>
                                <td>Klagenfurt</td>
                                <td>KLU</td>
                                <td>KLU</td>
                            </tr>
                            <tr>
                                <td>Kanab</td>
                                <td>KNB</td>
                                <td>KNB</td>
                                <td>Knoxville</td>
                                <td>TYS</td>
                                <td>TYS</td>
                            </tr>
                            <tr>
                                <td>Kananga</td>
                                <td>KGA</td>
                                <td>KGA</td>
                                <td>Kochi</td>
                                <td>KCZ</td>
                                <td>KCZ</td>
                            </tr>
                            <tr>
                                <td>Kano</td>
                                <td>KAN</td>
                                <td>KAN</td>
                                <td>Kodiak</td>
                                <td>ADQ</td>
                                <td>ADQ</td>
                            </tr>
                            <tr>
                                <td>Kansas City</td>
                                <td>MKC</td>
                                <td>MKC</td>
                                <td>Komatsu</td>
                                <td>KMQ</td>
                                <td>KMQ</td>
                            </tr>
                            <tr>
                                <td>Kansas City, International</td>
                                <td>MKC</td>
                                <td>MCI</td>
                                <td>Kongiganak</td>
                                <td>KKH</td>
                                <td>KKH</td>
                            </tr>
                            <tr>
                                <td>Kaohsiung</td>
                                <td>KHH</td>
                                <td>KHH</td>
                                <td>Koror</td>
                                <td>ROR</td>
                                <td>ROR</td>
                            </tr>
                            <tr>
                                <td>Karachi</td>
                                <td>KHI</td>
                                <td>KHI</td>
                                <td>Kosrae</td>
                                <td>KSA</td>
                                <td>KSA</td>
                            </tr>
                            <tr>
                                <td>Karaganda</td>
                                <td>KGF</td>
                                <td>KGF</td>
                                <td>Kota Kinabalu</td>
                                <td>BKI</td>
                                <td>BKI</td>
                            </tr>
                            <tr>
                                <td>Karup</td>
                                <td>KRP</td>
                                <td>KRP</td>
                                <td>Kotzebue</td>
                                <td>OTZ</td>
                                <td>OTZ</td>
                            </tr>
                            <tr>
                                <td>Kasigluk</td>
                                <td>KUK</td>
                                <td>KUK</td>
                                <td>Koyukuk</td>
                                <td>KYU</td>
                                <td>KYU</td>
                            </tr>
                            <tr>
                                <td>Kassel</td>
                                <td>KSF</td>
                                <td>KSF</td>
                                <td>Krasnoyarsk</td>
                                <td>KJA</td>
                                <td>KJA</td>
                            </tr>
                            <tr>
                                <td>Kathmandu</td>
                                <td>KTM</td>
                                <td>KTM</td>
                                <td>Kristiansand</td>
                                <td>KRS</td>
                                <td>KRS</td>
                            </tr>
                            <tr>
                                <td>Kauai Is</td>
                                <td>LIH</td>
                                <td>LIH</td>
                                <td>Kuala Lumpur</td>
                                <td>KUL</td>
                                <td>KUL</td>
                            </tr>
                            <tr>
                                <td>Kenai</td>
                                <td>ENA</td>
                                <td>ENA</td>
                                <td>Kuching</td>
                                <td>KCH</td>
                                <td>KCH</td>
                            </tr>
                            <tr>
                                <td>Kerman</td>
                                <td>KER</td>
                                <td>KER</td>
                                <td>Kumamoto</td>
                                <td>KMJ</td>
                                <td>KMJ</td>
                            </tr>
                            <tr>
                                <td>Ketchikan</td>
                                <td>KTN</td>
                                <td>KTN</td>
                                <td>Kunming</td>
                                <td>KMG</td>
                                <td>KMG</td>
                            </tr>
                            <tr>
                                <td>Khabarovsk</td>
                                <td>KHV</td>
                                <td>KHV</td>
                                <td>Kuopio</td>
                                <td>KUO</td>
                                <td>KUO</td>
                            </tr>
                            <tr>
                                <td>Kiev</td>
                                <td>IEV</td>
                                <td>IEV</td>
                                <td>Kushiro</td>
                                <td>KUH</td>
                                <td>KUH</td>
                            </tr>
                            <tr>
                                <td>Kiev, Borispol</td>
                                <td>IEV</td>
                                <td>KBP</td>
                                <td>Kuujjuarap</td>
                                <td>YGW</td>
                                <td>YGW</td>
                            </tr>
                            <tr>
                                <td>Kigali</td>
                                <td>KGL</td>
                                <td>KGL</td>
                                <td>Kuwait</td>
                                <td>KWI</td>
                                <td>KWI</td>
                            </tr>
                            <tr>
                                <td>Kilimanjaro</td>
                                <td>JRO</td>
                                <td>JRO</td>
                                <td>Kwajalein</td>
                                <td>KWA</td>
                                <td>KWA</td>
                            </tr>
                            <tr>
                                <td>Killeen</td>
                                <td>ILE</td>
                                <td>ILE</td>
                                <td>Kwangju</td>
                                <td>KWJ</td>
                                <td>KWJ</td>
                            </tr>
                            <tr>
                                <td>Kimberley</td>
                                <td>KIM</td>
                                <td>KIM</td>
                                <td>Kwethluk</td>
                                <td>KWT</td>
                                <td>KWT</td>
                            </tr>
                            <tr>
                                <td>Kindu</td>
                                <td>KND</td>
                                <td>KND</td>
                                <td>Kwigillingok</td>
                                <td>KWK</td>
                                <td>KWK</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="l" role="tabpanel" aria-labelledby="l-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>La Ceiba</td>
                                <td>LCE</td>
                                <td>LCE</td>
                                <td>Lisbon</td>
                                <td>LIS</td>
                                <td>LIS</td>
                            </tr>
                            <tr>
                                <td>La Crosse</td>
                                <td>LSE</td>
                                <td>LSE</td>
                                <td>Little Rock</td>
                                <td>LIT</td>
                                <td>LIT</td>
                            </tr>
                            <tr>
                                <td>La Grande</td>
                                <td>YGL</td>
                                <td>YGL</td>
                                <td>Liverpool</td>
                                <td>LPL</td>
                                <td>LPL</td>
                            </tr>
                            <tr>
                                <td>La Paz</td>
                                <td>LPB</td>
                                <td>LPB</td>
                                <td>Livingstone</td>
                                <td>LVI</td>
                                <td>LVI</td>
                            </tr>
                            <tr>
                                <td>La Paz Mex</td>
                                <td>LAP</td>
                                <td>LAP</td>
                                <td>Ljubljana</td>
                                <td>LJU</td>
                                <td>LJU</td>
                            </tr>
                            <tr>
                                <td>Labuan</td>
                                <td>LBU</td>
                                <td>LBU</td>
                                <td>Lobito</td>
                                <td>LOB</td>
                                <td>LOB</td>
                            </tr>
                            <tr>
                                <td>Lae</td>
                                <td>LAE</td>
                                <td>LAE</td>
                                <td>Lome</td>
                                <td>LFW</td>
                                <td>LFW</td>
                            </tr>
                            <tr>
                                <td>Lafayette</td>
                                <td>LFT</td>
                                <td>LFT</td>
                                <td>London</td>
                                <td>LON</td>
                                <td>LON</td>
                            </tr>
                            <tr>
                                <td>Lagos</td>
                                <td>LOS</td>
                                <td>LOS</td>
                                <td>London</td>
                                <td>YXU</td>
                                <td>YXU</td>
                            </tr>
                            <tr>
                                <td>Laguna Beach / Sant Ana</td>
                                <td>SNA</td>
                                <td>SNA</td>
                                <td>London, Gatwick</td>
                                <td>LON</td>
                                <td>LGW</td>
                            </tr>
                            <tr>
                                <td>Lahad Datu</td>
                                <td>LDU</td>
                                <td>LDU</td>
                                <td>London, Heathrow</td>
                                <td>LON</td>
                                <td>LHR</td>
                            </tr>
                            <tr>
                                <td>Lahore</td>
                                <td>LHE</td>
                                <td>LHE</td>
                                <td>London, City Airport</td>
                                <td>LON</td>
                                <td>LCY</td>
                            </tr>
                            <tr>
                                <td>Lake Charles</td>
                                <td>LCH</td>
                                <td>LCH</td>
                                <td>London, Luton</td>
                                <td>LON</td>
                                <td>ETN</td>
                            </tr>
                            <tr>
                                <td>Lanai City</td>
                                <td>LNY</td>
                                <td>LNY</td>
                                <td>London, Stansted</td>
                                <td>LON</td>
                                <td>STN</td>
                            </tr>
                            <tr>
                                <td>Langkawi</td>
                                <td>LGK</td>
                                <td>LGK</td>
                                <td>Long Beach</td>
                                <td>LGB</td>
                                <td>LGB</td>
                            </tr>
                            <tr>
                                <td>Lansing</td>
                                <td>LAN</td>
                                <td>LAN</td>
                                <td>Loreto</td>
                                <td>LTO</td>
                                <td>LTO</td>
                            </tr>
                            <tr>
                                <td>Lanzhou</td>
                                <td>LHW</td>
                                <td>LHW</td>
                                <td>Los Angeles</td>
                                <td>LAX</td>
                                <td>LAX</td>
                            </tr>
                            <tr>
                                <td>Laredo</td>
                                <td>LRD</td>
                                <td>LRD</td>
                                <td>Los Angeles</td>
                                <td>LAX</td>
                                <td>VNY</td>
                            </tr>
                            <tr>
                                <td>Larnaca</td>
                                <td>LCA</td>
                                <td>LCA</td>
                                <td>Los Mochis</td>
                                <td>LMM</td>
                                <td>LMM</td>
                            </tr>
                            <tr>
                                <td>Las Piedras</td>
                                <td>LSP</td>
                                <td>LSP</td>
                                <td>Louisville</td>
                                <td>SDF</td>
                                <td>SDF</td>
                            </tr>
                            <tr>
                                <td>Las Vegas</td>
                                <td>LAS</td>
                                <td>LAS</td>
                                <td>Lourdes/Tarbes</td>
                                <td>LDE</td>
                                <td>LDE</td>
                            </tr>
                            <tr>
                                <td>Las Vegas, North Air Terminal</td>
                                <td>LAS</td>
                                <td>VGT</td>
                                <td>Luanda</td>
                                <td>LAD</td>
                                <td>LAD</td>
                            </tr>
                            <tr>
                                <td>Launceston</td>
                                <td>LST</td>
                                <td>LST</td>
                                <td>Lubbock</td>
                                <td>LBB</td>
                                <td>LBB</td>
                            </tr>
                            <tr>
                                <td>Lawton</td>
                                <td>LAW</td>
                                <td>LAW</td>
                                <td>Lubumbashi</td>
                                <td>FBM</td>
                                <td>FBM</td>
                            </tr>
                            <tr>
                                <td>Le Havre</td>
                                <td>LEH</td>
                                <td>LEH</td>
                                <td>Lucknow</td>
                                <td>LKO</td>
                                <td>LKO</td>
                            </tr>
                            <tr>
                                <td>Leeds</td>
                                <td>LBA</td>
                                <td>LBA</td>
                                <td>Ludwigshafen</td>
                                <td>LUD</td>
                                <td>LUD</td>
                            </tr>
                            <tr>
                                <td>Leinster</td>
                                <td>LER</td>
                                <td>LER</td>
                                <td>Lugano</td>
                                <td>LUG</td>
                                <td>LUG</td>
                            </tr>
                            <tr>
                                <td>Leipzig</td>
                                <td>LEJ</td>
                                <td>LEJ</td>
                                <td>Lulea</td>
                                <td>LLA</td>
                                <td>LLA</td>
                            </tr>
                            <tr>
                                <td>Lethbridge</td>
                                <td>YQL</td>
                                <td>YQL</td>
                                <td>Lumid Pau</td>
                                <td>LUB</td>
                                <td>LUB</td>
                            </tr>
                            <tr>
                                <td>Lhasa</td>
                                <td>LXA</td>
                                <td>LXA</td>
                                <td>Lusaka</td>
                                <td>LUN</td>
                                <td>LUN</td>
                            </tr>
                            <tr>
                                <td>Libreville</td>
                                <td>LBV</td>
                                <td>LBV</td>
                                <td>Luxembourg</td>
                                <td>LUX</td>
                                <td>LUX</td>
                            </tr>
                            <tr>
                                <td>Liege</td>
                                <td>LGG</td>
                                <td>LGG</td>
                                <td>Luxor</td>
                                <td>LXR</td>
                                <td>LXR</td>
                            </tr>
                            <tr>
                                <td>Lille</td>
                                <td>LIL</td>
                                <td>LIL</td>
                                <td>Lyon</td>
                                <td>LYS</td>
                                <td>LYS</td>
                            </tr>
                            <tr>
                                <td>Lilongwe</td>
                                <td>LLW</td>
                                <td>LLW</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Lima</td>
                                <td>LIM</td>
                                <td>LIM</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Limoges</td>
                                <td>LIG</td>
                                <td>LIG</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Lincoln</td>
                                <td>LNK</td>
                                <td>LNK</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Linz</td>
                                <td>LNZ</td>
                                <td>LNZ</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="m" role="tabpanel" aria-labelledby="m-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Maastricht</td>
                                <td>MST</td>
                                <td>MST</td>
                                <td>Miami</td>
                                <td>MIA</td>
                                <td>MIA</td>
                            </tr>
                            <tr>
                                <td>Macon</td>
                                <td>MCN</td>
                                <td>MCN</td>
                                <td>Miami, Downtown Heliport</td>
                                <td>MIA</td>
                                <td>JDM</td>
                            </tr>
                            <tr>
                                <td>Madison</td>
                                <td>MSN</td>
                                <td>MSN</td>
                                <td>Miami, Sea Plane Base</td>
                                <td>MIA</td>
                                <td>MPB</td>
                            </tr>
                            <tr>
                                <td>Madras</td>
                                <td>MAA</td>
                                <td>MAA</td>
                                <td>Midland</td>
                                <td>MAF</td>
                                <td>MAF</td>
                            </tr>
                            <tr>
                                <td>Madrid</td>
                                <td>MAD</td>
                                <td>MAD</td>
                                <td>Milan</td>
                                <td>MIL</td>
                                <td>MIL</td>
                            </tr>
                            <tr>
                                <td>Magadan</td>
                                <td>GDX</td>
                                <td>GDX</td>
                                <td>Milan, Linate</td>
                                <td>MIL</td>
                                <td>LIN</td>
                            </tr>
                            <tr>
                                <td>Mahe Island</td>
                                <td>SEZ</td>
                                <td>SEZ</td>
                                <td>Milan, Malpensa</td>
                                <td>MIL</td>
                                <td>MXP</td>
                            </tr>
                            <tr>
                                <td>Maiduguri</td>
                                <td>MIU</td>
                                <td>MIU</td>
                                <td>Milan, Orio al Serio</td>
                                <td>MIL</td>
                                <td>BGY</td>
                            </tr>
                            <tr>
                                <td>Majuro</td>
                                <td>MAJ</td>
                                <td>MAJ</td>
                                <td>Milan, Segrate</td>
                                <td>MIL</td>
                                <td>SWK</td>
                            </tr>
                            <tr>
                                <td>Malaga</td>
                                <td>AGP</td>
                                <td>AGP</td>
                                <td>Milford</td>
                                <td>MLF</td>
                                <td>MLF</td>
                            </tr>
                            <tr>
                                <td>Male</td>
                                <td>MLE</td>
                                <td>MLE</td>
                                <td>Milwaukee</td>
                                <td>MKE</td>
                                <td>MKE</td>
                            </tr>
                            <tr>
                                <td>Malmo</td>
                                <td>MMA</td>
                                <td>MMA</td>
                                <td>Minatitlan</td>
                                <td>MTT</td>
                                <td>MTT</td>
                            </tr>
                            <tr>
                                <td>Malongo</td>
                                <td>MAL</td>
                                <td>MAL</td>
                                <td>Mineralnye</td>
                                <td>MRV</td>
                                <td>MRV</td>
                            </tr>
                            <tr>
                                <td>Malta</td>
                                <td>MLA</td>
                                <td>MLA</td>
                                <td>Minneapolis</td>
                                <td>MSP</td>
                                <td>MSP</td>
                            </tr>
                            <tr>
                                <td>Manado</td>
                                <td>MDC</td>
                                <td>MDC</td>
                                <td>Minot</td>
                                <td>MOT</td>
                                <td>MOT</td>
                            </tr>
                            <tr>
                                <td>Managua</td>
                                <td>MGA</td>
                                <td>MGA</td>
                                <td>Minsk</td>
                                <td>MSQ</td>
                                <td>MSQ</td>
                            </tr>
                            <tr>
                                <td>Manaus</td>
                                <td>MAO</td>
                                <td>MAO</td>
                                <td>Miri</td>
                                <td>MYY</td>
                                <td>MYY</td>
                            </tr>
                            <tr>
                                <td>Manchester</td>
                                <td>MAN</td>
                                <td>MAN</td>
                                <td>Missoula</td>
                                <td>MSO</td>
                                <td>MSO</td>
                            </tr>
                            <tr>
                                <td>Manchester</td>
                                <td>MHT</td>
                                <td>MHT</td>
                                <td>Miyazaki</td>
                                <td>KMI</td>
                                <td>KMI</td>
                            </tr>
                            <tr>
                                <td>Manila</td>
                                <td>MNL</td>
                                <td>MNL</td>
                                <td>Mobile</td>
                                <td>MOB</td>
                                <td>MOB</td>
                            </tr>
                            <tr>
                                <td>Manzanillo</td>
                                <td>ZLO</td>
                                <td>ZLO</td>
                                <td>Moline</td>
                                <td>MLI</td>
                                <td>MLI</td>
                            </tr>
                            <tr>
                                <td>Maputo</td>
                                <td>MPM</td>
                                <td>MPM</td>
                                <td>Mombasa</td>
                                <td>MBA</td>
                                <td>MBA</td>
                            </tr>
                            <tr>
                                <td>Maracaibo</td>
                                <td>MAR</td>
                                <td>MAR</td>
                                <td>Moncton</td>
                                <td>YQM</td>
                                <td>YQM</td>
                            </tr>
                            <tr>
                                <td>Maribor</td>
                                <td>MBX</td>
                                <td>MBX</td>
                                <td>Monroe</td>
                                <td>MLU</td>
                                <td>MLU</td>
                            </tr>
                            <tr>
                                <td>Marietta, Parkersburg</td>
                                <td>PKB</td>
                                <td>PKB</td>
                                <td>Monrovia</td>
                                <td>MLW</td>
                                <td>MLW</td>
                            </tr>
                            <tr>
                                <td>Marion</td>
                                <td>MWA</td>
                                <td>MWA</td>
                                <td>Monrovia, Roberts International</td>
                                <td>MLW</td>
                                <td>ROB</td>
                            </tr>
                            <tr>
                                <td>Marquette</td>
                                <td>MQT</td>
                                <td>MQT</td>
                                <td>Montego Bay</td>
                                <td>MBJ</td>
                                <td>MBJ</td>
                            </tr>
                            <tr>
                                <td>Marrakech</td>
                                <td>RAK</td>
                                <td>RAK</td>
                                <td>Monterrey</td>
                                <td>MTY</td>
                                <td>MTY</td>
                            </tr>
                            <tr>
                                <td>Marseille</td>
                                <td>MRS</td>
                                <td>MRS</td>
                                <td>Montevideo</td>
                                <td>MVD</td>
                                <td>MVD</td>
                            </tr>
                            <tr>
                                <td>Marshall</td>
                                <td>MLL</td>
                                <td>MLL</td>
                                <td>Montgomery</td>
                                <td>MGM</td>
                                <td>MGM</td>
                            </tr>
                            <tr>
                                <td>Martha’s Vineyard</td>
                                <td>MVY</td>
                                <td>MVY</td>
                                <td>Montpellier</td>
                                <td>MPL</td>
                                <td>MPL</td>
                            </tr>
                            <tr>
                                <td>Mashad</td>
                                <td>MHD</td>
                                <td>MHD</td>
                                <td>Montreal</td>
                                <td>YMQ</td>
                                <td>YMQ</td>
                            </tr>
                            <tr>
                                <td>Matamoros</td>
                                <td>MAM</td>
                                <td>MAM</td>
                                <td>Montreal, Dorval International</td>
                                <td>YMQ</td>
                                <td>YUL</td>
                            </tr>
                            <tr>
                                <td>Matsuyama</td>
                                <td>MYJ</td>
                                <td>MYJ</td>
                                <td>Montreal, Mirabel International</td>
                                <td>YMQ</td>
                                <td>YMX</td>
                            </tr>
                            <tr>
                                <td>Maturin</td>
                                <td>MUN</td>
                                <td>MUN</td>
                                <td>Morelia</td>
                                <td>MLM</td>
                                <td>MLM</td>
                            </tr>
                            <tr>
                                <td>Mauritius</td>
                                <td>MRU</td>
                                <td>MRU</td>
                                <td>Moroni</td>
                                <td>YVA</td>
                                <td>YVA</td>
                            </tr>
                            <tr>
                                <td>Mayaguez</td>
                                <td>MAZ</td>
                                <td>MAZ</td>
                                <td>Moroni, Hahaya International</td>
                                <td>YVA</td>
                                <td>HAH</td>
                            </tr>
                            <tr>
                                <td>Mazatlan</td>
                                <td>MZT</td>
                                <td>MZT</td>
                                <td>Moscow</td>
                                <td>MOW</td>
                                <td>MOW</td>
                            </tr>
                            <tr>
                                <td>Mbandaka</td>
                                <td>MDK</td>
                                <td>MDK</td>
                                <td>Moscow, Domodedovo</td>
                                <td>MOW</td>
                                <td>DME</td>
                            </tr>
                            <tr>
                                <td>Mbuji Mayi</td>
                                <td>MJM</td>
                                <td>MJM</td>
                                <td>Moscow, Sheremetyevo</td>
                                <td>MOW</td>
                                <td>SVO</td>
                            </tr>
                            <tr>
                                <td>Mc Allen</td>
                                <td>MFE</td>
                                <td>MFE</td>
                                <td>Moscow, Vnukovo</td>
                                <td>MOW</td>
                                <td>VKO</td>
                            </tr>
                            <tr>
                                <td>Mc Grath</td>
                                <td>MCG</td>
                                <td>MCG</td>
                                <td>Mount Hagen</td>
                                <td>HGU</td>
                                <td>HGU</td>
                            </tr>
                            <tr>
                                <td>Medan</td>
                                <td>MES</td>
                                <td>MES</td>
                                <td>Muenster</td>
                                <td>FMO</td>
                                <td>FMO</td>
                            </tr>
                            <tr>
                                <td>Medellin</td>
                                <td>MDE</td>
                                <td>MDE</td>
                                <td>Mulhouse</td>
                                <td>MLH</td>
                                <td>MLH</td>
                            </tr>
                            <tr>
                                <td>Medford</td>
                                <td>MFR</td>
                                <td>MFR</td>
                                <td>Munich</td>
                                <td>MUC</td>
                                <td>MUC</td>
                            </tr>
                            <tr>
                                <td>Medina</td>
                                <td>MED</td>
                                <td>MED</td>
                                <td>Muscat</td>
                                <td>MCT</td>
                                <td>MCT</td>
                            </tr>
                            <tr>
                                <td>Meekatharp</td>
                                <td>MKR</td>
                                <td>MKR</td>
                                <td>Muskegon</td>
                                <td>MKG</td>
                                <td>MKG</td>
                            </tr>
                            <tr>
                                <td>Mekoryuk</td>
                                <td>MYU</td>
                                <td>MYU</td>
                                <td>Myrtle Beach</td>
                                <td>MYR</td>
                                <td>MYR</td>
                            </tr>
                            <tr>
                                <td>Melbourne</td>
                                <td>MEL</td>
                                <td>MEL</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Melbourne</td>
                                <td>MLB</td>
                                <td>MLB</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Melbourne, City Heliport</td>
                                <td>MEL</td>
                                <td>KAH</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Melbourne, Essendon</td>
                                <td>MEL</td>
                                <td>MEB</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Memphis</td>
                                <td>MEM</td>
                                <td>MEM</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Mendoza</td>
                                <td>MDZ</td>
                                <td>MDZ</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Merida</td>
                                <td>MID</td>
                                <td>MID</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Merida</td>
                                <td>MRD</td>
                                <td>MRD</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Meridian</td>
                                <td>MEI</td>
                                <td>MEI</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Mexico City</td>
                                <td>MEX</td>
                                <td>MEX</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="n" role="tabpanel" aria-labelledby="n-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>N’djamena</td>
                                <td>NDJ</td>
                                <td>NDJ</td>
                                <td>Niagara Falls</td>
                                <td>IAG</td>
                                <td>IAG</td>
                            </tr>
                            <tr>
                                <td>Nadi</td>
                                <td>NAN</td>
                                <td>NAN</td>
                                <td>Niamey</td>
                                <td>NIM</td>
                                <td>NIM</td>
                            </tr>
                            <tr>
                                <td>Nagasaki</td>
                                <td>NGS</td>
                                <td>NGS</td>
                                <td>Nice</td>
                                <td>NCE</td>
                                <td>NCE</td>
                            </tr>
                            <tr>
                                <td>Nagoya</td>
                                <td>NGO</td>
                                <td>NGO</td>
                                <td>Nightmute</td>
                                <td>NME</td>
                                <td>NME</td>
                            </tr>
                            <tr>
                                <td>Nairobi</td>
                                <td>NBO</td>
                                <td>NBO</td>
                                <td>Niigata</td>
                                <td>KIJ</td>
                                <td>KIJ</td>
                            </tr>
                            <tr>
                                <td>Nairobi</td>
                                <td>NBO</td>
                                <td>WIL</td>
                                <td>Nimes</td>
                                <td>FNI</td>
                                <td>FNI</td>
                            </tr>
                            <tr>
                                <td>Nanchang</td>
                                <td>KHN</td>
                                <td>KHN</td>
                                <td>Ningbo</td>
                                <td>NGB</td>
                                <td>NGB</td>
                            </tr>
                            <tr>
                                <td>Nancy</td>
                                <td>ENC</td>
                                <td>ENC</td>
                                <td>Nis</td>
                                <td>INI</td>
                                <td>INI</td>
                            </tr>
                            <tr>
                                <td>Nanisivik</td>
                                <td>YSR</td>
                                <td>YSR</td>
                                <td>Nome</td>
                                <td>OME</td>
                                <td>OME</td>
                            </tr>
                            <tr>
                                <td>Nanjing</td>
                                <td>NKG</td>
                                <td>NKG</td>
                                <td>Norfolk</td>
                                <td>ORF</td>
                                <td>ORF</td>
                            </tr>
                            <tr>
                                <td>Nanning</td>
                                <td>NNG</td>
                                <td>NNG</td>
                                <td>Norilsk</td>
                                <td>NSK</td>
                                <td>NSK</td>
                            </tr>
                            <tr>
                                <td>Nantes</td>
                                <td>NTE</td>
                                <td>NTE</td>
                                <td>Norman Wells</td>
                                <td>YVQ</td>
                                <td>YVQ</td>
                            </tr>
                            <tr>
                                <td>Nantucket</td>
                                <td>ACK</td>
                                <td>ACK</td>
                                <td>Norrkoping</td>
                                <td>NRK</td>
                                <td>NRK</td>
                            </tr>
                            <tr>
                                <td>Napakiak</td>
                                <td>WNA</td>
                                <td>WNA</td>
                                <td>Norwich</td>
                                <td>NWI</td>
                                <td>NWI</td>
                            </tr>
                            <tr>
                                <td>Napaskiak</td>
                                <td>PKA</td>
                                <td>PKA</td>
                                <td>Nouakchott</td>
                                <td>NKC</td>
                                <td>NKC</td>
                            </tr>
                            <tr>
                                <td>Naples</td>
                                <td>APF</td>
                                <td>APF</td>
                                <td>Noumea</td>
                                <td>NOU</td>
                                <td>NOU</td>
                            </tr>
                            <tr>
                                <td>Naples</td>
                                <td>NAP</td>
                                <td>NAP</td>
                                <td>Noumea, Magenta</td>
                                <td>NOU</td>
                                <td>GEA</td>
                            </tr>
                            <tr>
                                <td>Nashville</td>
                                <td>BNA</td>
                                <td>BNA</td>
                                <td>Novosibirsk</td>
                                <td>OVB</td>
                                <td>OVB</td>
                            </tr>
                            <tr>
                                <td>Nassau</td>
                                <td>NAS</td>
                                <td>NAS</td>
                                <td>Nuevo Laredo</td>
                                <td>NLD</td>
                                <td>NLD</td>
                            </tr>
                            <tr>
                                <td>Natal</td>
                                <td>NAT</td>
                                <td>NAT</td>
                                <td>Nulato</td>
                                <td>NUL</td>
                                <td>NUL</td>
                            </tr>
                            <tr>
                                <td>Neuchatel</td>
                                <td>NEU</td>
                                <td>NEU</td>
                                <td>Nunapitchuk</td>
                                <td>NUP</td>
                                <td>NUP</td>
                            </tr>
                            <tr>
                                <td>New Bern</td>
                                <td>EWN</td>
                                <td>EWN</td>
                                <td>Nuremberg</td>
                                <td>NUE</td>
                                <td>NUE</td>
                            </tr>
                            <tr>
                                <td>New Orleans</td>
                                <td>MSY</td>
                                <td>MSY</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>New York</td>
                                <td>NYC</td>
                                <td>NYC</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>New York, John F. Kennedy</td>
                                <td>NYC</td>
                                <td>JFK</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>New York, La Guardia</td>
                                <td>NYC</td>
                                <td>LGA</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>New York, Newark</td>
                                <td>NYC</td>
                                <td>EWR</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Newburgh</td>
                                <td>SWF</td>
                                <td>SWF</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Newcastle</td>
                                <td>NCL</td>
                                <td>NCL</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Newtok</td>
                                <td>WWT</td>
                                <td>WWT</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="o" role="tabpanel" aria-labelledby="o-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Oakland</td>
                                <td>OAK</td>
                                <td>OAK</td>
                                <td>Osaka, Kansai International</td>
                                <td>OSA</td>
                                <td>KIX</td>
                            </tr>
                            <tr>
                                <td>Oaxaca</td>
                                <td>OAX</td>
                                <td>OAX</td>
                                <td>Oshkosh</td>
                                <td>OSH</td>
                                <td>OSH</td>
                            </tr>
                            <tr>
                                <td>Oita</td>
                                <td>OIT</td>
                                <td>OIT</td>
                                <td>Osijek</td>
                                <td>OSI</td>
                                <td>OSI</td>
                            </tr>
                            <tr>
                                <td>Okayama</td>
                                <td>OKJ</td>
                                <td>OKJ</td>
                                <td>Oslo</td>
                                <td>OSL</td>
                                <td>OSL</td>
                            </tr>
                            <tr>
                                <td>Okinawa</td>
                                <td>OKA</td>
                                <td>OKA</td>
                                <td>Oslo, Fornebu Airport</td>
                                <td>OSL</td>
                                <td>FBU</td>
                            </tr>
                            <tr>
                                <td>Oklahoma City</td>
                                <td>OKC</td>
                                <td>OKC</td>
                                <td>Oslo, Gardermoen</td>
                                <td>OSL</td>
                                <td>GEN</td>
                            </tr>
                            <tr>
                                <td>Omaha</td>
                                <td>OMA</td>
                                <td>OMA</td>
                                <td>Osorno</td>
                                <td>ZOS</td>
                                <td>ZOS</td>
                            </tr>
                            <tr>
                                <td>Ontario</td>
                                <td>ONT</td>
                                <td>ONT</td>
                                <td>Ostend</td>
                                <td>OST</td>
                                <td>OST</td>
                            </tr>
                            <tr>
                                <td>Oran</td>
                                <td>ORN</td>
                                <td>ORN</td>
                                <td>Ottawa</td>
                                <td>YOW</td>
                                <td>YOW</td>
                            </tr>
                            <tr>
                                <td>Orebro</td>
                                <td>ORB</td>
                                <td>ORB</td>
                                <td>Ouagadougou</td>
                                <td>OUA</td>
                                <td>OUA</td>
                            </tr>
                            <tr>
                                <td>Orlando</td>
                                <td>ORL</td>
                                <td>MCO</td>
                                <td>Oxnard/Ventura</td>
                                <td>OXR</td>
                                <td>OXR</td>
                            </tr>
                            <tr>
                                <td>Osaka</td>
                                <td>OSA</td>
                                <td>OSA</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Osaka, Itami</td>
                                <td>OSA</td>
                                <td>ITM</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="p" role="tabpanel" aria-labelledby="p-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Pago Pago</td>
                                <td>PPG</td>
                                <td>PPG</td>
                                <td>Ponce</td>
                                <td>PSE</td>
                                <td>PSE</td>
                            </tr>
                            <tr>
                                <td>Palembang</td>
                                <td>PLM</td>
                                <td>PLM</td>
                                <td>Ponta Delgada</td>
                                <td>PDL</td>
                                <td>PDL</td>
                            </tr>
                            <tr>
                                <td>Palermo</td>
                                <td>PMO</td>
                                <td>PMO</td>
                                <td>Pori</td>
                                <td>POR</td>
                                <td>POR</td>
                            </tr>
                            <tr>
                                <td>Palm Springs</td>
                                <td>PSP</td>
                                <td>PSP</td>
                                <td>Porlamar</td>
                                <td>PMV</td>
                                <td>PMV</td>
                            </tr>
                            <tr>
                                <td>Palma de Mallorca</td>
                                <td>PMI</td>
                                <td>PMI</td>
                                <td>Port au Prince</td>
                                <td>PAP</td>
                                <td>PAP</td>
                            </tr>
                            <tr>
                                <td>Panama City</td>
                                <td>PFN</td>
                                <td>PFN</td>
                                <td>Port Elizabeth</td>
                                <td>PLZ</td>
                                <td>PLZ</td>
                            </tr>
                            <tr>
                                <td>Panama City</td>
                                <td>PTY</td>
                                <td>PTY</td>
                                <td>Port Gentil</td>
                                <td>POG</td>
                                <td>POG</td>
                            </tr>
                            <tr>
                                <td>Panama City, Paitilla</td>
                                <td>PTY</td>
                                <td>PAC</td>
                                <td>Port Graham</td>
                                <td>PGM</td>
                                <td>PGM</td>
                            </tr>
                            <tr>
                                <td>Papeete</td>
                                <td>PPT</td>
                                <td>PPT</td>
                                <td>Port Harcourt</td>
                                <td>PHC</td>
                                <td>PHC</td>
                            </tr>
                            <tr>
                                <td>Paphos</td>
                                <td>PFO</td>
                                <td>PFO</td>
                                <td>Port Hedland</td>
                                <td>PHE</td>
                                <td>PHE</td>
                            </tr>
                            <tr>
                                <td>Paramaribo</td>
                                <td>PBM</td>
                                <td>PBM</td>
                                <td>Port Heiden</td>
                                <td>PTH</td>
                                <td>PTH</td>
                            </tr>
                            <tr>
                                <td>Paramaribo, Zorg En Hoop</td>
                                <td>PBM</td>
                                <td>ORG</td>
                                <td>Port Moresby</td>
                                <td>POM</td>
                                <td>POM</td>
                            </tr>
                            <tr>
                                <td>Paris</td>
                                <td>PAR</td>
                                <td>PAR</td>
                                <td>Port of Spain, Trinidad</td>
                                <td>POS</td>
                                <td>POS</td>
                            </tr>
                            <tr>
                                <td>Paris, Charles de Gaulle</td>
                                <td>PAR</td>
                                <td>CDG</td>
                                <td>Port Velho</td>
                                <td>PVH</td>
                                <td>PVH</td>
                            </tr>
                            <tr>
                                <td>Paris, Le Bourget</td>
                                <td>PAR</td>
                                <td>LBG</td>
                                <td>Port Vila</td>
                                <td>VLI</td>
                                <td>VLI</td>
                            </tr>
                            <tr>
                                <td>Paris, Orly</td>
                                <td>PAR</td>
                                <td>ORY</td>
                                <td>Portland</td>
                                <td>PDX</td>
                                <td>PDX</td>
                            </tr>
                            <tr>
                                <td>Pasco</td>
                                <td>PSC</td>
                                <td>PSC</td>
                                <td>Portland</td>
                                <td>PWM</td>
                                <td>PWM</td>
                            </tr>
                            <tr>
                                <td>Pau</td>
                                <td>PUF</td>
                                <td>PUF</td>
                                <td>Porto</td>
                                <td>OPO</td>
                                <td>OPO</td>
                            </tr>
                            <tr>
                                <td>Penang</td>
                                <td>PEN</td>
                                <td>PEN</td>
                                <td>Porto Alegre</td>
                                <td>POA</td>
                                <td>POA</td>
                            </tr>
                            <tr>
                                <td>Pensacola</td>
                                <td>PNS</td>
                                <td>PNS</td>
                                <td>Prague</td>
                                <td>PRG</td>
                                <td>PRG</td>
                            </tr>
                            <tr>
                                <td>Peoria</td>
                                <td>PIA</td>
                                <td>PIA</td>
                                <td>Presque Isle</td>
                                <td>PQI</td>
                                <td>PQI</td>
                            </tr>
                            <tr>
                                <td>Pereira</td>
                                <td>PEI</td>
                                <td>PEI</td>
                                <td>Prince George</td>
                                <td>YXS</td>
                                <td>YXS</td>
                            </tr>
                            <tr>
                                <td>Perpignan</td>
                                <td>PGF</td>
                                <td>PGF</td>
                                <td>Prince Rupert</td>
                                <td>YPR</td>
                                <td>YPR</td>
                            </tr>
                            <tr>
                                <td>Perryville</td>
                                <td>KPV</td>
                                <td>KPV</td>
                                <td>Providence</td>
                                <td>PVD</td>
                                <td>PVD</td>
                            </tr>
                            <tr>
                                <td>Perth</td>
                                <td>PER</td>
                                <td>PER</td>
                                <td>Providenciales</td>
                                <td>PLS</td>
                                <td>PLS</td>
                            </tr>
                            <tr>
                                <td>Pescara</td>
                                <td>PSR</td>
                                <td>PSR</td>
                                <td>Prudhoe Bay / Deadhorse</td>
                                <td>SCC</td>
                                <td>SCC</td>
                            </tr>
                            <tr>
                                <td>Peshawar</td>
                                <td>PEW</td>
                                <td>PEW</td>
                                <td>Pucallpa</td>
                                <td>PCL</td>
                                <td>PCL</td>
                            </tr>
                            <tr>
                                <td>Petersburg</td>
                                <td>PSG</td>
                                <td>PSG</td>
                                <td>Puebla</td>
                                <td>PBC</td>
                                <td>PBC</td>
                            </tr>
                            <tr>
                                <td>Philadelphia</td>
                                <td>PHL</td>
                                <td>PHL</td>
                                <td>Puerto Ayachucho</td>
                                <td>PYH</td>
                                <td>PYH</td>
                            </tr>
                            <tr>
                                <td>Philadelphia, North</td>
                                <td>PHL</td>
                                <td>PNE</td>
                                <td>Puerto Cabello</td>
                                <td>PBL</td>
                                <td>PBL</td>
                            </tr>
                            <tr>
                                <td>Phnom Penh</td>
                                <td>PNH</td>
                                <td>PNH</td>
                                <td>Puerto Escondido</td>
                                <td>PXM</td>
                                <td>PXM</td>
                            </tr>
                            <tr>
                                <td>Phoenix</td>
                                <td>PHX</td>
                                <td>PHX</td>
                                <td>Puerto Maldonado</td>
                                <td>PEM</td>
                                <td>PEM</td>
                            </tr>
                            <tr>
                                <td>Phoenix, Scottsdale Municipal</td>
                                <td>PHX</td>
                                <td>SCF</td>
                                <td>Puerto Montt</td>
                                <td>PMC</td>
                                <td>PMC</td>
                            </tr>
                            <tr>
                                <td>Phuket</td>
                                <td>HKT</td>
                                <td>HKT</td>
                                <td>Puerto Ordaz</td>
                                <td>PZO</td>
                                <td>PZO</td>
                            </tr>
                            <tr>
                                <td>Pierre</td>
                                <td>PIR</td>
                                <td>PIR</td>
                                <td>Puerto Plata</td>
                                <td>POP</td>
                                <td>POP</td>
                            </tr>
                            <tr>
                                <td>Pisa</td>
                                <td>PSA</td>
                                <td>PSA</td>
                                <td>Puerto Vallarta</td>
                                <td>PVR</td>
                                <td>PVR</td>
                            </tr>
                            <tr>
                                <td>Pittsburgh</td>
                                <td>PIT</td>
                                <td>PIT</td>
                                <td>Punta Arenas</td>
                                <td>PUQ</td>
                                <td>PUQ</td>
                            </tr>
                            <tr>
                                <td>Piura</td>
                                <td>PIU</td>
                                <td>PIU</td>
                                <td>Pusan</td>
                                <td>PUS</td>
                                <td>PUS</td>
                            </tr>
                            <tr>
                                <td>Platinum</td>
                                <td>PTU</td>
                                <td>PTU</td>
                                <td>Pyongyang</td>
                                <td>FNJ</td>
                                <td>FNJ</td>
                            </tr>
                            <tr>
                                <td>Plymouth</td>
                                <td>PYM</td>
                                <td>PYM</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Pocatello</td>
                                <td>PIH</td>
                                <td>PIH</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Pohnpei</td>
                                <td>PNI</td>
                                <td>PNI</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Point à Pitre</td>
                                <td>PTP</td>
                                <td>PTP</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Pointe Noire</td>
                                <td>PNR</td>
                                <td>PNR</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="q" role="tabpanel" aria-labelledby="q-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Qingdao</td>
                                <td>TAO</td>
                                <td>TAO</td>
                                <td>Quinhagak</td>
                                <td>KWN</td>
                                <td>KWN</td>
                            </tr>
                            <tr>
                                <td>Quebec</td>
                                <td>YQB</td>
                                <td>YQB</td>
                                <td>Quito</td>
                                <td>UIO</td>
                                <td>UIO</td>
                            </tr>
                            <tr>
                                <td>Quetta</td>
                                <td>UET</td>
                                <td>UET</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="r" role="tabpanel" aria-labelledby="r-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Rabat</td>
                                <td>RBA</td>
                                <td>RBA</td>
                                <td>Roanoke</td>
                                <td>ROA</td>
                                <td>ROA</td>
                            </tr>
                            <tr>
                                <td>Rabaul</td>
                                <td>RAB</td>
                                <td>RAB</td>
                                <td>Roatan</td>
                                <td>RTB</td>
                                <td>RTB</td>
                            </tr>
                            <tr>
                                <td>Raleigh/Durham</td>
                                <td>RDU</td>
                                <td>RDU</td>
                                <td>Rochester</td>
                                <td>ROC</td>
                                <td>ROC</td>
                            </tr>
                            <tr>
                                <td>Rangoon/Yangon</td>
                                <td>RGN</td>
                                <td>RGN</td>
                                <td>Rochester</td>
                                <td>RST</td>
                                <td>RST</td>
                            </tr>
                            <tr>
                                <td>Rapid City</td>
                                <td>RAP</td>
                                <td>RAP</td>
                                <td>Rockford</td>
                                <td>RFD</td>
                                <td>RFD</td>
                            </tr>
                            <tr>
                                <td>Rarotonga</td>
                                <td>RAR</td>
                                <td>RAR</td>
                                <td>Rocky Mount/Wilson</td>
                                <td>RWI</td>
                                <td>RWI</td>
                            </tr>
                            <tr>
                                <td>Recife</td>
                                <td>REC</td>
                                <td>REC</td>
                                <td>Rome</td>
                                <td>ROM</td>
                                <td>ROM</td>
                            </tr>
                            <tr>
                                <td>Red Devil</td>
                                <td>RDV</td>
                                <td>RDV</td>
                                <td>Rome, Clampino</td>
                                <td>ROM</td>
                                <td>CIA</td>
                            </tr>
                            <tr>
                                <td>Redding</td>
                                <td>RDD</td>
                                <td>RDD</td>
                                <td>Rome, Fiumicino</td>
                                <td>ROM</td>
                                <td>FCO</td>
                            </tr>
                            <tr>
                                <td>Regina</td>
                                <td>YQR</td>
                                <td>YQR</td>
                                <td>Roosevelt</td>
                                <td>ROL</td>
                                <td>ROL</td>
                            </tr>
                            <tr>
                                <td>Reno</td>
                                <td>RNO</td>
                                <td>RNO</td>
                                <td>Roswell</td>
                                <td>ROW</td>
                                <td>ROW</td>
                            </tr>
                            <tr>
                                <td>Resolute</td>
                                <td>YRB</td>
                                <td>YRB</td>
                                <td>Rota</td>
                                <td>ROP</td>
                                <td>ROP</td>
                            </tr>
                            <tr>
                                <td>Reykjavik</td>
                                <td>REK</td>
                                <td>REK</td>
                                <td>Rotterdam</td>
                                <td>RTM</td>
                                <td>RTM</td>
                            </tr>
                            <tr>
                                <td>Richmond</td>
                                <td>RIC</td>
                                <td>RIC</td>
                                <td>Rouen</td>
                                <td>URO</td>
                                <td>URO</td>
                            </tr>
                            <tr>
                                <td>Riga</td>
                                <td>RIX</td>
                                <td>RIX</td>
                                <td>Ruby</td>
                                <td>RBY</td>
                                <td>RBY</td>
                            </tr>
                            <tr>
                                <td>Riga, Skulte</td>
                                <td>RIX</td>
                                <td>RSC</td>
                                <td>Russian Mission</td>
                                <td>RSH</td>
                                <td>RSH</td>
                            </tr>
                            <tr>
                                <td>Rimini</td>
                                <td>RMI</td>
                                <td>RMI</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Rio de Janeiro</td>
                                <td>RIO</td>
                                <td>RIO</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Rio de Janeiro, Internacional</td>
                                <td>RIO</td>
                                <td>GIG</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Rio de Janeiro, Santos Dumont</td>
                                <td>RIO</td>
                                <td>SDU</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Rio Gallegos</td>
                                <td>RGL</td>
                                <td>RGL</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Rioja</td>
                                <td>RIJ</td>
                                <td>RIJ</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Riyadh</td>
                                <td>RUH</td>
                                <td>RUH</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="s" role="tabpanel" aria-labelledby="s-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Saarbruecken</td>
                                <td>SCN</td>
                                <td>SCN</td>
                                <td>Shannon</td>
                                <td>SNN</td>
                                <td>SNN</td>
                            </tr>
                            <tr>
                                <td>Sacramento</td>
                                <td>SAC</td>
                                <td>SMF</td>
                                <td>Shantou/Swatow</td>
                                <td>SWA</td>
                                <td>SWA</td>
                            </tr>
                            <tr>
                                <td>Saipan</td>
                                <td>SPN</td>
                                <td>SPN</td>
                                <td>Sharjah</td>
                                <td>SHJ</td>
                                <td>SHJ</td>
                            </tr>
                            <tr>
                                <td>Sal</td>
                                <td>SID</td>
                                <td>SID</td>
                                <td>Shemya Islands</td>
                                <td>SYA</td>
                                <td>SYA</td>
                            </tr>
                            <tr>
                                <td>Salt Lake City</td>
                                <td>SLC</td>
                                <td>SLC</td>
                                <td>Shenyang</td>
                                <td>SHE</td>
                                <td>SHE</td>
                            </tr>
                            <tr>
                                <td>Saltillo</td>
                                <td>SLW</td>
                                <td>SLW</td>
                                <td>Shenzhen</td>
                                <td>SZX</td>
                                <td>SZX</td>
                            </tr>
                            <tr>
                                <td>Salvador</td>
                                <td>SSA</td>
                                <td>SSA</td>
                                <td>Shetland Islands, Lerwick / Tingwall</td>
                                <td>SDZ</td>
                                <td>LWK</td>
                            </tr>
                            <tr>
                                <td>Salzburg</td>
                                <td>SZG</td>
                                <td>SZG</td>
                                <td>Shetland Islands, Scatsta</td>
                                <td>SDZ</td>
                                <td>SCS</td>
                            </tr>
                            <tr>
                                <td>San Andres Island</td>
                                <td>ADZ</td>
                                <td>ADZ</td>
                                <td>Shetland Islands, Sumuburgh</td>
                                <td>SDZ</td>
                                <td>LSI</td>
                            </tr>
                            <tr>
                                <td>San Angelo</td>
                                <td>SJT</td>
                                <td>SJT</td>
                                <td>Shijiazhuang</td>
                                <td>SJW</td>
                                <td>SJW</td>
                            </tr>
                            <tr>
                                <td>San Antonio</td>
                                <td>SAT</td>
                                <td>SAT</td>
                                <td>Shiraz</td>
                                <td>SYZ</td>
                                <td>SYZ</td>
                            </tr>
                            <tr>
                                <td>San Antonio</td>
                                <td>SVZ</td>
                                <td>SVZ</td>
                                <td>Shreveport</td>
                                <td>SHV</td>
                                <td>SHV</td>
                            </tr>
                            <tr>
                                <td>San Diego</td>
                                <td>SAN</td>
                                <td>SAN</td>
                                <td>Sibu</td>
                                <td>SBW</td>
                                <td>SBW</td>
                            </tr>
                            <tr>
                                <td>San Francisco</td>
                                <td>SFO</td>
                                <td>SFO</td>
                                <td>Simferopol</td>
                                <td>SIP</td>
                                <td>SIP</td>
                            </tr>
                            <tr>
                                <td>San Francisco, Embarkadero</td>
                                <td>SFO</td>
                                <td>EMB</td>
                                <td>Singapore</td>
                                <td>SIN</td>
                                <td>SIN</td>
                            </tr>
                            <tr>
                                <td>San Jose</td>
                                <td>SJC</td>
                                <td>SJC</td>
                                <td>Singapore, Paya Lebar</td>
                                <td>SIN</td>
                                <td>QPG</td>
                            </tr>
                            <tr>
                                <td>San Jose</td>
                                <td>SJO</td>
                                <td>SJO</td>
                                <td>Singapore, Seletar</td>
                                <td>SIN</td>
                                <td>XSP</td>
                            </tr>
                            <tr>
                                <td>San Jose, Los Cabos</td>
                                <td>SJD</td>
                                <td>SJD</td>
                                <td>Sioux Falls</td>
                                <td>FSD</td>
                                <td>FSD</td>
                            </tr>
                            <tr>
                                <td>San Juan</td>
                                <td>SJU</td>
                                <td>SJU</td>
                                <td>Sitka</td>
                                <td>SIT</td>
                                <td>SIT</td>
                            </tr>
                            <tr>
                                <td>San Juan, Isla Grande</td>
                                <td>SJU</td>
                                <td>SIG</td>
                                <td>Sleetmute</td>
                                <td>SLQ</td>
                                <td>SLQ</td>
                            </tr>
                            <tr>
                                <td>San Luis Potosi</td>
                                <td>SLP</td>
                                <td>SLP</td>
                                <td>Sofia</td>
                                <td>SOF</td>
                                <td>SOF</td>
                            </tr>
                            <tr>
                                <td>San Pedro Sula</td>
                                <td>SAP</td>
                                <td>SAP</td>
                                <td>Sokoto</td>
                                <td>SKO</td>
                                <td>SKO</td>
                            </tr>
                            <tr>
                                <td>San Salvador</td>
                                <td>SAL</td>
                                <td>SAL</td>
                                <td>Soldotna</td>
                                <td>SXQ</td>
                                <td>SXW</td>
                            </tr>
                            <tr>
                                <td>San Tome</td>
                                <td>SOM</td>
                                <td>SOM</td>
                                <td>Sonderborg</td>
                                <td>SGD</td>
                                <td>SGD</td>
                            </tr>
                            <tr>
                                <td>Sanaa</td>
                                <td>SAH</td>
                                <td>SAH</td>
                                <td>Sondre Stromfjord</td>
                                <td>SFJ</td>
                                <td>SFJ</td>
                            </tr>
                            <tr>
                                <td>Sand Point</td>
                                <td>SDP</td>
                                <td>SDP</td>
                                <td>South Bend</td>
                                <td>SBN</td>
                                <td>SBN</td>
                            </tr>
                            <tr>
                                <td>Sandakan</td>
                                <td>SDK</td>
                                <td>SDK</td>
                                <td>Springfield</td>
                                <td>SGF</td>
                                <td>SGF</td>
                            </tr>
                            <tr>
                                <td>Santa Barbara</td>
                                <td>SBA</td>
                                <td>SBA</td>
                                <td>Springfield</td>
                                <td>SPI</td>
                                <td>SPI</td>
                            </tr>
                            <tr>
                                <td>Santa Cruz</td>
                                <td>SRZ</td>
                                <td>SRZ</td>
                                <td>St. Denis de La Reunion</td>
                                <td>RUN</td>
                                <td>RUN</td>
                            </tr>
                            <tr>
                                <td>Santa Cruz</td>
                                <td>SRZ</td>
                                <td>VVI</td>
                                <td>St. George</td>
                                <td>SGU</td>
                                <td>SGU</td>
                            </tr>
                            <tr>
                                <td>Santa Maria</td>
                                <td>SMX</td>
                                <td>SMX</td>
                                <td>St. George Island</td>
                                <td>STG</td>
                                <td>STG</td>
                            </tr>
                            <tr>
                                <td>Santiago</td>
                                <td>SCL</td>
                                <td>SCL</td>
                                <td>St. Johns</td>
                                <td>YYT</td>
                                <td>YYT</td>
                            </tr>
                            <tr>
                                <td>Santiago de Compostela</td>
                                <td>SCQ</td>
                                <td>SCQ</td>
                                <td>St. Kitts</td>
                                <td>SKB</td>
                                <td>SKB</td>
                            </tr>
                            <tr>
                                <td>Santo Domingo</td>
                                <td>SDQ</td>
                                <td>SDQ</td>
                                <td>St. Louis</td>
                                <td>STL</td>
                                <td>STL</td>
                            </tr>
                            <tr>
                                <td>Santo Domingo</td>
                                <td>STD</td>
                                <td>STD</td>
                                <td>St. Lucia</td>
                                <td>SLU</td>
                                <td>SLU</td>
                            </tr>
                            <tr>
                                <td>Sanya</td>
                                <td>SYX</td>
                                <td>SYX</td>
                                <td>St. Lucia, Hewanorra</td>
                                <td>SLU</td>
                                <td>UVF</td>
                            </tr>
                            <tr>
                                <td>Sao Luiz</td>
                                <td>SLZ</td>
                                <td>SLZ</td>
                                <td>St. Maarten</td>
                                <td>SXM</td>
                                <td>SXM</td>
                            </tr>
                            <tr>
                                <td>Sao Paulo</td>
                                <td>SAO</td>
                                <td>SAO</td>
                                <td>St. Mary’s</td>
                                <td>KSM</td>
                                <td>KSM</td>
                            </tr>
                            <tr>
                                <td>Sao Paulo, Congonhas</td>
                                <td>SAO</td>
                                <td>CGH</td>
                                <td>St. Petersburg</td>
                                <td>LED</td>
                                <td>LED</td>
                            </tr>
                            <tr>
                                <td>Sao Paulo, Guarulhos</td>
                                <td>SAO</td>
                                <td>GRU</td>
                                <td>St. Thomas</td>
                                <td>STT</td>
                                <td>STT</td>
                            </tr>
                            <tr>
                                <td>Sao Paulo, Viracopos</td>
                                <td>SAO</td>
                                <td>VCP</td>
                                <td>St. Vincent</td>
                                <td>SVD</td>
                                <td>SVD</td>
                            </tr>
                            <tr>
                                <td>Sao Tome Island</td>
                                <td>TMS</td>
                                <td>TMS</td>
                                <td>Sta Cruz Huat</td>
                                <td>HUX</td>
                                <td>HUX</td>
                            </tr>
                            <tr>
                                <td>Sapporo</td>
                                <td>SPK</td>
                                <td>SPK</td>
                                <td>Stavanger</td>
                                <td>SVG</td>
                                <td>SVG</td>
                            </tr>
                            <tr>
                                <td>Sapporo, Chitose</td>
                                <td>SPK</td>
                                <td>CTS</td>
                                <td>Steamboat Spring</td>
                                <td>SBS</td>
                                <td>SBS</td>
                            </tr>
                            <tr>
                                <td>Sapporo, Okadama</td>
                                <td>SPK</td>
                                <td>OKD</td>
                                <td>Stevens Village</td>
                                <td>SVS</td>
                                <td>SVS</td>
                            </tr>
                            <tr>
                                <td>Sarasota/ Bradenton</td>
                                <td>SRQ</td>
                                <td>SRQ</td>
                                <td>Stockholm</td>
                                <td>STO</td>
                                <td>STO</td>
                            </tr>
                            <tr>
                                <td>Sault Ste. Marie</td>
                                <td>YAM</td>
                                <td>YAM</td>
                                <td>Stockholm, Arlanda</td>
                                <td>STO</td>
                                <td>ARN</td>
                            </tr>
                            <tr>
                                <td>Savannah</td>
                                <td>SAV</td>
                                <td>SAV</td>
                                <td>Stockholm, Bromma</td>
                                <td>STO</td>
                                <td>BMA</td>
                            </tr>
                            <tr>
                                <td>Scammon Bay</td>
                                <td>SCM</td>
                                <td>SCM</td>
                                <td>Stockton</td>
                                <td>SCK</td>
                                <td>SCK</td>
                            </tr>
                            <tr>
                                <td>Scranton, Wilkes-Barre</td>
                                <td>AVP</td>
                                <td>AVP</td>
                                <td>Stony River</td>
                                <td>SRV</td>
                                <td>SRV</td>
                            </tr>
                            <tr>
                                <td>Seattle</td>
                                <td>SEA</td>
                                <td>SEA</td>
                                <td>Strasbourg</td>
                                <td>SXB</td>
                                <td>SXB</td>
                            </tr>
                            <tr>
                                <td>Sedona</td>
                                <td>SDX</td>
                                <td>SDX</td>
                                <td>Stuttgart</td>
                                <td>STR</td>
                                <td>STR</td>
                            </tr>
                            <tr>
                                <td>Seldovia</td>
                                <td>SOV</td>
                                <td>SOV</td>
                                <td>Sudbury</td>
                                <td>YSB</td>
                                <td>YSB</td>
                            </tr>
                            <tr>
                                <td>Sendai</td>
                                <td>SDJ</td>
                                <td>SDJ</td>
                                <td>Sukhumi</td>
                                <td>SUI</td>
                                <td>SUI</td>
                            </tr>
                            <tr>
                                <td>Seoul</td>
                                <td>SEL</td>
                                <td>SEL</td>
                                <td>Sundsvall</td>
                                <td>SDL</td>
                                <td>SDL</td>
                            </tr>
                            <tr>
                                <td>Sepulot</td>
                                <td>SPE</td>
                                <td>SPE</td>
                                <td>Surabaya</td>
                                <td>SUB</td>
                                <td>SUB</td>
                            </tr>
                            <tr>
                                <td>Seville</td>
                                <td>SVQ</td>
                                <td>SVQ</td>
                                <td>Suva</td>
                                <td>SUV</td>
                                <td>SUV</td>
                            </tr>
                            <tr>
                                <td>Seward</td>
                                <td>SWD</td>
                                <td>SWD</td>
                                <td>Sverdlovsk, Ekaterinburg</td>
                                <td>SVX</td>
                                <td>SVX</td>
                            </tr>
                            <tr>
                                <td>Shageluk</td>
                                <td>SHX</td>
                                <td>SHX</td>
                                <td>Sydney</td>
                                <td>SYD</td>
                                <td>SYD</td>
                            </tr>
                            <tr>
                                <td>Shanghai</td>
                                <td>SHA</td>
                                <td>SHA</td>
                                <td>Syracuse</td>
                                <td>SYR</td>
                                <td>SYR</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="t" role="tabpanel" aria-labelledby="t-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Tabriz</td>
                                <td>TBZ</td>
                                <td>TBZ</td>
                                <td>Tokushima</td>
                                <td>TKS</td>
                                <td>TKS</td>
                            </tr>
                            <tr>
                                <td>Tabuk</td>
                                <td>TUU</td>
                                <td>TUU</td>
                                <td>Tokyo</td>
                                <td>TYO</td>
                                <td>TYO</td>
                            </tr>
                            <tr>
                                <td>Tacna</td>
                                <td>TCQ</td>
                                <td>TCQ</td>
                                <td>Tokyo, Haneda</td>
                                <td>TYO</td>
                                <td>HND</td>
                            </tr>
                            <tr>
                                <td>Taegu, Korea</td>
                                <td>TAE</td>
                                <td>TAE</td>
                                <td>Tokyo, Narita Airport</td>
                                <td>TYO</td>
                                <td>NRT</td>
                            </tr>
                            <tr>
                                <td>Taichung</td>
                                <td>TXG</td>
                                <td>TXG</td>
                                <td>Toledo</td>
                                <td>TOL</td>
                                <td>TOL</td>
                            </tr>
                            <tr>
                                <td>Taif</td>
                                <td>TIF</td>
                                <td>TIF</td>
                                <td>Tongatapu</td>
                                <td>TBU</td>
                                <td>TBU</td>
                            </tr>
                            <tr>
                                <td>Taipei</td>
                                <td>TPE</td>
                                <td>TPE</td>
                                <td>Topeka</td>
                                <td>TOP</td>
                                <td>TOP</td>
                            </tr>
                            <tr>
                                <td>Taipei, Shung Shan</td>
                                <td>TPE</td>
                                <td>TSA</td>
                                <td>Toronto</td>
                                <td>YTO</td>
                                <td>YTO</td>
                            </tr>
                            <tr>
                                <td>Taiyuan</td>
                                <td>TYN</td>
                                <td>TYN</td>
                                <td>Toronto</td>
                                <td>YYZ</td>
                                <td>YYZ</td>
                            </tr>
                            <tr>
                                <td>Takamatsu</td>
                                <td>TAK</td>
                                <td>TAK</td>
                                <td>Toronto Island</td>
                                <td>YTO</td>
                                <td>YTZ</td>
                            </tr>
                            <tr>
                                <td>Talara</td>
                                <td>TYL</td>
                                <td>TYL</td>
                                <td>Torreon</td>
                                <td>TRC</td>
                                <td>TRC</td>
                            </tr>
                            <tr>
                                <td>Tallahassee</td>
                                <td>TLH</td>
                                <td>TLH</td>
                                <td>Tottori</td>
                                <td>TTJ</td>
                                <td>TTJ</td>
                            </tr>
                            <tr>
                                <td>Tallinn</td>
                                <td>TLL</td>
                                <td>TLL</td>
                                <td>Toulon/Hyeres</td>
                                <td>TLN</td>
                                <td>TLN</td>
                            </tr>
                            <tr>
                                <td>Tamanrasset</td>
                                <td>TMR</td>
                                <td>TMR</td>
                                <td>Toulouse</td>
                                <td>TLS</td>
                                <td>TLS</td>
                            </tr>
                            <tr>
                                <td>Tampa</td>
                                <td>TPA</td>
                                <td>TPA</td>
                                <td>Toyama</td>
                                <td>TOY</td>
                                <td>TOY</td>
                            </tr>
                            <tr>
                                <td>Tampere</td>
                                <td>TMP</td>
                                <td>TMP</td>
                                <td>Traverse City</td>
                                <td>TVC</td>
                                <td>TVC</td>
                            </tr>
                            <tr>
                                <td>Tanana</td>
                                <td>TAL</td>
                                <td>TAL</td>
                                <td>Trenton</td>
                                <td>TTN</td>
                                <td>TTN</td>
                            </tr>
                            <tr>
                                <td>Tangier</td>
                                <td>TNG</td>
                                <td>TNG</td>
                                <td>Tri-City</td>
                                <td>TRI</td>
                                <td>TRI</td>
                            </tr>
                            <tr>
                                <td>Tarapoto</td>
                                <td>TPP</td>
                                <td>TPP</td>
                                <td>Trieste</td>
                                <td>TRS</td>
                                <td>TRS</td>
                            </tr>
                            <tr>
                                <td>Tashkent</td>
                                <td>TAS</td>
                                <td>TAS</td>
                                <td>Tripoli</td>
                                <td>TIP</td>
                                <td>TIP</td>
                            </tr>
                            <tr>
                                <td>Tawau</td>
                                <td>TWU</td>
                                <td>TWU</td>
                                <td>Trivandrum</td>
                                <td>TRV</td>
                                <td>TRV</td>
                            </tr>
                            <tr>
                                <td>Teesside</td>
                                <td>MME</td>
                                <td>MME</td>
                                <td>Trombetas</td>
                                <td>TMT</td>
                                <td>TMT</td>
                            </tr>
                            <tr>
                                <td>Tegucigalpa</td>
                                <td>TGU</td>
                                <td>TGU</td>
                                <td>Tromso</td>
                                <td>TOS</td>
                                <td>TOS</td>
                            </tr>
                            <tr>
                                <td>Tehran</td>
                                <td>THR</td>
                                <td>THR</td>
                                <td>Trondheim</td>
                                <td>TRD</td>
                                <td>TRD</td>
                            </tr>
                            <tr>
                                <td>Tel Aviv Yafo, Sde Dov</td>
                                <td>TLV</td>
                                <td>SDV</td>
                                <td>Trujillo</td>
                                <td>TRU</td>
                                <td>TRU</td>
                            </tr>
                            <tr>
                                <td>Tel Aviv Yafo, Tel Aviv</td>
                                <td>TLV</td>
                                <td>TLV</td>
                                <td>Truk</td>
                                <td>TKK</td>
                                <td>TKK</td>
                            </tr>
                            <tr>
                                <td>Temuco</td>
                                <td>ZCO</td>
                                <td>ZCO</td>
                                <td>Tucson</td>
                                <td>TUS</td>
                                <td>TUS</td>
                            </tr>
                            <tr>
                                <td>Tenerife</td>
                                <td>TCI</td>
                                <td>TCI</td>
                                <td>Tulsa</td>
                                <td>TUL</td>
                                <td>TUL</td>
                            </tr>
                            <tr>
                                <td>Tenerife, Norte Los Rodeos</td>
                                <td>TCI</td>
                                <td>TFN</td>
                                <td>Tuluksak</td>
                                <td>TLT</td>
                                <td>TLT</td>
                            </tr>
                            <tr>
                                <td>Tenerife, Sur Reine Sofia</td>
                                <td>TCI</td>
                                <td>TFS</td>
                                <td>Tumbes</td>
                                <td>TBP</td>
                                <td>TBP</td>
                            </tr>
                            <tr>
                                <td>Terceira</td>
                                <td>TER</td>
                                <td>TER</td>
                                <td>Tunis</td>
                                <td>TUN</td>
                                <td>TUN</td>
                            </tr>
                            <tr>
                                <td>Terrace</td>
                                <td>YXT</td>
                                <td>YXT</td>
                                <td>Tuntutulia</td>
                                <td>WTL</td>
                                <td>WTL</td>
                            </tr>
                            <tr>
                                <td>Texarkana</td>
                                <td>TXK</td>
                                <td>TXK</td>
                                <td>Tununak</td>
                                <td>TNK</td>
                                <td>TNK</td>
                            </tr>
                            <tr>
                                <td>Thessaloniki</td>
                                <td>SKG</td>
                                <td>SKG</td>
                                <td>Turin</td>
                                <td>TRN</td>
                                <td>TRN</td>
                            </tr>
                            <tr>
                                <td>Thunder Bay</td>
                                <td>YQT</td>
                                <td>YQT</td>
                                <td>Turku</td>
                                <td>TKU</td>
                                <td>TKU</td>
                            </tr>
                            <tr>
                                <td>Tianjin</td>
                                <td>TSN</td>
                                <td>TSN</td>
                                <td>Tuscaloosa</td>
                                <td>TCL</td>
                                <td>TCL</td>
                            </tr>
                            <tr>
                                <td>Tijuana</td>
                                <td>TIJ</td>
                                <td>TIJ</td>
                                <td>Tuxtla Gutierrez</td>
                                <td>TGZ</td>
                                <td>TGZ</td>
                            </tr>
                            <tr>
                                <td>Timisoara</td>
                                <td>TSR</td>
                                <td>TSR</td>
                                <td>Twin Falls</td>
                                <td>TWF</td>
                                <td>TWF</td>
                            </tr>
                            <tr>
                                <td>Tingo Maria</td>
                                <td>TGI</td>
                                <td>TGI</td>
                                <td>Tyler</td>
                                <td>TYR</td>
                                <td>TYR</td>
                            </tr>
                            <tr>
                                <td>Tobago</td>
                                <td>TAB</td>
                                <td>TAB</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>Toksook Bay</td>
                                <td>OOK</td>
                                <td>OOK</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="u" role="tabpanel" aria-labelledby="u-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Ube</td>
                                <td>UBJ</td>
                                <td>UBJ</td>
                                <td>Umea</td>
                                <td>UME</td>
                                <td>UME</td>
                            </tr>
                            <tr>
                                <td>Ukiah</td>
                                <td>UKI</td>
                                <td>UKI</td>
                                <td>Unalakleet</td>
                                <td>UNK</td>
                                <td>UNK</td>
                            </tr>
                            <tr>
                                <td>Ulan Bator</td>
                                <td>ULN</td>
                                <td>ULN</td>
                                <td>Urumqi</td>
                                <td>URC</td>
                                <td>URC</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="v" role="tabpanel" aria-labelledby="v-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Vaasa</td>
                                <td>VAA</td>
                                <td>VAA</td>
                                <td>Veracruz</td>
                                <td>VER</td>
                                <td>VER</td>
                            </tr>
                            <tr>
                                <td>Valdosta</td>
                                <td>VLD</td>
                                <td>VLD</td>
                                <td>Vernal</td>
                                <td>VEL</td>
                                <td>VEL</td>
                            </tr>
                            <tr>
                                <td>Valencia</td>
                                <td>VLC</td>
                                <td>VLC</td>
                                <td>Verona</td>
                                <td>VRN</td>
                                <td>VRN</td>
                            </tr>
                            <tr>
                                <td>Valencia</td>
                                <td>VLN</td>
                                <td>VLN</td>
                                <td>Victoria</td>
                                <td>YYJ</td>
                                <td>YYJ</td>
                            </tr>
                            <tr>
                                <td>Valera</td>
                                <td>VLV</td>
                                <td>VLV</td>
                                <td>Vienna</td>
                                <td>VIE</td>
                                <td>VIE</td>
                            </tr>
                            <tr>
                                <td>Valladolid</td>
                                <td>VLL</td>
                                <td>VLL</td>
                                <td>Vientiane</td>
                                <td>VTE</td>
                                <td>VTE</td>
                            </tr>
                            <tr>
                                <td>Vancouver</td>
                                <td>YVR</td>
                                <td>YVR</td>
                                <td>Vieques</td>
                                <td>VQS</td>
                                <td>VQS</td>
                            </tr>
                            <tr>
                                <td>Vasteras</td>
                                <td>VST</td>
                                <td>VST</td>
                                <td>Villahermosa</td>
                                <td>VSA</td>
                                <td>VSA</td>
                            </tr>
                            <tr>
                                <td>Vaxjo</td>
                                <td>VXO</td>
                                <td>VXO</td>
                                <td>Vilnius</td>
                                <td>VNO</td>
                                <td>VNO</td>
                            </tr>
                            <tr>
                                <td>Venetie</td>
                                <td>VEE</td>
                                <td>VEE</td>
                                <td>Vitoria</td>
                                <td>VIT</td>
                                <td>VIT</td>
                            </tr>
                            <tr>
                                <td>Venice</td>
                                <td>VCE</td>
                                <td>VCE</td>
                                <td>Vladivostok</td>
                                <td>VVO</td>
                                <td>VVO</td>
                            </tr>
                            <tr>
                                <td>Venice, Treviso</td>
                                <td>VCE</td>
                                <td>TSF</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="w" role="tabpanel" aria-labelledby="w-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Wabush</td>
                                <td>YWK</td>
                                <td>YWK</td>
                                <td>White River</td>
                                <td>LEB</td>
                                <td>LEB</td>
                            </tr>
                            <tr>
                                <td>Waco</td>
                                <td>ACT</td>
                                <td>ACT</td>
                                <td>Whitehorse</td>
                                <td>YXY</td>
                                <td>YXY</td>
                            </tr>
                            <tr>
                                <td>Warsaw</td>
                                <td>WAW</td>
                                <td>WAW</td>
                                <td>Wichita</td>
                                <td>ICT</td>
                                <td>ICT</td>
                            </tr>
                            <tr>
                                <td>Washington</td>
                                <td>WAS</td>
                                <td>WAS</td>
                                <td>Wichita Falls</td>
                                <td>SPS</td>
                                <td>SPS</td>
                            </tr>
                            <tr>
                                <td>Washington, Dulles International</td>
                                <td>WAS</td>
                                <td>IAD</td>
                                <td>Wilmington</td>
                                <td>ILM</td>
                                <td>ILM</td>
                            </tr>
                            <tr>
                                <td>Washington, National</td>
                                <td>WAS</td>
                                <td>DCA</td>
                                <td>Windhoek</td>
                                <td>WDH</td>
                                <td>WDH</td>
                            </tr>
                            <tr>
                                <td>Watson Lake</td>
                                <td>YQH</td>
                                <td>YQH</td>
                                <td>Windhoek, Eros</td>
                                <td>WDH</td>
                                <td>ERS</td>
                            </tr>
                            <tr>
                                <td>Wausau</td>
                                <td>AUW</td>
                                <td>AUW</td>
                                <td>Windsor</td>
                                <td>YQG</td>
                                <td>YQG</td>
                            </tr>
                            <tr>
                                <td>Wellington</td>
                                <td>WLG</td>
                                <td>WLG</td>
                                <td>Winnipeg</td>
                                <td>YWG</td>
                                <td>YWG</td>
                            </tr>
                            <tr>
                                <td>Wenatchee</td>
                                <td>EAT</td>
                                <td>EAT</td>
                                <td>Wrangell</td>
                                <td>WRG</td>
                                <td>WRG</td>
                            </tr>
                            <tr>
                                <td>West Palm Beach</td>
                                <td>PBI</td>
                                <td>PBI</td>
                                <td>Wuhan</td>
                                <td>WUH</td>
                                <td>WUH</td>
                            </tr>
                            <tr>
                                <td>Westchester</td>
                                <td>HPN</td>
                                <td>HPN</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="x" role="tabpanel" aria-labelledby="x-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Xiamen</td>
                                <td>XMN</td>
                                <td>XMN</td>
                                <td>Xian</td>
                                <td>SIA</td>
                                <td>SIA</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="y" role="tabpanel" aria-labelledby="y-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Yakima</td>
                                <td>YKM</td>
                                <td>YKM</td>
                                <td>Yellowknife</td>
                                <td>YZF</td>
                                <td>YZF</td>
                            </tr>
                            <tr>
                                <td>Yakutat</td>
                                <td>YAK</td>
                                <td>YAK</td>
                                <td>Yinchuang</td>
                                <td>INC</td>
                                <td>INC</td>
                            </tr>
                            <tr>
                                <td>Yamagata</td>
                                <td>GAJ</td>
                                <td>GAJ</td>
                                <td>Yurimaguas</td>
                                <td>YMS</td>
                                <td>YMS</td>
                            </tr>
                            <tr>
                                <td>Yantai</td>
                                <td>YNT</td>
                                <td>YNT</td>
                                <td>Yuzhno-Sakhalinsk</td>
                                <td>UUS</td>
                                <td>UUS</td>
                            </tr>
                            <tr>
                                <td>Yap Caroline Island</td>
                                <td>YAP</td>
                                <td>YAP</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="z" role="tabpanel" aria-labelledby="z-tab">
                <div class="table-responsive">
                    <table class="table text-start red-table" border="0">
                        <thead>
                            <tr>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                                <td> Location </td>
                                <td> City </td>
                                <td> Airport </td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Zacatecas</td>
                                <td>ZCL</td>
                                <td>ZCL</td>
                                <td>Zhanjiang</td>
                                <td>ZHA</td>
                                <td>ZHA</td>
                            </tr>
                            <tr>
                                <td>Zagreb</td>
                                <td>ZAG</td>
                                <td>ZAG</td>
                                <td>Zhengzhou</td>
                                <td>CGO</td>
                                <td>CGO</td>
                            </tr>
                            <tr>
                                <td>Zahedan</td>
                                <td>ZAH</td>
                                <td>ZAH</td>
                                <td>Zihuatanejo</td>
                                <td>ZIH</td>
                                <td>ZIH</td>
                            </tr>
                            <tr>
                                <td>Zanzibar</td>
                                <td>ZNZ</td>
                                <td>ZNZ</td>
                                <td>Zurich</td>
                                <td>ZRH</td>
                                <td>ZRH</td>
                            </tr>
                            <tr>
                                <td>Zaragoza</td>
                                <td>ZAZ</td>
                                <td>ZAZ</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
</section>


<section class="p-0 mb-n10 bg-transparent cta-overlay">
    <div class="row">
        <div class="col-lg-1 col-xl-3">
        </div>
        <div class="col-lg-11 col-xl-9">
            <div class="px-1-9 px-sm-6 px-lg-9 py-5 py-sm-8 z-index-3 bg-primary contact-block half-border-radius">
                <div class="row align-items-center position-relative z-index-3">
                    <div class="col-lg-7 col-xxl-7 mb-lg-0">
                        <h3 class="text-white mb-0">Let's make your supply chain easy
                        </h3>
                    </div>
                    <div class="col-lg-5 col-xxl-5 mt-3 text-lg-end">
                        <h5 class="text-white mb-3">If you have any questions.</h5>
                        <a href="contact.php" class="butn transparent"><span>Get In Touch</span></a>
                    </div>
                </div>
                <img src="img/bg/bg-03.png" class="position-absolute top-0 left-n5" alt="...">
            </div>
        </div>
    </div>
</section>
<div class="footer-light footer-new">
    <div class="ftr-bg">
        <div class="footer-top">
            <div class="container">
                <div class="row">

                    <div class="col-lg-4 col-md-12">

                        <div class="widget widget_about">
                            <div>
                                <h3 class="widget-title">Interport Global Logistics</h3>
                            </div>
                            <p>Today, IGL has established offices in major cities and ports in India with
                                warehousing facilities and transport equipment to handle any cargo
                                independently. The company also has access to major international ports through
                                its branch offices.</p>
                            <ul class="social-icon-style1 mb-0">

                                <li>
                                    <a target="_blank" href="https://www.linkedin.com/company/1897064"><i
                                            class="fab fa-linkedin-in"></i></a>
                                </li>

                            </ul>
                        </div>

                    </div>

                    <div class="col-lg-2 col-md-6 col-6">
                        <div class="widget widget_services ftr-list-center">
                            <h3 class="widget-title">Contact Us</h3>
                            <ul>
                                <li><a href="contact.php">Contact</a></li>
                                <li><a href="enquiry-form.php">Enquiry Form</a></li>
                                <li><a href="feedback-form.php">Feedback Form</a></li>
                                <li><a href="air-shipment.php">Air Shipment Bookings</a></li>
                                <li><a href="sea-shipment.php">Sea Shipment Bookings</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6 col-6">
                        <div class="widget widget_services ftr-list-center">
                            <h3 class="widget-title">Important Links</h3>
                            <ul>
                                <li><a href="about.php">About</a></li>
                                <li><a href="careers.php">Careers</a></li>
                                <li><a href="terms-and-conditions.php">Terms & Conditions</a></li>
                                <li><a href="certifications.php">Certifications</a></li>
                                <li><a href="advertisements.php">Advertisements</a></li>
                                <li><a href="sitemap.php">Sitemap</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-12">
                        <div class="widget widget_services ftr-list-center connect-details">
                            <h3 class="widget-title">Online Support</h3>
                            <ul>
                                <p>Everyday is a new day for us and we work really hard to satisfy
                                    our customers everywhere.</p>
                                <li><a href="tel:+91-22 6951 6951"><i class="fa fa-phone"></i><strong> India: T-
                                        </strong> +91-22 6951 6951</a></li>
                                <li><a href="tel:+1 (732) 422-3870"><i class="fa fa-phone"></i><strong> USA: T-
                                        </strong> +1 (732) 422-3870</a></li>
                            </ul>
                            <ul class="mt-md-3">
                                <li><a href="tel:+91-22 6616 6642"><i class="fa fa-fax"></i><strong> India: F-
                                        </strong> +91-22 6616 6642</a></li>
                                <li><a href="tel:+1 (732) 422-3878"><i class="fa fa-fax"></i><strong> USA: F- </strong>
                                        +1 (732) 422-3878</a></li>
                            </ul>
                            <ul class="mt-md-3">
                                <li><a href="mailto:info@interportglobal.com"><i class="fa fa-envelope"></i><strong>
                                            India: E- </strong>info@interportglobal.com</a></li>
                                <li><a href="mailto:usa@interportglobal.com"><i class="fa fa-envelope"></i><strong>
                                            USA: E- </strong>usa@interportglobal.com</a></li>
                            </ul>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <div class="footer-bottom-info">
                    <div class="footer-copy-right">
                        <span class="copyrights-text cpt-txt">Interport Global Logistics &copy; 2023. All rights reserved.
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

</div>
<a href="javascript:void(0)" class="scroll-to-top"><i class="fas fa-angle-up" aria-hidden="true"></i></a>
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/core.min.js"></script>
<script src="js/main.js"></script>
<script>
    $(document).ready(function () {
        $(".hide").click(function () {
            $(".hide-show-block").hide();
        });
        $(".show").click(function () {
            $(".hide-show-block").show();
        });
    });

    $(document).ready(function () {
        $(".hide-one").click(function () {
            $(".hide-show-block-one").hide();
        });
        $(".show-one").click(function () {
            $(".hide-show-block-one").show();
        });
    });
</script>
</body>

</html>
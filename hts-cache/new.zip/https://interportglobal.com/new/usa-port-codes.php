<!DOCTYPE html>
<html lang="en">

		
 
<head>
    <meta charset="utf-8" />
    <meta name="author" content="Interport Global Logistics" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="keywords" content="Interport Global Logistics" />
    <meta name="description" content="Interport Global Logistics" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;900&display=swap" rel="stylesheet">
    <title>USA port codes - Interport Global Logistics</title>
    <meta name="description" content="Interport Global Logistics - Total Logistics Solutions Provider">
    <meta name="keywords" content="logistics, cargo, solutions, addons, sea freight, air freight, rail freight, cargo insurance, container freight station, custom clearance, import export consolidation, nvocc, door to door delivery, iso flexi tanks, project logistics, heavy lift, break bulk, warehousing, our packing, transportation and distribution, rfid solutions, warehouse management, turnkey projects, logistic solutions, exhibition cargo, hazardous cargo, project cargo, ivrs phone track, airlines, bankers, india info, container specification sea, container specification air, hazmat definitions, shipping glossary, iata codes, usa port codes, print your bill of lading, industry links, inco terms, air shipment, sea shipment" />
    <meta property="og:description" content="Interport Global Logistics - Total Logistics Solutions Provider">
    <meta property="og:site_name" content="Interport Global Logistics">
    <meta property="og:title" content="Interport Global Logistics">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://interportglobal.com/new/">
    <meta property="og:image" content="https://interportglobal.com/new/img/logos/logo-old.png" />
    <meta property="og:image:secure_url" content="https://interportglobal.com/new/img/logos/logo-old.png" />
    <meta property="og:image:width" content="1800" />
    <meta property="og:image:height" content="945" />
    <meta property="og:image:alt" content="Interport Global Logistics" />
    <meta property="og:image:type" content="image/png" />
    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="Interport Global Logistics">
    <meta name="twitter:creator" content="Interport Global Logistics">
    <meta name="twitter:title" content="Interport Global Logistics">
    <meta name="twitter:description" content="Interport Global Logistics - Total Logistics Solutions Provider">
    <link rel="shortcut icon" href="img/logos/logo-old.png" />
    <link rel="apple-touch-icon" href="img/logos/logo-old.png" />
    <link rel="apple-touch-icon" sizes="72x72" href="img/logos/logo-old.png" />
    <link rel="apple-touch-icon" sizes="114x114" href="img/logos/logo-old.png" />
    <link rel="stylesheet" href="css/plugins.css">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="css/mystyle.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link href="css/new-responsive.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/f70dd43e17.js" crossorigin="anonymous"></script>
    <script type="text/javascript">
        function googleTranslateElementInit2() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                autoDisplay: false
            }, 'google_translate_element2');
        }
    </script>
    <script type="text/javascript"
        src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2">
    </script>
    <script type="text/javascript">
        eval(function (p, a, c, k, e, r) {
            e = function (c) {
                return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) :
                    c
                    .toString(36))
            };
            if (!''.replace(/^/, String)) {
                while (c--) r[e(c)] = k[c] || e(c);
                k = [function (e) {
                    return r[e]
                }];
                e = function () {
                    return '\\w+'
                };
                c = 1
            };
            while (c--)
                if (k[c]) p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]);
            return p
        }('6 7(a,b){n{4(2.9){3 c=2.9("o");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s(\'t\'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a==\'\')v;3 b=a.w(\'|\')[1];3 c;3 d=2.x(\'y\');z(3 i=0;i<d.5;i++)4(d[i].A==\'B-C-D\')c=d[i];4(2.j(\'k\')==E||2.j(\'k\').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,\'m\');7(c,\'m\')}}',
            43, 43,
            '||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500'
            .split('|'), 0, {}))
    </script>
    <script>
        (function (w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-M9TZHXX');
    </script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-179148496-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-179148496-1');
    </script>
    <script>
        ! function (f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function () {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '420989926550304');
        fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
            src="https://www.facebook.com/tr?id=420989926550304&ev=PageView&noscript=1" /></noscript>
</head>

<body>
    <div id="preloader"></div>
    <div class="main-wrapper">
        <header class="header-style1 menu_area-light">
            <div class="navbar-default">
                <div class="top-search bg-secondary">
                    <div class="container-fluid px-lg-1-6 px-xl-2-5 px-xxl-2-9">
                        <form class="search-form" action="" method="GET" accept-charset="utf-8">
                            <div class="input-group">
                                <span class="input-group-addon cursor-pointer">
                                    <button class="search-form_submit fas fa-search text-white" type="submit"></button>
                                </span>
                                <input type="text" class="search-form_input form-control" name="s" autocomplete="off"
                                    placeholder="Type &amp; hit enter...">
                                <span class="input-group-addon close-search mt-1"><i class="fas fa-times"></i></span>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="container-fluid px-lg-1-6 px-xl-2-5 px-xxl-2-9">
                    <div class="row align-items-center">
                        <div class="col-12 col-lg-12 p-0 px-lg-2">
                            <div class="menu_area alt-font">
                                <nav class="navbar navbar-expand-lg navbar-light p-0">
                                    <div class="navbar-header navbar-header-custom">
                                        <a href="index.php" class="navbar-brand logochange">
                                            <img id="logo" class="home-logo" src="img/logos/logo-w.png" alt="logo" />
                                            <img id="logo" class="other-logo" src="img/logos/logo-b.png" alt="logo" />
                                        </a>
                                    </div>
                                    <div class="navbar-toggler bg-primary"></div>
                                    <ul class="navbar-nav" id="nav" style="display: none;">
                                        <li
                                            >
                                            <a href="https://interportglobal.com/new/index.php">Home</a></li>
                                        <li >
                                            <a href="about.php">About Us</a>
                                        </li>
                                        <li
                                            class="d-none d-lg-block d-xl-block 
                                            ">
                                            <a href="https://interportglobal.com/new/services.php">Services</a>
                                            <ul class="row megamenu">
                                                <li class="col-lg-4 col-sm-12">
                                                    <ul>
                                                        <li><a href="freight-forwarding.php">Freight Forwarding</a></li>
                                                        <li><a href="ocean-freight.php">Ocean Freight</a></li>
                                                        <li><a href="air-freight.php">Air Freight</a></li>
                                                        <li><a href="rail-freight.php">Rail Freight</a></li>
                                                        <li><a href="road-freight.php">Road Freight</a></li>
                                                        <li><a href="3pl-warehousing.php">3PL Warehousing</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <ul>
                                                        <li><a href="custom-brokerage.php">Custom Brokerage</a></li>
                                                        <li><a href="hazardous-cargo.php">Hazardous Cargo</a></li>
                                                        <li><a href="project-cargo.php">Project Cargo</a></li>
                                                        <li><a href="heavy-lift.php">Heavy Lift</a></li>
                                                        <li><a href="door-to-door-program.php">Door To Door
                                                                Program</a></li>
                                                        <li><a href="vessel-handling.php">Vessel Handling</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <ul>
                                                        <li><a href="turnkey-projects.php">Turnkey Projects</a></li>
                                                        <li><a href="iso-flexi-tanks.php">ISO Tanks / Flexi Tanks</a>
                                                        </li>
                                                        <li><a href="cargo-insurance.php">Cargo Insurance</a></li>
                                                        <li><a href="nvocc.php">NVOCC</a></li>
                                                        <li><a href="import-export-consolidation.php">Import / Export
                                                                Consolidation</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                        <li
                                            class="d-block d-lg-none d-xl-none 
                                            ">
                                            <a href="services.php">Services</a>
                                            <ul>
                                                <li><a href="services.php">Services</a></li>
                                                <li><a href="freight-forwarding.php">Freight Forwarding</a></li>
                                                <li><a href="ocean-freight.php">Ocean Freight</a></li>
                                                <li><a href="air-freight.php">Air Freight</a></li>
                                                <li><a href="rail-freight.php">Rail Freight</a></li>
                                                <li><a href="road-freight.php">Road Freight</a></li>
                                                <li><a href="3pl-warehousing.php">3PL Warehousing</a>
                                                </li>
                                                <li><a href="custom-brokerage.php">Custom Brokerage</a></li>
                                                <li><a href="hazardous-cargo.php">Hazardous Cargo</a></li>
                                                <li><a href="project-cargo.php">Project Cargo</a></li>
                                                <li><a href="heavy-lift.php">Heavy Lift</a></li>
                                                <li><a href="door-to-door-program.php">Door To Door
                                                        Program</a></li>
                                                <li><a href="vessel-handling.php">Vessel Handling</a></li>
                                                <li><a href="turnkey-projects.php">Turnkey Projects</a></li>
                                                <li><a href="iso-flexi-tanks.php">ISO Tanks / Flexi Tanks</a>
                                                </li>
                                                <li><a href="cargo-insurance.php">Cargo Insurance</a></li>
                                                <li><a href="nvocc.php">NVOCC</a></li>
                                                <li><a href="import-export-consolidation.php">Import / Export
                                                        Consolidation</a></li>
                                            </ul>
                                        </li>
                                        <li
                                            class="active">
                                            <a href="javascript:void(0)">Resources</a>
                                            <ul class="row megamenu">
                                                <li class="col-lg-4 col-sm-12">
                                                    <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Other
                                                        Links</span>
                                                    <ul>
                                                        <li><a href="airlines.php">Airlines</a></li>
                                                        <li><a href="bankers.php">Bankers</a></li>
                                                        <li><a href="2023-holiday-list.php">2023 Holiday List</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Important
                                                        Info</span>
                                                    <ul>
                                                        <li><a href="india-info.php">India Info</a></li>
                                                        <li><a href="container-specification-sea.php">Container
                                                                Specification-Sea</a></li>
                                                        <li><a href="container-specification-air.php">Container
                                                                Specification-Air</a></li>
                                                        <li><a href="hazmat-definitions.php">Hazmat Definifitons</a>
                                                        </li>
                                                        <li><a href="shipping-glossary.php">Shipping Glossary</a></li>
                                                        <li><a href="iata-codes.php">IATA Codes</a></li>
                                                        <li><a href="usa-port-codes.php">USA Port Codes</a></li>
                                                        <li><a href="print-your-bill-of-lading.php">Print Your Bill Of
                                                                Lading</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Important
                                                        Links</span>
                                                    <ul>
                                                        <li><a href="industry-links.php">Industry Links</a></li>
                                                        <li><a href="inco-terms.php">INCO Terms</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                        <li >
                                            <a href="careers.php">Careers</a>
                                        </li>
                                        <li >
                                            <a href="network.php">Network</a>
                                        </li>
                                        <li
                                            >
                                            <a href="contact.php">Contact</a>
                                            <ul>
                                                <li
                                                    class="d-block d-lg-none ">
                                                    <a href="contact.php">Contact</a>
                                                </li>
                                                <li >
                                                    <a href="enquiry-form.php">Enquiry Form</a>
                                                </li>
                                                <li >
                                                    <a href="feedback-form.php">Feedback Form</a>
                                                </li>
                                                <li >
                                                    <a href="air-shipment.php">Air Shipment Bookings</a>
                                                </li>
                                                <li >
                                                    <a href="sea-shipment.php">Sea Shipment Bookings</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li
                                            class=" d-block d-lg-none">
                                            <a href="get-a-quote.php">Get a Quote</a>
                                        </li>
                                        <li class="d-block d-lg-none">
                                            <a target="_blank"
                                                href="http://www.interportglobal.net/Logisys/customervisibility/login.aspx">Track
                                                your shipment</a>
                                        </li>
                                        <li class="d-block d-lg-none">
                                                <select class="language-dropdown" onchange="doGTranslate(this);">
                                                    <option value="">Select a language</option>
                                                    <option value="en|af">Af</option>
                                                    <option value="en|sq">sq</option>
                                                    <option value="en|am">am</option>
                                                    <option value="en|ar">ar</option>
                                                    <option value="en|hy">hy</option>
                                                    <option value="en|az">az</option>
                                                    <option value="en|eu">eu</option>
                                                    <option value="en|be">be</option>
                                                    <option value="en|bn">bn</option>
                                                    <option value="en|bs">bs</option>
                                                    <option value="en|bg">bg</option>
                                                    <option value="en|ca">ca</option>
                                                    <option value="en|ceb">ceb</option>
                                                    <option value="en|ny">ny</option>
                                                    <option value="en|zh-CN">zh-CN</option>
                                                    <option value="en|zh-TW">zh-TW</option>
                                                    <option value="en|co">co</option>
                                                    <option value="en|hr">hr</option>
                                                    <option value="en|cs">cs</option>
                                                    <option value="en|da">da</option>
                                                    <option value="en|nl">nl</option>
                                                    <option value="en|en">en</option>
                                                    <option value="en|eo">eo</option>
                                                    <option value="en|et">et</option>
                                                    <option value="en|tl">tl</option>
                                                    <option value="en|fi">fi</option>
                                                    <option value="en|fr">fr</option>
                                                    <option value="en|fy">fy</option>
                                                    <option value="en|gl">gl </option>
                                                    <option value="en|ka">ka </option>
                                                    <option value="en|de">de </option>
                                                    <option value="en|el">el </option>
                                                    <option value="en|gu">gu </option>
                                                    <option value="en|ht">ht</option>
                                                    <option value="en|ha">ha </option>
                                                    <option value="en|haw">haw</option>
                                                    <option value="en|iw">iw </option>
                                                    <option value="en|hi">hi </option>
                                                    <option value="en|hmn">hmn</option>
                                                    <option value="en|hu">hu</option>
                                                    <option value="en|is">is</option>
                                                    <option value="en|ig">ig </option>
                                                    <option value="en|id">id</option>
                                                    <option value="en|ga">ga </option>
                                                    <option value="en|it">it </option>
                                                    <option value="en|ja">ja </option>
                                                    <option value="en|jw">jw </option>
                                                    <option value="en|kn">kn </option>
                                                    <option value="en|kk">kk </option>
                                                    <option value="en|km">km </option>
                                                    <option value="en|ko">ko </option>
                                                    <option value="en|ku">ku </option>
                                                    <option value="en|ky">ky </option>
                                                    <option value="en|lo">lo </option>
                                                    <option value="en|la">la </option>
                                                    <option value="en|lv">lv </option>
                                                    <option value="en|lt">lt </option>
                                                    <option value="en|lb">lb </option>
                                                    <option value="en|mk">mk </option>
                                                    <option value="en|mg">mg </option>
                                                    <option value="en|ms">ms </option>
                                                    <option value="en|ml">ml </option>
                                                    <option value="en|mt">mt </option>
                                                    <option value="en|mi">mi </option>
                                                    <option value="en|mr">mr </option>
                                                    <option value="en|mn">mn </option>
                                                    <option value="en|my">my </option>
                                                    <option value="en|ne">ne </option>
                                                    <option value="en|no">no </option>
                                                    <option value="en|ps">ps </option>
                                                    <option value="en|fa">fa </option>
                                                    <option value="en|pl">pl </option>
                                                    <option value="en|pt">pt </option>
                                                    <option value="en|pa">pa </option>
                                                    <option value="en|ro">ro </option>
                                                    <option value="en|ru">ru </option>
                                                    <option value="en|sm">sm </option>
                                                    <option value="en|gd">gd </option>
                                                    <option value="en|sr">sr </option>
                                                    <option value="en|st">st </option>
                                                    <option value="en|sn">sn </option>
                                                    <option value="en|sd">sd </option>
                                                    <option value="en|si">si </option>
                                                    <option value="en|sk">sk </option>
                                                    <option value="en|sl">sl </option>
                                                    <option value="en|so">so </option>
                                                    <option value="en|es">es </option>
                                                    <option value="en|su">su </option>
                                                    <option value="en|sw">sw </option>
                                                    <option value="en|sv">sv </option>
                                                    <option value="en|tg">tg </option>
                                                    <option value="en|ta">ta </option>
                                                    <option value="en|te">te </option>
                                                    <option value="en|th">th </option>
                                                    <option value="en|tr">tr </option>
                                                    <option value="en|uk">uk </option>
                                                    <option value="en|ur">ur </option>
                                                    <option value="en|uz">uz </option>
                                                    <option value="en|vi">vi </option>
                                                    <option value="en|cy">cy </option>
                                                    <option value="en|xh">xh </option>
                                                    <option value="en|yi">yi </option>
                                                    <option value="en|yo">yo </option>
                                                    <option value="en|zu">zu </option>
                                                </select>
                                                <div id="google_translate_element2"></div>

                                        </li>
                                    </ul>
                                    <div class="attr-nav align-items-xl-center main-font">
                                        <ul>
                                            <li class="d-none d-xl-inline-block">
                                                <a target="_blank"
                                                    href="http://www.interportglobal.net/Logisys/customervisibility/login.aspx"
                                                    class="butn outline me-3">
                                                    <span>Track a shipment</span>
                                                </a>
                                            </li>
                                            <li class="d-none d-xl-inline-block">
                                                <a href="get-a-quote.php" class="butn primary">
                                                    <span>Get a Quote</span>
                                                </a>
                                            </li>
                                            <li class="d-none d-xl-inline-block">
                                                <select class="language-dropdown" onchange="doGTranslate(this);">
                                                    <option value="">en</option>
                                                    <option value="en|af">Af</option>
                                                    <option value="en|sq">sq</option>
                                                    <option value="en|am">am</option>
                                                    <option value="en|ar">ar</option>
                                                    <option value="en|hy">hy</option>
                                                    <option value="en|az">az</option>
                                                    <option value="en|eu">eu</option>
                                                    <option value="en|be">be</option>
                                                    <option value="en|bn">bn</option>
                                                    <option value="en|bs">bs</option>
                                                    <option value="en|bg">bg</option>
                                                    <option value="en|ca">ca</option>
                                                    <option value="en|ceb">ceb</option>
                                                    <option value="en|ny">ny</option>
                                                    <option value="en|zh-CN">zh-CN</option>
                                                    <option value="en|zh-TW">zh-TW</option>
                                                    <option value="en|co">co</option>
                                                    <option value="en|hr">hr</option>
                                                    <option value="en|cs">cs</option>
                                                    <option value="en|da">da</option>
                                                    <option value="en|nl">nl</option>
                                                    <option value="en|en">en</option>
                                                    <option value="en|eo">eo</option>
                                                    <option value="en|et">et</option>
                                                    <option value="en|tl">tl</option>
                                                    <option value="en|fi">fi</option>
                                                    <option value="en|fr">fr</option>
                                                    <option value="en|fy">fy</option>
                                                    <option value="en|gl">gl </option>
                                                    <option value="en|ka">ka </option>
                                                    <option value="en|de">de </option>
                                                    <option value="en|el">el </option>
                                                    <option value="en|gu">gu </option>
                                                    <option value="en|ht">ht</option>
                                                    <option value="en|ha">ha </option>
                                                    <option value="en|haw">haw</option>
                                                    <option value="en|iw">iw </option>
                                                    <option value="en|hi">hi </option>
                                                    <option value="en|hmn">hmn</option>
                                                    <option value="en|hu">hu</option>
                                                    <option value="en|is">is</option>
                                                    <option value="en|ig">ig </option>
                                                    <option value="en|id">id</option>
                                                    <option value="en|ga">ga </option>
                                                    <option value="en|it">it </option>
                                                    <option value="en|ja">ja </option>
                                                    <option value="en|jw">jw </option>
                                                    <option value="en|kn">kn </option>
                                                    <option value="en|kk">kk </option>
                                                    <option value="en|km">km </option>
                                                    <option value="en|ko">ko </option>
                                                    <option value="en|ku">ku </option>
                                                    <option value="en|ky">ky </option>
                                                    <option value="en|lo">lo </option>
                                                    <option value="en|la">la </option>
                                                    <option value="en|lv">lv </option>
                                                    <option value="en|lt">lt </option>
                                                    <option value="en|lb">lb </option>
                                                    <option value="en|mk">mk </option>
                                                    <option value="en|mg">mg </option>
                                                    <option value="en|ms">ms </option>
                                                    <option value="en|ml">ml </option>
                                                    <option value="en|mt">mt </option>
                                                    <option value="en|mi">mi </option>
                                                    <option value="en|mr">mr </option>
                                                    <option value="en|mn">mn </option>
                                                    <option value="en|my">my </option>
                                                    <option value="en|ne">ne </option>
                                                    <option value="en|no">no </option>
                                                    <option value="en|ps">ps </option>
                                                    <option value="en|fa">fa </option>
                                                    <option value="en|pl">pl </option>
                                                    <option value="en|pt">pt </option>
                                                    <option value="en|pa">pa </option>
                                                    <option value="en|ro">ro </option>
                                                    <option value="en|ru">ru </option>
                                                    <option value="en|sm">sm </option>
                                                    <option value="en|gd">gd </option>
                                                    <option value="en|sr">sr </option>
                                                    <option value="en|st">st </option>
                                                    <option value="en|sn">sn </option>
                                                    <option value="en|sd">sd </option>
                                                    <option value="en|si">si </option>
                                                    <option value="en|sk">sk </option>
                                                    <option value="en|sl">sl </option>
                                                    <option value="en|so">so </option>
                                                    <option value="en|es">es </option>
                                                    <option value="en|su">su </option>
                                                    <option value="en|sw">sw </option>
                                                    <option value="en|sv">sv </option>
                                                    <option value="en|tg">tg </option>
                                                    <option value="en|ta">ta </option>
                                                    <option value="en|te">te </option>
                                                    <option value="en|th">th </option>
                                                    <option value="en|tr">tr </option>
                                                    <option value="en|uk">uk </option>
                                                    <option value="en|ur">ur </option>
                                                    <option value="en|uz">uz </option>
                                                    <option value="en|vi">vi </option>
                                                    <option value="en|cy">cy </option>
                                                    <option value="en|xh">xh </option>
                                                    <option value="en|yi">yi </option>
                                                    <option value="en|yo">yo </option>
                                                    <option value="en|zu">zu </option>
                                                </select>
                                                <div id="google_translate_element2"></div>
                                            </li>
                                        </ul>
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <div class="modal fade" id="getaquote_modal" tabindex="-1" aria-labelledby="centeredLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title" id="centeredLabel">Get a Quote</h3>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <form class="row g-3">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_name" placeholder="Name">
                                            <label for="quote_name">Name</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-1">
                                            <input type="email" class="form-control" id="quote_email"
                                                placeholder="Email">
                                            <label for="quote_email">Email</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_phone"
                                                placeholder="Phone">
                                            <label for="quote_phone">Phone</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected>Freight Type</option>
                                                <option value="1">Freight Type 1</option>
                                                <option value="2">Freight Type 2</option>
                                                <option value="3">Freight Type 3</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_city_of_departure"
                                                placeholder="City of Departure">
                                            <label for="quote_city_of_departure">City of Departure</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_delivery_city"
                                                placeholder="Delivery City">
                                            <label for="quote_delivery_city">Delivery City</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected>Incoterms</option>
                                                <option value="1">Incoterms 1</option>
                                                <option value="2">Incoterms 2</option>
                                                <option value="3">Incoterms 3</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_weight"
                                                placeholder="Weight (kg)">
                                            <label for="quote_weight">Weight (kg)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_height"
                                                placeholder="Height (cm)">
                                            <label for="quote_height">Height (cm)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_width"
                                                placeholder="Width (cm)">
                                            <label for="quote_width">Width (cm)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_length"
                                                placeholder="Length (cm)">
                                            <label for="quote_length">Length (cm)</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="quote_fragile">
                                            <label class="form-check-label" for="quote_fragile">
                                                Fragile
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="quote_express_delivery">
                                            <label class="form-check-label" for="quote_express_delivery">
                                                Express Delivery
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="quote_insurance">
                                            <label class="form-check-label" for="quote_insurance">
                                                Insurance
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="quote_packaging">
                                            <label class="form-check-label" for="quote_packaging">
                                                Packaging
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>
                    <div class="modal-footer justify-content-center">
                        <button type="button" class="butn primary">Save</button>
                    </div>
                </div>
            </div>
        </div>
<style>
    .table tbody tr td {
        text-transform: uppercase;
    }
</style>

<section class="page-title-section main-title-section bg-light">
    <div class="container title-container">
        <div class="row">
            <div class="col-md-12">
                <ul class="wow fadeInUp breadcrump-list" data-wow-delay="400ms">
                    <li><a href="index.php">Home</a></li>
                    <li><a>Resources</a></li>
                    <li>USA Port Codes</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <ul class="usa-port-code-tab nav nav-tabs" id="iatacodesTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="a-tab" data-bs-toggle="tab" data-bs-target="#a" type="button"
                    role="tab" aria-controls="a" aria-selected="true">Alphabetically</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="ab-tab" data-bs-toggle="tab" data-bs-target="#ab" type="button" role="tab"
                    aria-controls="ab" aria-selected="false" tabindex="-1">State wise</button>
            </li>


        </ul>

        <div class="tab-content" id="iatacodesTabContent">
            <div class="tab-pane fade show active" id="a" role="tabpanel" aria-labelledby="a-tab">
                <table class="table text-start red-table" border="0">
                    <thead>

                        <tr>
                            <th scope="col">Port Name</th>
                            <th scope="col">Port Code</th>

                        </tr>
                    </thead>

                    <tbody>

                        <tr>
                            <td> ABERDEEN-HOQUIAM, WASH.</td>
                            </td>
                            <td> 3003</td>
                        </tr>
                        <tr>
                            <td> ADDISON USER FEE AIRPORT, DALLA</td>
                            <td> 5584</td>
                        </tr>
                        <tr>
                            <td> AGUADILLA, PUERTO RICO</td>
                            <td> 4901</td>
                        </tr>
                        <tr>
                            <td> AIR CARGO HANDLING SERVICES, IN</td>
                            <td> 2773</td>
                        </tr>
                        <tr>
                            <td> Air Cargo Handling Services, Sa</td>
                            <td> 2871</td>
                        </tr>
                        <tr>
                            <td> AIR FRANCE (MACH PLUS)</td>
                            <td> 1074</td>
                        </tr>
                        <tr>
                            <td> AIRBORNE AIR PARK</td>
                            <td> 4181</td>
                        </tr>
                        <tr>
                            <td> AIRBORNE EXPRESS, SEATTLE, WA</td>
                            <td> 3074</td>
                        </tr>
                        <tr>
                            <td> AKRON, OHIO</td>
                            <td> 4112</td>
                        </tr>
                        <tr>
                            <td> ALAMEDA, CALIF.</td>
                            <td> 2813</td>
                        </tr>
                        <tr>
                            <td> ALBANY, N.Y.</td>
                            <td> 1002</td>
                        </tr>
                        <tr>
                            <td> ALBUQUERQUE, N.M.</td>
                            <td> 2407</td>
                        </tr>
                        <tr>
                            <td> ALCAN, ALASKA</td>
                            <td> 3104</td>
                        </tr>
                        <tr>
                            <td> ALEXANDRIA BAY, N.Y.</td>
                            <td> 708</td>
                        </tr>
                        <tr>
                            <td> ALEXANDRIA, VA.</td>
                            <td> 5402</td>
                        </tr>
                        <tr>
                            <td> ALGONAC, MICH.</td>
                            <td> 3814</td>
                        </tr>
                        <tr>
                            <td> ALITALIA (ALIEXPRESS)</td>
                            <td> 1077</td>
                        </tr>
                        <tr>
                            <td> ALPENA, MICH.</td>
                            <td> 3843</td>
                        </tr>
                        <tr>
                            <td> AMARILLO, TEXAS</td>
                            <td> 5502</td>
                        </tr>
                        <tr>
                            <td> AMBROSE, N.D.</td>
                            <td> 3410</td>
                        </tr>
                        <tr>
                            <td> ANACORTES, WASH.</td>
                            </td>
                            <td> 3010</td>
                        </tr>
                        <tr>
                            <td> ANCHORAGE, ALASKA</td>
                            <td> 3126</td>
                        </tr>
                        <tr>
                            <td> ANDRADE, CAL.</td>
                            <td> 2502</td>
                        </tr>
                        <tr>
                            <td> ANNAPOLIS, MD.</td>
                            <td> 1301</td>
                        </tr>
                        <tr>
                            <td> ANTLER, N.D.</td>
                            <td> 3413</td>
                        </tr>
                        <tr>
                            <td> ARKANSAS AESOPLEX, BLYTHVILLE,</td>
                            <td> 2083</td>
                        </tr>
                        <tr>
                            <td> ASHLAND, WISCONSIN</td>
                            <td> 3602</td>
                        </tr>
                        <tr>
                            <td> ASHTABULA, OHIO</td>
                            <td> 4108</td>
                        </tr>
                        <tr>
                            <td> ASHTABULA/CONNEAUT, OHIO</td>
                            <td> 4122</td>
                        </tr>
                        <tr>
                            <td> ASTORIA, OREGON</td>
                            <td> 2901</td>
                        </tr>
                        <tr>
                            <td> ATLANTA, GA.</td>
                            <td> 1704</td>
                        </tr>
                        <tr>
                            <td> ATLANTIC CITY USER FEE AIRPORT</td>
                            <td> 1182</td>
                        </tr>
                        <tr>
                            <td> AUSTIN, TEXAS</td>
                            <td> 5506</td>
                        </tr>
                        <tr>
                            <td> AVION BROKERS</td>
                            <td> 3072</td>
                        </tr>
                        <tr>
                            <td> AVONDALE, LA.</td>
                            <td> 2012</td>
                        </tr>
                        <tr>
                            <td> BALTIMORE, MD.</td>
                            <td> 1303</td>
                        </tr>
                        <tr>
                            <td> BALTIMORE-WASHINGTON INTERNATIO</td>
                            <td> 1305</td>
                        </tr>
                        <tr>
                            <td> BATON ROUGE, LA.</td>
                            <td> 2004</td>
                        </tr>
                        <tr>
                            <td> BATTLE CREEK, MICH.</td>
                            <td> 3805</td>
                        </tr>
                        <tr>
                            <td> BAUDETTE, MINN.</td>
                            <td> 3424</td>
                        </tr>
                        <tr>
                            <td> BEAUMONT, TEXAS</td>
                            <td> 2104</td>
                        </tr>
                        <tr>
                            <td> BEECHER FALLS, VERMONT</td>
                            <td> 206</td>
                        </tr>
                        <tr>
                            <td> BELLINGHAM, WASH.</td>
                            </td>
                            <td> 3005</td>
                        </tr>
                        <tr>
                            <td> BINGHAMTON REGIONAL AIRPORT, N.</td>
                            <td> 981</td>
                        </tr>
                        <tr>
                            <td> BIRMINGHAM, ALA.</td>
                            <td> 1904</td>
                        </tr>
                        <tr>
                            <td> BLAINE, WASH.</td>
                            </td>
                            <td> 3004</td>
                        </tr>
                        <tr>
                            <td> BLUEGRASS AIRPORT, LEXINGTON, K</td>
                            <td> 4184</td>
                        </tr>
                        <tr>
                            <td> BOCA GRANDE</td>
                            <td> 1807</td>
                        </tr>
                        <tr>
                            <td> BOISE, IDAHO</td>
                            <td> 2907</td>
                        </tr>
                        <tr>
                            <td> BOSTON, MA</td>
                            <td> 0401</td>
                        </tr>
                        <tr>
                            <td> BOSTON, MASS.</td>
                            <td> 401</td>
                        </tr>
                        <tr>
                            <td> BOUNDARY, WASH.</td>
                            </td>
                            <td> 3015</td>
                        </tr>
                        <tr>
                            <td> BRIDGEPORT, CONN.</td>
                            <td> 410</td>
                        </tr>
                        <tr>
                            <td> BROWNSVILLE-CAMERON, TX.</td>
                            <td> 2301</td>
                        </tr>
                        <tr>
                            <td> BRUNSWICK, GA.</td>
                            <td> 1701</td>
                        </tr>
                        <tr>
                            <td> BUFFALO-NIAGARA FALLS, N.Y.</td>
                            <td> 901</td>
                        </tr>
                        <tr>
                            <td> Burlington Air Express</td>
                            <td> 4170</td>
                        </tr>
                        <tr>
                            <td> BURLINGTON AIT EXPRESS, OHIO</td>
                            <td> 4192</td>
                        </tr>
                        <tr>
                            <td> BURLINGTON, VERMONT</td>
                            <td> 207</td>
                        </tr>
                        <tr>
                            <td> BUTTE, MONTANA</td>
                            <td> 3305</td>
                        </tr>
                        <tr>
                            <td> CALEXICO, CA</td>
                            <td> 2503</td>
                        </tr>
                        <tr>
                            <td> CALEXICO-EAST, CA.</td>
                            <td> 2507</td>
                        </tr>
                        <tr>
                            <td> CAMBRIDGE, MD.</td>
                            <td> 1302</td>
                        </tr>
                        <tr>
                            <td> CAMDEN, N.J.</td>
                            <td> 1107</td>
                        </tr>
                        <tr>
                            <td> CAPE VINCENT, N.Y.</td>
                            <td> 706</td>
                        </tr>
                        <tr>
                            <td> CAPITAN, CALIF.</td>
                            <td> 2715</td>
                        </tr>
                        <tr>
                            <td> CARBURY, N.D.</td>
                            <td> 3421</td>
                        </tr>
                        <tr>
                            <td> CARQUINEZ STRAIT, CALIF.</td>
                            <td> 2830</td>
                        </tr>
                        <tr>
                            <td> CENTENNIAL AIRPORT, CO.</td>
                            <td> 3384</td>
                        </tr>
                        <tr>
                            <td> CHAMPLAIN-ROUSES PT., N.Y.</td>
                            <td> 712</td>
                        </tr>
                        <tr>
                            <td> CHARLESTON, S.C.</td>
                            <td> 1601</td>
                        </tr>
                        <tr>
                            <td> CHARLESTOWN, W. VA.</td>
                            <td> 1409</td>
                        </tr>
                        <tr>
                            <td> CHARLOTTE AMALIE, V.I.</td>
                            <td> 5101</td>
                        </tr>
                        <tr>
                            <td> CHARLOTTE, N.C.</td>
                            <td> 1512</td>
                        </tr>
                        <tr>
                            <td> CHATTANOOGA, TENN.</td>
                            <td> 2008</td>
                        </tr>
                        <tr>
                            <td> CHENNAI</td>
                            <td> 5335</td>
                        </tr>
                        <tr>
                            <td> CHESTER, PA.</td>
                            <td> 1102</td>
                        </tr>
                        <tr>
                            <td> CHICAGO, ILLINOIS</td>
                            <td> 3901</td>
                        </tr>
                        <tr>
                            <td> CHRISTIANSTED, V.I.</td>
                            <td> 5104</td>
                        </tr>
                        <tr>
                            <td> CINCINNATI-LAWRENCEBURG</td>
                            <td> 4102</td>
                        </tr>
                        <tr>
                            <td> CLAYTON, N.Y.</td>
                            <td> 714</td>
                        </tr>
                        <tr>
                            <td> CLEVELAND, OHIO</td>
                            <td> 4101</td>
                        </tr>
                        <tr>
                            <td> COLUMBIA, SOUTH CAROLINA</td>
                            <td> 1604</td>
                        </tr>
                        <tr>
                            <td> COLUMBUS, N.M.</td>
                            <td> 2406</td>
                        </tr>
                        <tr>
                            <td> COLUMBUS, OHIO</td>
                            <td> 4103</td>
                        </tr>
                        <tr>
                            <td> CONNEAUT, OHIO</td>
                            <td> 4109</td>
                        </tr>
                        <tr>
                            <td> COOS BAY, OREGON</td>
                            <td> 2903</td>
                        </tr>
                        <tr>
                            <td> CORAL BAY, V.I.</td>
                            <td> 5103</td>
                        </tr>
                        <tr>
                            <td> CORPUS CHRISTI, TEXAS</td>
                            <td> 5312</td>
                        </tr>
                        <tr>
                            <td> CRISFIELD, MD.</td>
                            <td> 1304</td>
                        </tr>
                        <tr>
                            <td> CROCKETT, CALIF.</td>
                            <td> 2815</td>
                        </tr>
                        <tr>
                            <td> CRUZ BAY, V.I.</td>
                            <td> 5102</td>
                        </tr>
                        <tr>
                            <td> DALLAS-FORT WORTH, TEXAS</td>
                            <td> 5501</td>
                        </tr>
                        <tr>
                            <td> DALTON CACHE, ALASKA</td>
                            <td> 3106</td>
                        </tr>
                        <tr>
                            <td> DANVILLE, WASH.</td>
                            </td>
                            <td> 3012</td>
                        </tr>
                        <tr>
                            <td> DAVENPOR IA ROCK IS MOLINE IL</td>
                            <td> 3908</td>
                        </tr>
                        <tr>
                            <td> DAYTON, OHIO</td>
                            <td> 4104</td>
                        </tr>
                        <tr>
                            <td> DAYTONA BEACH AIRPORT</td>
                            <td> 1884</td>
                        </tr>
                        <tr>
                            <td> DECATUR USER FEE AIRPORT, DECAT</td>
                            <td> 3985</td>
                        </tr>
                        <tr>
                            <td> DEL BONITA, MONTANA</td>
                            <td> 3322</td>
                        </tr>
                        <tr>
                            <td> DEL RIO, TEXAS</td>
                            <td> 2302</td>
                        </tr>
                        <tr>
                            <td> DENVER, COLORADO</td>
                            <td> 3307</td>
                        </tr>
                        <tr>
                            <td> DERBY LINE, VERMONT</td>
                            <td> 209</td>
                        </tr>
                        <tr>
                            <td> DES MOINES, IOWA</td>
                            <td> 3907</td>
                        </tr>
                        <tr>
                            <td> DESTREHAN, LA.</td>
                            <td> 2009</td>
                        </tr>
                        <tr>
                            <td> DETOUR CITY, MICH.</td>
                            <td> 3819</td>
                        </tr>
                        <tr>
                            <td> DETROIT, MICHIGAN</td>
                            <td> 3801</td>
                        </tr>
                        <tr>
                            <td> DHL WORLDWIDE EXPRESS</td>
                            <td> 3073</td>
                        </tr>
                        <tr>
                            <td> DHL Worldwide Express, San Fran</td>
                            <td> 2870</td>
                        </tr>
                        <tr>
                            <td> DHL, CINCINNATI, OHIO</td>
                            <td> 4197</td>
                        </tr>
                        <tr>
                            <td> DHL, JAMAICA, NY</td>
                            <td> 1072</td>
                        </tr>
                        <tr>
                            <td> DHL, LOS ANGELES, CA</td>
                            <td> 2770</td>
                        </tr>
                        <tr>
                            <td> DHL, MIAMI, FL</td>
                            <td> 5271</td>
                        </tr>
                        <tr>
                            <td> DOUGLAS, ARIZ.</td>
                            <td> 2601</td>
                        </tr>
                        <tr>
                            <td> DULUTH, MINN.</td>
                            <td> 3601</td>
                        </tr>
                        <tr>
                            <td> DUNSEITH, N.D.</td>
                            <td> 3422</td>
                        </tr>
                        <tr>
                            <td> DUPAGE AIRPORT, ILLINOIS</td>
                            <td> 4185</td>
                        </tr>
                        <tr>
                            <td> DURHAM, N.C.</td>
                            <td> 1503</td>
                        </tr>
                        <tr>
                            <td> DWORKIN/COSELL COURIER</td>
                            <td> 1075</td>
                        </tr>
                        <tr>
                            <td> EAGLE PASS, TEXAS</td>
                            <td> 2303</td>
                        </tr>
                        <tr>
                            <td> EAST CHICAGO, INDIANA</td>
                            <td> 3904</td>
                        </tr>
                        <tr>
                            <td> EASTPORT, IDAHO</td>
                            <td> 3302</td>
                        </tr>
                        <tr>
                            <td> EL PASO, TEXAS</td>
                            <td> 2402</td>
                        </tr>
                        <tr>
                            <td> EL SEGUNDO, CALIF.</td>
                            <td> 2711</td>
                        </tr>
                        <tr>
                            <td> EMERY WORLD-WIDE, DAYTON,OH</td>
                            <td> 4195</td>
                        </tr>
                        <tr>
                            <td> EMERY WORLDWIDE</td>
                            <td> 1073</td>
                        </tr>
                        <tr>
                            <td> ERIE, PENNSYLVANIA</td>
                            <td> 4106</td>
                        </tr>
                        <tr>
                            <td> ESCANABA, MICH.</td>
                            <td> 3808</td>
                        </tr>
                        <tr>
                            <td> EUREKA, CALIF.</td>
                            <td> 2802</td>
                        </tr>
                        <tr>
                            <td> EVERETT, WASH.</td>
                            </td>
                            <td> 3006</td>
                        </tr>
                        <tr>
                            <td> FABENS, TEXAS</td>
                            <td> 2404</td>
                        </tr>
                        <tr>
                            <td> FAIRBANKS, ALASKA</td>
                            <td> 3111</td>
                        </tr>
                        <tr>
                            <td> FAIRPORT, OHIO</td>
                            <td> 4111</td>
                        </tr>
                        <tr>
                            <td> FAJARDO, PUERTO RICO</td>
                            <td> 4904</td>
                        </tr>
                        <tr>
                            <td> FALL RIVER, MASS.</td>
                            <td> 407</td>
                        </tr>
                        <tr>
                            <td> FED EXPRESS, ANCHORAGE</td>
                            <td> 3195</td>
                        </tr>
                        <tr>
                            <td> FEDERAL EXPRESS</td>
                            <td> 2095</td>
                        </tr>
                        <tr>
                            <td> FEDERAL EXPRESS COURIER FACILIT</td>
                            <td> 2895</td>
                        </tr>
                        <tr>
                            <td> FEDERAL EXPRESS CURRIER</td>
                            <td> 2991</td>
                        </tr>
                        <tr>
                            <td> FEDERAL EXPRESS, JAMAICA, NY</td>
                            <td> 1070</td>
                        </tr>
                        <tr>
                            <td> FEDEX COURIER HUB FACILITY, IND</td>
                            <td> 4198</td>
                        </tr>
                        <tr>
                            <td> FERNANDINA, FLA.</td>
                            <td> 1805</td>
                        </tr>
                        <tr>
                            <td> FERRY, WASH.</td>
                            </td>
                            <td> 3013</td>
                        </tr>
                        <tr>
                            <td> FERRYSBURG, MICH.</td>
                            <td> 3844</td>
                        </tr>
                        <tr>
                            <td> FORT COVINGTON, N.Y.</td>
                            <td> 705</td>
                        </tr>
                        <tr>
                            <td> FORT MYERS AIRPORT, FLORIDA</td>
                            <td> 1822</td>
                        </tr>
                        <tr>
                            <td> FORT PIERCE, FLA.</td>
                            <td> 5205</td>
                        </tr>
                        <tr>
                            <td> FORT WAYNE AIRPORT</td>
                            <td> 4183</td>
                        </tr>
                        <tr>
                            <td> FORT WORTH ALLIANCE AIRPORT, TX</td>
                            <td> 5583</td>
                        </tr>
                        <tr>
                            <td> FORTUNA, N.D.</td>
                            <td> 3417</td>
                        </tr>
                        <tr>
                            <td> FREDERIKSTED, V.I.</td>
                            <td> 5105</td>
                        </tr>
                        <tr>
                            <td> FREEPORT, TEXAS</td>
                            <td> 5311</td>
                        </tr>
                        <tr>
                            <td> FRESNO, CALIF.</td>
                            <td> 2803</td>
                        </tr>
                        <tr>
                            <td> FRIDAY HARBOR, WASH.</td>
                            </td>
                            <td> 3014</td>
                        </tr>
                        <tr>
                            <td> FRONT ROYAL, VA.</td>
                            <td> 1410</td>
                        </tr>
                        <tr>
                            <td> FRONTIER, WASH.</td>
                            </td>
                            <td> 3020</td>
                        </tr>
                        <tr>
                            <td> GALVESTON, TEXAS</td>
                            <td> 5310</td>
                        </tr>
                        <tr>
                            <td> GARY, INDIANA</td>
                            <td> 3905</td>
                        </tr>
                        <tr>
                            <td> GATEWAY FREIGHT SERVICES, LAX</td>
                            <td> 2772</td>
                        </tr>
                        <tr>
                            <td> GEORGETOWN, S.C.</td>
                            <td> 1602</td>
                        </tr>
                        <tr>
                            <td> GLOUCESTER CITY, N.J.</td>
                            <td> 1113</td>
                        </tr>
                        <tr>
                            <td> GLOUCESTER, MASS.</td>
                            <td> 404</td>
                        </tr>
                        <tr>
                            <td> GOOD HOPE, LA.</td>
                            <td> 2014</td>
                        </tr>
                        <tr>
                            <td> GRAMERCY, LA.</td>
                            <td> 2010</td>
                        </tr>
                        <tr>
                            <td> GRAND HAVEN, MICH.</td>
                            <td> 3816</td>
                        </tr>
                        <tr>
                            <td> GRAND PORTAGE, MINN.</td>
                            <td> 3613</td>
                        </tr>
                        <tr>
                            <td> GRAND RAPIDS, MICH.</td>
                            <td> 3806</td>
                        </tr>
                        <tr>
                            <td> GRANT COUNTY USER-FEE AIRPORT,</td>
                            <td> 3082</td>
                        </tr>
                        <tr>
                            <td> GREAT FALLS, MONTANA</td>
                            <td> 3304</td>
                        </tr>
                        <tr>
                            <td> GREATER ROCKFORD AIRPORT, ROCKF</td>
                            <td> 3982</td>
                        </tr>
                        <tr>
                            <td> GREEN BAY, WISCONSIN</td>
                            <td> 3703</td>
                        </tr>
                        <tr>
                            <td> GREENVILLE, MISS.</td>
                            <td> 2011</td>
                        </tr>
                        <tr>
                            <td> GREENVILLE-SPTBURG, S.C.</td>
                            <td> 1603</td>
                        </tr>
                        <tr>
                            <td> GUANICA, PUERTO RICO</td>
                            <td> 4905</td>
                        </tr>
                        <tr>
                            <td> GUAYANILLA, PUERTO RICO</td>
                            <td> 4912</td>
                        </tr>
                        <tr>
                            <td> GULFPORT, MISS.</td>
                            <td> 1902</td>
                        </tr>
                        <tr>
                            <td> HALIFAX, CN</td>
                            <td> 0001</td>
                        </tr>
                        <tr>
                            <td> HANNAH, N.D.</td>
                            <td> 3408</td>
                        </tr>
                        <tr>
                            <td> HANSBORO, N.D.</td>
                            <td> 3415</td>
                        </tr>
                        <tr>
                            <td> HARRISBURG, PA.</td>
                            <td> 1109</td>
                        </tr>
                        <tr>
                            <td> HARTFORD, CONN.</td>
                            <td> 411</td>
                        </tr>
                        <tr>
                            <td> HECTOR INTERNATIONAL AIRPORT</td>
                            <td> 3481</td>
                        </tr>
                        <tr>
                            <td> HIGHGATE SPRINGS-ALBURG, VT</td>
                            <td> 212</td>
                        </tr>
                        <tr>
                            <td> HILDAGO, TEXAS</td>
                            <td> 2305</td>
                        </tr>
                        <tr>
                            <td> HILO, HAWAII</td>
                            <td> 3202</td>
                        </tr>
                        <tr>
                            <td> HONOLULU INT. AIRPORT</td>
                            <td> 3205</td>
                        </tr>
                        <tr>
                            <td> HONOLULU, HAWAII</td>
                            <td> 3201</td>
                        </tr>
                        <tr>
                            <td> HOPEWELL, VA.</td>
                            <td> 1408</td>
                        </tr>
                        <tr>
                            <td> HOUSTON INTERCONTINENTAL AIR</td>
                            <td> 5309</td>
                        </tr>
                        <tr>
                            <td> HOUSTON, TEXAS</td>
                            <td> 5301</td>
                        </tr>
                        <tr>
                            <td> HULMAN REGIONAL AIRPORT, INDIAN</td>
                            <td> 3984</td>
                        </tr>
                        <tr>
                            <td> HUMACAO, PUERTO RICO</td>
                            <td> 4906</td>
                        </tr>
                        <tr>
                            <td> HUNTSVILLE, ALA.</td>
                            <td> 1910</td>
                        </tr>
                        <tr>
                            <td> HURON, OHIO</td>
                            <td> 4117</td>
                        </tr>
                        <tr>
                            <td> IBC PACIFIC, CALIFORNIA</td>
                            <td> 2776</td>
                        </tr>
                        <tr>
                            <td> IBC PACIFIC, CALIFORNIA</td>
                            <td> 2873</td>
                        </tr>
                        <tr>
                            <td> INDIANAPOLIS, IND.</td>
                            <td> 4110</td>
                        </tr>
                        <tr>
                            <td> INT. FALLS-RANIER, MINN.</td>
                            <td> 3604</td>
                        </tr>
                        <tr>
                            <td> INTERNATIONAL COURIER ASSOC.</td>
                            <td> 5270</td>
                        </tr>
                        <tr>
                            <td> J.F.K. INT. AIRPORT, N.Y.</td>
                            <td> 1012</td>
                        </tr>
                        <tr>
                            <td> JACKSONVILLE, FLA.</td>
                            <td> 1803</td>
                        </tr>
                        <tr>
                            <td> JOBOS, PUERTO RICO</td>
                            <td> 4911</td>
                        </tr>
                        <tr>
                            <td> JUNEAU, ALASKA</td>
                            <td> 3101</td>
                        </tr>
                        <tr>
                            <td> KAHULUI, HAWAII</td>
                            <td> 3203</td>
                        </tr>
                        <tr>
                            <td> KALAMA, WASH.</td>
                            </td>
                            <td> 2909</td>
                        </tr>
                        <tr>
                            <td> KANSAS CITY, MISSOURI</td>
                            <td> 4501</td>
                        </tr>
                        <tr>
                            <td> KENMORE AIR HARBOR, WASH.</td>
                            </td>
                            <td> 3018</td>
                        </tr>
                        <tr>
                            <td> KETCHIKAN, ALASKA</td>
                            <td> 3102</td>
                        </tr>
                        <tr>
                            <td> KEY WEST, FLORIDA</td>
                            <td> 5202</td>
                        </tr>
                        <tr>
                            <td> KINGSLEY FIELD KLAMATH FALLS, O</td>
                            <td> 2981</td>
                        </tr>
                        <tr>
                            <td> KNOXVILLE, TENN.</td>
                            <td> 2016</td>
                        </tr>
                        <tr>
                            <td> KODIAK, ALASKA</td>
                            <td> 3127</td>
                        </tr>
                        <tr>
                            <td> KONA, HAWAII</td>
                            <td> 3206</td>
                        </tr>
                        <tr>
                            <td> L.A. INT. AIRPORT, CALIF.</td>
                            <td> 2720</td>
                        </tr>
                        <tr>
                            <td> LAKE CHARLES, LA.</td>
                            <td> 2017</td>
                        </tr>
                        <tr>
                            <td> LAREDO, TEXAS</td>
                            <td> 2304</td>
                        </tr>
                        <tr>
                            <td> LAS VEGAS, NEVADA</td>
                            <td> 2722</td>
                        </tr>
                        <tr>
                            <td> LAURIER, WASH.</td>
                            </td>
                            <td> 3016</td>
                        </tr>
                        <tr>
                            <td> LAWRENCE, MASS.</td>
                            <td> 416</td>
                        </tr>
                        <tr>
                            <td> LEHIGH VALLEY, PA</td>
                            <td> 1119</td>
                        </tr>
                        <tr>
                            <td> LITTLE ROCK-N.L.R., ARK.</td>
                            <td> 2003</td>
                        </tr>
                        <tr>
                            <td> LOGAN AIRPORT-BOSTON, MASS.</td>
                            <td> 417</td>
                        </tr>
                        <tr>
                            <td> LONG BEACH, CALIF.</td>
                            <td> 2709</td>
                        </tr>
                        <tr>
                            <td> LONGVIEW, WASH.</td>
                            </td>
                            <td> 2905</td>
                        </tr>
                        <tr>
                            <td> LORAIN, OHIO</td>
                            <td> 4121</td>
                        </tr>
                        <tr>
                            <td> LOS ANGELES, CALIF.</td>
                            <td> 2704</td>
                        </tr>
                        <tr>
                            <td> LOUISVILLE, KY.</td>
                            <td> 4115</td>
                        </tr>
                        <tr>
                            <td> LOW VALUE SHIPMENTS</td>
                            <td> 7000</td>
                        </tr>
                        <tr>
                            <td> Low-Value Estimates</td>
                            <td> 7070</td>
                        </tr>
                        <tr>
                            <td> LUBBOCK, TEXAS</td>
                            <td> 5503</td>
                        </tr>
                        <tr>
                            <td> LUKEVILLE, ARIZ.</td>
                            <td> 2602</td>
                        </tr>
                        <tr>
                            <td> LYNDEN, WASH.</td>
                            </td>
                            <td> 3023</td>
                        </tr>
                        <tr>
                            <td> MACKINAC ISLAND, MICH.</td>
                            <td> 3820</td>
                        </tr>
                        <tr>
                            <td> MAIDA, N.D.</td>
                            <td> 3416</td>
                        </tr>
                        <tr>
                            <td> MAIL SHIPMENTS</td>
                            <td> 8000</td>
                        </tr>
                        <tr>
                            <td> MANITOWOC, WISCONSIN</td>
                            <td> 3706</td>
                        </tr>
                        <tr>
                            <td> MARINETTE, WISCONSIN</td>
                            <td> 3702</td>
                        </tr>
                        <tr>
                            <td> MARQUETTE, MICH.</td>
                            <td> 3809</td>
                        </tr>
                        <tr>
                            <td> MARTINEZ, CALIF.</td>
                            <td> 2820</td>
                        </tr>
                        <tr>
                            <td> MASSENA, N.Y.</td>
                            <td> 704</td>
                        </tr>
                        <tr>
                            <td> MAYAGUES, PUERTO RICO</td>
                            <td> 4907</td>
                        </tr>
                        <tr>
                            <td> MEDFORD-JACKSON COUNTY AIRPORT</td>
                            <td> 2982</td>
                        </tr>
                        <tr>
                            <td> MELBOURNE REGIONAL AIRPORT, FLA</td>
                            <td> 1885</td>
                        </tr>
                        <tr>
                            <td> MELLVILLE, R.I.</td>
                            <td> 503</td>
                        </tr>
                        <tr>
                            <td> MEMPHIS, TENN.</td>
                            <td> 2006</td>
                        </tr>
                        <tr>
                            <td> METALINE FALLS, WASH.</td>
                            </td>
                            <td> 3025</td>
                        </tr>
                        <tr>
                            <td> MIAMI INT AIRPORT, CARGO FACILI</td>
                            <td> 5272</td>
                        </tr>
                        <tr>
                            <td> MIAMI INT. AIRPORT, FLA.</td>
                            <td> 5206</td>
                        </tr>
                        <tr>
                            <td> MIAMI, FLORIDA</td>
                            <td> 5201</td>
                        </tr>
                        <tr>
                            <td> MIDLAND INTERNATIONAL AIR</td>
                            <td> 5582</td>
                        </tr>
                        <tr>
                            <td> MILWAUKEE, WISCONSIN</td>
                            <td> 3701</td>
                        </tr>
                        <tr>
                            <td> MINNEAP.-ST. PAUL, MINN.</td>
                            <td> 3501</td>
                        </tr>
                        <tr>
                            <td> MOBILE, ALA.</td>
                            <td> 1901</td>
                        </tr>
                        <tr>
                            <td> MONTEREY, CALIF.</td>
                            <td> 2805</td>
                        </tr>
                        <tr>
                            <td> MONTREAL CANADA</td>
                            <td> 6001</td>
                        </tr>
                        <tr>
                            <td> MOREHEAD-BEAUFORT, N.C.</td>
                            <td> 1511</td>
                        </tr>
                        <tr>
                            <td> MORGAN CITY, LA.</td>
                            <td> 2001</td>
                        </tr>
                        <tr>
                            <td> MORGAN, MONTANA</td>
                            <td> 3319</td>
                        </tr>
                        <tr>
                            <td> MORRISTOWN AIRPORT, NEWARK, NJ</td>
                            <td> 1081</td>
                        </tr>
                        <tr>
                            <td> MORRO, CALIF.</td>
                            <td> 2719</td>
                        </tr>
                        <tr>
                            <td> MUSKEGON, MICH.</td>
                            <td> 3815</td>
                        </tr>
                        <tr>
                            <td> MYRTLE BEACH INTERNATIONAL AIRP</td>
                            <td> 1681</td>
                        </tr>
                        <tr>
                            <td> NACO, ARIZONA</td>
                            <td> 2603</td>
                        </tr>
                        <tr>
                            <td> NASHVILLE, TENN.</td>
                            <td> 2007</td>
                        </tr>
                        <tr>
                            <td> NATRONA COUNTY INTERNATIONAL AI</td>
                            <td> 3382</td>
                        </tr>
                        <tr>
                            <td> NAWILIWILT-PT ALLEN, HAWAII</td>
                            <td> 3204</td>
                        </tr>
                        <tr>
                            <td> NEAH BAY, WASH.</td>
                            </td>
                            <td> 3027</td>
                        </tr>
                        <tr>
                            <td> NECHE, N.D.</td>
                            <td> 3404</td>
                        </tr>
                        <tr>
                            <td> NEW BEDFORD, MASS.</td>
                            <td> 405</td>
                        </tr>
                        <tr>
                            <td> NEW HAVEN, CONN.</td>
                            <td> 412</td>
                        </tr>
                        <tr>
                            <td> NEW LONDON, CONN.</td>
                            <td> 413</td>
                        </tr>
                        <tr>
                            <td> NEW ORLEANS, LA.</td>
                            <td> 2002</td>
                        </tr>
                        <tr>
                            <td> NEW RIVER VALLEY AIRPORT, DUBLI</td>
                            <td> 1481</td>
                        </tr>
                        <tr>
                            <td> NEW YORK, N.Y.</td>
                            <td> 1001</td>
                        </tr>
                        <tr>
                            <td> NEWARK FEDEX ECCF, NEWARK, NJ</td>
                            <td> 1068</td>
                        </tr>
                        <tr>
                            <td> NEWARK, NJ</td>
                            <td> 4601</td>
                        </tr>
                        <tr>
                            <td> NEWPORT NEWS, VA.</td>
                            <td> 1402</td>
                        </tr>
                        <tr>
                            <td> NEWPORT, OREGON</td>
                            <td> 2902</td>
                        </tr>
                        <tr>
                            <td> NEWPORT, R.I.</td>
                            <td> 501</td>
                        </tr>
                        <tr>
                            <td> NIGHTHAWK, WASH.</td>
                            </td>
                            <td> 3011</td>
                        </tr>
                        <tr>
                            <td> NIPPON COURIER HUB, CHICAGO,IL</td>
                            <td> 3991</td>
                        </tr>
                        <tr>
                            <td> NOGALES, ARIZ.</td>
                            <td> 2604</td>
                        </tr>
                        <tr>
                            <td> NOONAN, N.D.</td>
                            <td> 3420</td>
                        </tr>
                        <tr>
                            <td> NORFOLK, VA.</td>
                            <td> 1401</td>
                        </tr>
                        <tr>
                            <td> NORFOLK/MOBILE/CHARLESTON E</td>
                            <td> 5901</td>
                        </tr>
                        <tr>
                            <td> NORTHGATE, N.D.</td>
                            <td> 3406</td>
                        </tr>
                        <tr>
                            <td> NORTON, VERMONT</td>
                            <td> 211</td>
                        </tr>
                        <tr>
                            <td> NOYES, MINN.</td>
                            <td> 3402</td>
                        </tr>
                        <tr>
                            <td> NYACC, JAMAICA, NY</td>
                            <td> 1071</td>
                        </tr>
                        <tr>
                            <td> OAKLAND, CALIF.</td>
                            <td> 2811</td>
                        </tr>
                        <tr>
                            <td> OAKLAND-PONTIAC AIRPORT, MI</td>
                            <td> 3881</td>
                        </tr>
                        <tr>
                            <td> OCALA REGIONAL AIRPORT, FLORIDA</td>
                            <td> 1886</td>
                        </tr>
                        <tr>
                            <td> OGDENSBURG, N.Y.</td>
                            <td> 701</td>
                        </tr>
                        <tr>
                            <td> OKLAHOMA CITY, OKLAHOMA</td>
                            <td> 5504</td>
                        </tr>
                        <tr>
                            <td> OLYMPIA, WASH.</td>
                            </td>
                            <td> 3026</td>
                        </tr>
                        <tr>
                            <td> OMAHA, NEBRASKA</td>
                            <td> 3903</td>
                        </tr>
                        <tr>
                            <td> ONTARIO INTERNATIONAL AIRPORT,</td>
                            <td> 2721</td>
                        </tr>
                        <tr>
                            <td> OPHEIM, MONTANA</td>
                            <td> 3317</td>
                        </tr>
                        <tr>
                            <td> ORANGE, TEXAS</td>
                            <td> 2103</td>
                        </tr>
                        <tr>
                            <td> ORLANDO, FLA.</td>
                            <td> 1808</td>
                        </tr>
                        <tr>
                            <td> ORLANDO-SANFORD AIRPORT, FL.</td>
                            <td> 1809</td>
                        </tr>
                        <tr>
                            <td> OROVILLE, WASH.</td>
                            </td>
                            <td> 3019</td>
                        </tr>
                        <tr>
                            <td> OSWEGO, N.Y.</td>
                            <td> 904</td>
                        </tr>
                        <tr>
                            <td> OTAY MESA STATION</td>
                            <td> 2506</td>
                        </tr>
                        <tr>
                            <td> OWENSBORO-EVANSVILLE</td>
                            <td> 4116</td>
                        </tr>
                        <tr>
                            <td> PAL-WAUKEE USER FEE AIRPORT, WH</td>
                            <td> 3983</td>
                        </tr>
                        <tr>
                            <td> PALM SPRINGS REGIONAL AIRPORT,</td>
                            <td> 2781</td>
                        </tr>
                        <tr>
                            <td> PANAMA CITY, FLA.</td>
                            <td> 1818</td>
                        </tr>
                        <tr>
                            <td> PASCAGOULA, MISS.</td>
                            <td> 1903</td>
                        </tr>
                        <tr>
                            <td> PAULSBORO, N.J.</td>
                            <td> 1105</td>
                        </tr>
                        <tr>
                            <td> PELICAN, ALASKA</td>
                            <td> 3124</td>
                        </tr>
                        <tr>
                            <td> PEMBINA, N.D.</td>
                            <td> 3401</td>
                        </tr>
                        <tr>
                            <td> PENSACOLA, FLA.</td>
                            <td> 1819</td>
                        </tr>
                        <tr>
                            <td> PEORIA, ILLINOIS</td>
                            <td> 3902</td>
                        </tr>
                        <tr>
                            <td> PERTH AMBOY, N.J.</td>
                            <td> 1004</td>
                        </tr>
                        <tr>
                            <td> PETERSBURG, ALASKA</td>
                            <td> 3112</td>
                        </tr>
                        <tr>
                            <td> PHILADELPHIA INT’L AIRPORT</td>
                            <td> 1108</td>
                        </tr>
                        <tr>
                            <td> PHILADELPHIA, PA.</td>
                            <td> 1101</td>
                        </tr>
                        <tr>
                            <td> PHOENIX, ARIZ.</td>
                            <td> 2605</td>
                        </tr>
                        <tr>
                            <td> PIEGAN, MONTANA</td>
                            <td> 3316</td>
                        </tr>
                        <tr>
                            <td> PINECREEK, MINN.</td>
                            <td> 3425</td>
                        </tr>
                        <tr>
                            <td> PITTSBURGH, PA.</td>
                            <td> 1104</td>
                        </tr>
                        <tr>
                            <td> PLYMOUTH, MASS.</td>
                            <td> 406</td>
                        </tr>
                        <tr>
                            <td> POINT ROBERTS, WASH.</td>
                            </td>
                            <td> 3017</td>
                        </tr>
                        <tr>
                            <td> PONCE, PUERTO RICO</td>
                            <td> 4908</td>
                        </tr>
                        <tr>
                            <td> PORT ANGELES, WASH.</td>
                            </td>
                            <td> 3007</td>
                        </tr>
                        <tr>
                            <td> PORT ARTHUR, TEXAS</td>
                            <td> 2101</td>
                        </tr>
                        <tr>
                            <td> PORT CANAVERAL, FLA.</td>
                            <td> 1816</td>
                        </tr>
                        <tr>
                            <td> PORT HUENEME, CALIF.</td>
                            <td> 2713</td>
                        </tr>
                        <tr>
                            <td> PORT HURON, MICHIGAN</td>
                            <td> 3802</td>
                        </tr>
                        <tr>
                            <td> PORT LAVACA, TEXAS</td>
                            <td> 5313</td>
                        </tr>
                        <tr>
                            <td> PORT MANATEE</td>
                            <td> 1821</td>
                        </tr>
                        <tr>
                            <td> PORT OF ROCKFORT, ROCKFORT, IL</td>
                            <td> 3909</td>
                        </tr>
                        <tr>
                            <td> PORT SAN LUIS, CALIF.</td>
                            <td> 2707</td>
                        </tr>
                        <tr>
                            <td> PORT SULPHUR, LA.</td>
                            <td> 2005</td>
                        </tr>
                        <tr>
                            <td> PORT TOWNSEND, WASH.</td>
                            </td>
                            <td> 3008</td>
                        </tr>
                        <tr>
                            <td> PORTAL, N.D.</td>
                            <td> 3403</td>
                        </tr>
                        <tr>
                            <td> PORTHILL, IDAHO</td>
                            <td> 3308</td>
                        </tr>
                        <tr>
                            <td> PORTLAND INTERNATIONAL AIRPORT</td>
                            <td> 2910</td>
                        </tr>
                        <tr>
                            <td> PORTLAND, OREGON</td>
                            <td> 2904</td>
                        </tr>
                        <tr>
                            <td> PRESIDIO, TEXAS</td>
                            <td> 2403</td>
                        </tr>
                        <tr>
                            <td> PRESQUE ISLE, MICH.</td>
                            <td> 3842</td>
                        </tr>
                        <tr>
                            <td> PROGRESSO, TEXAS</td>
                            <td> 2309</td>
                        </tr>
                        <tr>
                            <td> PROVIDENCE, R.I.</td>
                            <td> 502</td>
                        </tr>
                        <tr>
                            <td> PROVINCETOWN, MASS.</td>
                            <td> 409</td>
                        </tr>
                        <tr>
                            <td> PT. EVERGLADES, FLORIDA</td>
                            <td> 5203</td>
                        </tr>
                        <tr>
                            <td> RACINE, WISCONSIN</td>
                            <td> 3708</td>
                        </tr>
                        <tr>
                            <td> RAYMOND, MONTANA</td>
                            <td> 3301</td>
                        </tr>
                        <tr>
                            <td> REDWOOD CITY, CALIF.</td>
                            <td> 2821</td>
                        </tr>
                        <tr>
                            <td> REIDSVILLE, N.C.</td>
                            <td> 1506</td>
                        </tr>
                        <tr>
                            <td> RENO, NEVADA</td>
                            <td> 2833</td>
                        </tr>
                        <tr>
                            <td> RICHFORD, VERMONT</td>
                            <td> 203</td>
                        </tr>
                        <tr>
                            <td> RICHMOND, CALIF.</td>
                            <td> 2812</td>
                        </tr>
                        <tr>
                            <td> RICHMOND-PETERSBURG, VA.</td>
                            <td> 1404</td>
                        </tr>
                        <tr>
                            <td> RICKENBACKER AIRPORT,OH</td>
                            <td> 4182</td>
                        </tr>
                        <tr>
                            <td> RIO GRANDE CITY, TEXAS</td>
                            <td> 2307</td>
                        </tr>
                        <tr>
                            <td> ROCHESTER, MINN. USER FEE AIRPO</td>
                            <td> 3581</td>
                        </tr>
                        <tr>
                            <td> ROCHESTER, N.Y.</td>
                            <td> 903</td>
                        </tr>
                        <tr>
                            <td> ROGERS CITY, MICH.</td>
                            <td> 3818</td>
                        </tr>
                        <tr>
                            <td> ROMA, TEXAS</td>
                            <td> 2310</td>
                        </tr>
                        <tr>
                            <td> ROOSVILLE, MONTANA</td>
                            <td> 3318</td>
                        </tr>
                        <tr>
                            <td> ROSEAU, MINN.</td>
                            <td> 3426</td>
                        </tr>
                        <tr>
                            <td> S.F. INT. AIRPORT, CALIF.</td>
                            <td> 2801</td>
                        </tr>
                        <tr>
                            <td> SABINE, TEXAS</td>
                            <td> 2102</td>
                        </tr>
                        <tr>
                            <td> SACRAMENTO, CALIF.</td>
                            <td> 2816</td>
                        </tr>
                        <tr>
                            <td> SAGINAW-BAY CITY, MICH.</td>
                            <td> 3804</td>
                        </tr>
                        <tr>
                            <td> SALEM, MASS.</td>
                            <td> 408</td>
                        </tr>
                        <tr>
                            <td> SALT LAKE CITY, UTAH</td>
                            <td> 3303</td>
                        </tr>
                        <tr>
                            <td> SAN ANTONIO, TEXAS</td>
                            <td> 5507</td>
                        </tr>
                        <tr>
                            <td> SAN DIEGO, CAL.</td>
                            <td> 2501</td>
                        </tr>
                        <tr>
                            <td> SAN FRANCISCO, CALIF.</td>
                            <td> 2809</td>
                        </tr>
                        <tr>
                            <td> SAN JOAQUIN RIVER, CALIF.</td>
                            <td> 2828</td>
                        </tr>
                        <tr>
                            <td> SAN JOSE INTERNATIONAL AIRPORT</td>
                            <td> 2834</td>
                        </tr>
                        <tr>
                            <td> SAN JUAN INT. AIRPORT, P.R.</td>
                            <td> 4913</td>
                        </tr>
                        <tr>
                            <td> SAN JUAN, PUERTO RICO</td>
                            <td> 4909</td>
                        </tr>
                        <tr>
                            <td> SAN LUIS, ARIZ.</td>
                            <td> 2608</td>
                        </tr>
                        <tr>
                            <td> SAN PABLO BAY, CALIF.</td>
                            <td> 2829</td>
                        </tr>
                        <tr>
                            <td> SAN YSIDRO, CAL.</td>
                            <td> 2504</td>
                        </tr>
                        <tr>
                            <td> SAND POINT, ALASKA</td>
                            <td> 3125</td>
                        </tr>
                        <tr>
                            <td> SANTA TERESA AIRPORT, NM</td>
                            <td> 2481</td>
                        </tr>
                        <tr>
                            <td> SANTA TERESA, NEW MEXICO</td>
                            <td> 2408</td>
                        </tr>
                        <tr>
                            <td> SARASOTA-BRADENTON AIRPORT</td>
                            <td> 1883</td>
                        </tr>
                        <tr>
                            <td> SARLES, N.D.</td>
                            <td> 3409</td>
                        </tr>
                        <tr>
                            <td> SASABE, ARIZ.</td>
                            <td> 2606</td>
                        </tr>
                        <tr>
                            <td> SAULT STE. MARIE, MICH.</td>
                            <td> 3803</td>
                        </tr>
                        <tr>
                            <td> SAVANNAH, GA.</td>
                            <td> 1703</td>
                        </tr>
                        <tr>
                            <td> SAVANNAH/WILMINGTON</td>
                            <td> 5801</td>
                        </tr>
                        <tr>
                            <td> SCOBEY, MONTANA</td>
                            <td> 3309</td>
                        </tr>
                        <tr>
                            <td> SEATTLE, WASH.</td>
                            </td>
                            <td> 3001</td>
                        </tr>
                        <tr>
                            <td> SEATTLE-TACOMA INT. AIRPORT</td>
                            <td> 3029</td>
                        </tr>
                        <tr>
                            <td> SELBY, CALIF.</td>
                            <td> 2827</td>
                        </tr>
                        <tr>
                            <td> SHEBOYGAN, WISCONSIN</td>
                            <td> 3707</td>
                        </tr>
                        <tr>
                            <td> SHERWOOD, N.D.</td>
                            <td> 3414</td>
                        </tr>
                        <tr>
                            <td> SHREVEPORT-BOSSIER CTY,LA</td>
                            <td> 2018</td>
                        </tr>
                        <tr>
                            <td> SILVER BAY, MINN.</td>
                            <td> 3614</td>
                        </tr>
                        <tr>
                            <td> SIOUX FALLS, S.D.</td>
                            <td> 3502</td>
                        </tr>
                        <tr>
                            <td> SITKA, ALASKA</td>
                            <td> 3115</td>
                        </tr>
                        <tr>
                            <td> SKAGWAY, ALASKA</td>
                            <td> 3103</td>
                        </tr>
                        <tr>
                            <td> SODUS POINT, N.Y.</td>
                            <td> 905</td>
                        </tr>
                        <tr>
                            <td> SPIRIT OF ST. LOUIS AIRPORT, MO</td>
                            <td> 4506</td>
                        </tr>
                        <tr>
                            <td> SPOKANE, WASH.</td>
                            </td>
                            <td> 3022</td>
                        </tr>
                        <tr>
                            <td> SPRINGFIELD, MASS.</td>
                            <td> 402</td>
                        </tr>
                        <tr>
                            <td> SPRINGFIELD, MISSOURI</td>
                            <td> 4505</td>
                        </tr>
                        <tr>
                            <td> ST. JOHN, N.D.</td>
                            <td> 3405</td>
                        </tr>
                        <tr>
                            <td> ST. JOSEPH, MISSOURI</td>
                            <td> 4502</td>
                        </tr>
                        <tr>
                            <td> ST. LOUIS, MISSOURI</td>
                            <td> 4503</td>
                        </tr>
                        <tr>
                            <td> ST. PAUL AIRPORT, ANCHORAGE, AK</td>
                            <td> 3181</td>
                        </tr>
                        <tr>
                            <td> ST. PETERSBURG, FLA.</td>
                            <td> 1814</td>
                        </tr>
                        <tr>
                            <td> ST. ROSE, LA.</td>
                            <td> 2013</td>
                        </tr>
                        <tr>
                            <td> STOCKTON, CALIF.</td>
                            <td> 2810</td>
                        </tr>
                        <tr>
                            <td> SUISUN BAY, CALIF.</td>
                            <td> 2831</td>
                        </tr>
                        <tr>
                            <td> SUMAS, WASH.</td>
                            </td>
                            <td> 3009</td>
                        </tr>
                        <tr>
                            <td> SUPERIOR, WISCONSIN</td>
                            <td> 3608</td>
                        </tr>
                        <tr>
                            <td> SW FL Regional Airport FL</td>
                            <td> 1881</td>
                        </tr>
                        <tr>
                            <td> SWEETGRASS, MONTANA</td>
                            <td> 3310</td>
                        </tr>
                        <tr>
                            <td> SWIFT SURE COURIER SERVICES, LT</td>
                            <td> 972</td>
                        </tr>
                        <tr>
                            <td> SWISS AIR (SKYRACER)</td>
                            <td> 1076</td>
                        </tr>
                        <tr>
                            <td> SYRACUSE, N.Y.</td>
                            <td> 906</td>
                        </tr>
                        <tr>
                            <td> TACOMA, WASH.</td>
                            </td>
                            <td> 3002</td>
                        </tr>
                        <tr>
                            <td> TAMPA, FLA.</td>
                            <td> 1801</td>
                        </tr>
                        <tr>
                            <td> TECATE, CAL.</td>
                            <td> 2505</td>
                        </tr>
                        <tr>
                            <td> TEXAS CITY, TEXAS</td>
                            <td> 5306</td>
                        </tr>
                        <tr>
                            <td> TNT EXPRESS WORLDWIDE LA, CA</td>
                            <td> 2775</td>
                        </tr>
                        <tr>
                            <td> TNT SKYPAK, BUFFALO</td>
                            <td> 971</td>
                        </tr>
                        <tr>
                            <td> TNT SKYPAK, JFK</td>
                            <td> 1078</td>
                        </tr>
                        <tr>
                            <td> TNT SKYPAK, SAN FRANCISCO</td>
                            <td> 2872</td>
                        </tr>
                        <tr>
                            <td> TOLEDO-SANDUSKY</td>
                            <td> 4105</td>
                        </tr>
                        <tr>
                            <td> TRENTON/MERCER COUNTRY USER FEE</td>
                            <td> 1183</td>
                        </tr>
                        <tr>
                            <td> TRI-CITY USER FEE AIRPORT, BOUN</td>
                            <td> 2082</td>
                        </tr>
                        <tr>
                            <td> TROUT RIVER, N.Y.</td>
                            <td> 715</td>
                        </tr>
                        <tr>
                            <td> TUCSON, ARIZ.</td>
                            <td> 2609</td>
                        </tr>
                        <tr>
                            <td> TULSA, OKLAHOMA</td>
                            <td> 5505</td>
                        </tr>
                        <tr>
                            <td> TURNER, MONTANA</td>
                            <td> 3306</td>
                        </tr>
                        <tr>
                            <td> U.P.S. COURIER</td>
                            <td> 3295</td>
                        </tr>
                        <tr>
                            <td> UPS COURIER HUB FACILITY, PHILA</td>
                            <td> 1195</td>
                        </tr>
                        <tr>
                            <td> UPS COURIER HUB, SEATTLE, WA</td>
                            <td> 3095</td>
                        </tr>
                        <tr>
                            <td> UPS MIAMI INTERNATIONAL AIRPORT</td>
                            <td> 5273</td>
                        </tr>
                        <tr>
                            <td> UPS, ANCHORAGE, AK</td>
                            <td> 3196</td>
                        </tr>
                        <tr>
                            <td> UPS, LOUISVILLE, KY</td>
                            <td> 4196</td>
                        </tr>
                        <tr>
                            <td> UPS, NEWARK, NJ</td>
                            <td> 1069</td>
                        </tr>
                        <tr>
                            <td> UPS, ONTARIO, CA</td>
                            <td> 2795</td>
                        </tr>
                        <tr>
                            <td> UPS, SEATTLE, WASH.</td>
                            </td>
                            <td> 3071</td>
                        </tr>
                        <tr>
                            <td> UTTICA, N.Y.</td>
                            <td> 907</td>
                        </tr>
                        <tr>
                            <td> VALDEZ, ALASKA</td>
                            <td> 3107</td>
                        </tr>
                        <tr>
                            <td> VANCOUVER, BC</td>
                            <td> 0000</td>
                        </tr>
                        <tr>
                            <td> VANCOUVER, WASH.</td>
                            </td>
                            <td> 2908</td>
                        </tr>
                        <tr>
                            <td> VENTURA, CALIF.</td>
                            <td> 2712</td>
                        </tr>
                        <tr>
                            <td> VESSELS UNDER OWN POWER</td>
                            <td> 6000</td>
                        </tr>
                        <tr>
                            <td> VICKSBURG, MS (INCL. JACKSON MU</td>
                            <td> 2015</td>
                        </tr>
                        <tr>
                            <td> VIRGIN ATLANTIC CARGO</td>
                            <td> 2774</td>
                        </tr>
                        <tr>
                            <td> WALHALLA, N.D.</td>
                            <td> 3407</td>
                        </tr>
                        <tr>
                            <td> WARROAD, MINN.</td>
                            <td> 3423</td>
                        </tr>
                        <tr>
                            <td> WASHINGTON, D.C.</td>
                            <td> 5401</td>
                        </tr>
                        <tr>
                            <td> WAUKEGAN AIRPORT, CHICAGO, IL</td>
                            <td> 3981</td>
                        </tr>
                        <tr>
                            <td> WEST PALM BEACH, FLA.</td>
                            <td> 5204</td>
                        </tr>
                        <tr>
                            <td> WESTHOPE, N.D.</td>
                            <td> 3419</td>
                        </tr>
                        <tr>
                            <td> WHITETAIL, MONTANA</td>
                            <td> 3312</td>
                        </tr>
                        <tr>
                            <td> WHITLASH, MONTANA</td>
                            <td> 3321</td>
                        </tr>
                        <tr>
                            <td> WICHITA, KANSAS</td>
                            <td> 4504</td>
                        </tr>
                        <tr>
                            <td> WILLOW RUN AIRPORT</td>
                            <td> 3882</td>
                        </tr>
                        <tr>
                            <td> WILMINGTON, DEL.</td>
                            <td> 1103</td>
                        </tr>
                        <tr>
                            <td> WILMINGTON, N.C.</td>
                            <td> 1501</td>
                        </tr>
                        <tr>
                            <td> WINSTON-SALEM, N.C.</td>
                            <td> 1502</td>
                        </tr>
                        <tr>
                            <td> WLKS-BARRE/SCRANTON, PA.</td>
                            <td> 1106</td>
                        </tr>
                        <tr>
                            <td> WORCESTER, MASS.</td>
                            <td> 403</td>
                        </tr>
                        <tr>
                            <td> WRANGELL, ALASKA</td>
                            <td> 3105</td>
                        </tr>
                        <tr>
                            <td> YAKIMA AIR TERMINAL, WA</td>
                            <td> 3081</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="tab-pane fade" id="ab" role="tabpanel" aria-labelledby="ab-tab">

                <table class="table text-start red-table" border="0">
                    <thead>

                        <tr>
                            <th scope="col">Port Name</th>
                            <th scope="col">Port Code</th>

                        </tr>
                        <tr class="c-black">
                            <th scope="col">1) WASHINGTON</th>
                            <th scope="col"></th>

                        </tr>
                    </thead>

                    <tbody>
                        <tr>
                            <td>ABERDEEN-HOQUIAM, WASH.</td>
                            <td>3003</td>
                        </tr>
                        <tr>
                            <td>ANACORTES, WASH.</td>
                            <td>3010</td>
                        </tr>

                        <tr>
                            <td>BALTIMORE-WASHINGTON INTERNATIONAL </td>
                            <td>1305</td>
                        </tr>
                        <tr>
                            <td>BELLINGHAM, WASH.</td>
                            <td>3005</td>
                        </tr>
                        <tr>
                            <td>BLAINE, WASH.</td>
                            <td>3004</td>
                        </tr>
                        <tr>
                            <td>BOUNDARY, WASH.</td>
                            <td>3015</td>
                        </tr>
                        <tr>
                            <td>DANVILLE, WASH.</td>
                            <td>3012</td>
                        </tr>
                        <tr>
                            <td>EVERETT, WASH.</td>
                            <td>3006</td>
                        </tr>
                        <tr>
                            <td>FERRY, WASH.</td>
                            <td>3013</td>
                        </tr>
                        <tr>
                            <td>FRIDAY HARBOR, WASH.</td>
                            <td>3014</td>
                        </tr>
                        <tr>
                            <td>FRONTIER, WASH.</td>
                            <td>3020</td>
                        </tr>
                        <tr>
                            <td>KALAMA, WASH.</td>
                            <td>2909</td>
                        </tr>
                        <tr>
                            <td>KENMORE AIR HARBOR, WASH.</td>
                            <td>3018</td>
                        </tr>
                        <tr>
                            <td>LAURIER, WASH.</td>
                            <td>3016</td>
                        </tr>
                        <tr>
                            <td>LONGVIEW, WASH.</td>
                            <td>2905</td>
                        </tr>
                        <tr>
                            <td>LYNDEN, WASH.</td>
                            <td>3023</td>
                        </tr>
                        <tr>
                            <td>METALINE FALLS, WASH.</td>
                            <td>3025</td>
                        </tr>
                        <tr>
                            <td>NEAH BAY, WASH.</td>
                            <td>3027</td>
                        </tr>
                        <tr>
                            <td>NIGHTHAWK, WASH.</td>
                            <td>3011</td>
                        </tr>
                        <tr>
                            <td>OLYMPIA, WASH.</td>
                            <td>3026</td>
                        </tr>
                        <tr>
                            <td>OROVILLE, WASH.</td>
                            <td>3019</td>
                        </tr>
                        <tr>
                            <td>POINT ROBERTS, WASH.</td>
                            <td>3017</td>
                        </tr>
                        <tr>
                            <td>PORT ANGELES, WASH.</td>
                            <td>3007</td>
                        </tr>
                        <tr>
                            <td>PORT TOWNSEND, WASH.</td>
                            <td>3008</td>
                        </tr>
                        <tr>
                            <td>SEATTLE, WASH.</td>
                            <td>3001</td>
                        </tr>
                        <tr>
                            <td>SPOKANE, WASH.</td>
                            <td>3022</td>
                        </tr>
                        <tr>
                            <td>SUMAS, WASH.</td>
                            <td>3009</td>
                        </tr>
                        <tr>
                            <td>TACOMA, WASH.</td>
                            <td>3002</td>
                        </tr>
                        <tr>
                            <td>UPS, SEATTLE, WASH.</td>
                            <td>3071</td>
                        </tr>
                        <tr>
                            <td>VANCOUVER, WASH.</td>
                            <td>2908</td>
                        </tr>
                        <tr>
                            <td>WASHINGTON, D.C.
                            <td>5401</td>
                        </tr>
                    </tbody>

                    <thead>


                        <tr>
                            <th scope="col" class="c-black">2)New York </th>
                            <th scope="col"></th>

                        </tr>
                    </thead>

                    <tbody>

                        <tr>
                            <td>ALBANY, N.Y.</td>
                            <td>1002</td>
                        </tr>
                        <tr>
                            <td>DHL, JAMAICA, NY</td>
                            <td>1072</td>
                        </tr>
                        <tr>
                            <td>FEDERAL EXPRESS, JAMAICA, NY</td>
                            <td>1070</td>
                        </tr>
                        <tr>
                            <td>NYACC, JAMAICA, NY</td>
                            <td>1071</td>
                        </tr>
                    </tbody>
                </table>

            </div>

        </div>
    </div>
</section>

<section class="p-0 mb-n10 bg-transparent cta-overlay">
    <div class="row">
        <div class="col-lg-1 col-xl-3">
        </div>
        <div class="col-lg-11 col-xl-9">
            <div class="px-1-9 px-sm-6 px-lg-9 py-5 py-sm-8 z-index-3 bg-primary contact-block half-border-radius">
                <div class="row align-items-center position-relative z-index-3">
                    <div class="col-lg-7 col-xxl-7 mb-lg-0">
                        <h3 class="text-white mb-0">Let's make your supply chain easy
                        </h3>
                    </div>
                    <div class="col-lg-5 col-xxl-5 mt-3 text-lg-end">
                        <h5 class="text-white mb-3">If you have any questions.</h5>
                        <a href="contact.php" class="butn transparent"><span>Get In Touch</span></a>
                    </div>
                </div>
                <img src="img/bg/bg-03.png" class="position-absolute top-0 left-n5" alt="...">
            </div>
        </div>
    </div>
</section>
<div class="footer-light footer-new">
    <div class="ftr-bg">
        <div class="footer-top">
            <div class="container">
                <div class="row">

                    <div class="col-lg-4 col-md-12">

                        <div class="widget widget_about">
                            <div>
                                <h3 class="widget-title">Interport Global Logistics</h3>
                            </div>
                            <p>Today, IGL has established offices in major cities and ports in India with
                                warehousing facilities and transport equipment to handle any cargo
                                independently. The company also has access to major international ports through
                                its branch offices.</p>
                            <ul class="social-icon-style1 mb-0">

                                <li>
                                    <a target="_blank" href="https://www.linkedin.com/company/1897064"><i
                                            class="fab fa-linkedin-in"></i></a>
                                </li>

                            </ul>
                        </div>

                    </div>

                    <div class="col-lg-2 col-md-6 col-6">
                        <div class="widget widget_services ftr-list-center">
                            <h3 class="widget-title">Contact Us</h3>
                            <ul>
                                <li><a href="contact.php">Contact</a></li>
                                <li><a href="enquiry-form.php">Enquiry Form</a></li>
                                <li><a href="feedback-form.php">Feedback Form</a></li>
                                <li><a href="air-shipment.php">Air Shipment Bookings</a></li>
                                <li><a href="sea-shipment.php">Sea Shipment Bookings</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6 col-6">
                        <div class="widget widget_services ftr-list-center">
                            <h3 class="widget-title">Important Links</h3>
                            <ul>
                                <li><a href="about.php">About</a></li>
                                <li><a href="careers.php">Careers</a></li>
                                <li><a href="terms-and-conditions.php">Terms & Conditions</a></li>
                                <li><a href="certifications.php">Certifications</a></li>
                                <li><a href="advertisements.php">Advertisements</a></li>
                                <li><a href="sitemap.php">Sitemap</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-12">
                        <div class="widget widget_services ftr-list-center connect-details">
                            <h3 class="widget-title">Online Support</h3>
                            <ul>
                                <p>Everyday is a new day for us and we work really hard to satisfy
                                    our customers everywhere.</p>
                                <li><a href="tel:+91-22 6951 6951"><i class="fa fa-phone"></i><strong> India: T-
                                        </strong> +91-22 6951 6951</a></li>
                                <li><a href="tel:+1 (732) 422-3870"><i class="fa fa-phone"></i><strong> USA: T-
                                        </strong> +1 (732) 422-3870</a></li>
                            </ul>
                            <ul class="mt-md-3">
                                <li><a href="tel:+91-22 6616 6642"><i class="fa fa-fax"></i><strong> India: F-
                                        </strong> +91-22 6616 6642</a></li>
                                <li><a href="tel:+1 (732) 422-3878"><i class="fa fa-fax"></i><strong> USA: F- </strong>
                                        +1 (732) 422-3878</a></li>
                            </ul>
                            <ul class="mt-md-3">
                                <li><a href="mailto:info@interportglobal.com"><i class="fa fa-envelope"></i><strong>
                                            India: E- </strong>info@interportglobal.com</a></li>
                                <li><a href="mailto:usa@interportglobal.com"><i class="fa fa-envelope"></i><strong>
                                            USA: E- </strong>usa@interportglobal.com</a></li>
                            </ul>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <div class="footer-bottom-info">
                    <div class="footer-copy-right">
                        <span class="copyrights-text cpt-txt">Interport Global Logistics &copy; 2023. All rights reserved.
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

</div>
<a href="javascript:void(0)" class="scroll-to-top"><i class="fas fa-angle-up" aria-hidden="true"></i></a>
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/core.min.js"></script>
<script src="js/main.js"></script>
<script>
    $(document).ready(function () {
        $(".hide").click(function () {
            $(".hide-show-block").hide();
        });
        $(".show").click(function () {
            $(".hide-show-block").show();
        });
    });

    $(document).ready(function () {
        $(".hide-one").click(function () {
            $(".hide-show-block-one").hide();
        });
        $(".show-one").click(function () {
            $(".hide-show-block-one").show();
        });
    });
</script>
</body>

</html>
<!DOCTYPE html>
<html lang="en">

		
 
<head>
    <meta charset="utf-8" />
    <meta name="author" content="Interport Global Logistics" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="keywords" content="Interport Global Logistics" />
    <meta name="description" content="Interport Global Logistics" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;900&display=swap" rel="stylesheet">
    <title>Sea Shipment - Interport Global Logistics</title>
    <meta name="description" content="Interport Global Logistics - Total Logistics Solutions Provider">
    <meta name="keywords" content="logistics, cargo, solutions, addons, sea freight, air freight, rail freight, cargo insurance, container freight station, custom clearance, import export consolidation, nvocc, door to door delivery, iso flexi tanks, project logistics, heavy lift, break bulk, warehousing, our packing, transportation and distribution, rfid solutions, warehouse management, turnkey projects, logistic solutions, exhibition cargo, hazardous cargo, project cargo, ivrs phone track, airlines, bankers, india info, container specification sea, container specification air, hazmat definitions, shipping glossary, iata codes, usa port codes, print your bill of lading, industry links, inco terms, air shipment, sea shipment" />
    <meta property="og:description" content="Interport Global Logistics - Total Logistics Solutions Provider">
    <meta property="og:site_name" content="Interport Global Logistics">
    <meta property="og:title" content="Interport Global Logistics">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://interportglobal.com/new/">
    <meta property="og:image" content="https://interportglobal.com/new/img/logos/logo-old.png" />
    <meta property="og:image:secure_url" content="https://interportglobal.com/new/img/logos/logo-old.png" />
    <meta property="og:image:width" content="1800" />
    <meta property="og:image:height" content="945" />
    <meta property="og:image:alt" content="Interport Global Logistics" />
    <meta property="og:image:type" content="image/png" />
    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="Interport Global Logistics">
    <meta name="twitter:creator" content="Interport Global Logistics">
    <meta name="twitter:title" content="Interport Global Logistics">
    <meta name="twitter:description" content="Interport Global Logistics - Total Logistics Solutions Provider">
    <link rel="shortcut icon" href="img/logos/logo-old.png" />
    <link rel="apple-touch-icon" href="img/logos/logo-old.png" />
    <link rel="apple-touch-icon" sizes="72x72" href="img/logos/logo-old.png" />
    <link rel="apple-touch-icon" sizes="114x114" href="img/logos/logo-old.png" />
    <link rel="stylesheet" href="css/plugins.css">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="css/mystyle.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link href="css/new-responsive.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/f70dd43e17.js" crossorigin="anonymous"></script>
    <script type="text/javascript">
        function googleTranslateElementInit2() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                autoDisplay: false
            }, 'google_translate_element2');
        }
    </script>
    <script type="text/javascript"
        src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2">
    </script>
    <script type="text/javascript">
        eval(function (p, a, c, k, e, r) {
            e = function (c) {
                return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) :
                    c
                    .toString(36))
            };
            if (!''.replace(/^/, String)) {
                while (c--) r[e(c)] = k[c] || e(c);
                k = [function (e) {
                    return r[e]
                }];
                e = function () {
                    return '\\w+'
                };
                c = 1
            };
            while (c--)
                if (k[c]) p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]);
            return p
        }('6 7(a,b){n{4(2.9){3 c=2.9("o");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s(\'t\'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a==\'\')v;3 b=a.w(\'|\')[1];3 c;3 d=2.x(\'y\');z(3 i=0;i<d.5;i++)4(d[i].A==\'B-C-D\')c=d[i];4(2.j(\'k\')==E||2.j(\'k\').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,\'m\');7(c,\'m\')}}',
            43, 43,
            '||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500'
            .split('|'), 0, {}))
    </script>
    <script>
        (function (w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-M9TZHXX');
    </script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-179148496-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-179148496-1');
    </script>
    <script>
        ! function (f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function () {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '420989926550304');
        fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
            src="https://www.facebook.com/tr?id=420989926550304&ev=PageView&noscript=1" /></noscript>
</head>

<body>
    <div id="preloader"></div>
    <div class="main-wrapper ">
        <header class="header-style1 menu_area-light">
            <div class="navbar-default">
                <div class="top-search bg-secondary">
                    <div class="container-fluid px-lg-1-6 px-xl-2-5 px-xxl-2-9">
                        <form class="search-form" action="" method="GET" accept-charset="utf-8">
                            <div class="input-group">
                                <span class="input-group-addon cursor-pointer">
                                    <button class="search-form_submit fas fa-search text-white" type="submit"></button>
                                </span>
                                <input type="text" class="search-form_input form-control" name="s" autocomplete="off"
                                    placeholder="Type &amp; hit enter...">
                                <span class="input-group-addon close-search mt-1"><i class="fas fa-times"></i></span>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="container-fluid px-lg-1-6 px-xl-2-5 px-xxl-2-9">
                    <div class="row align-items-center">
                        <div class="col-12 col-lg-12 p-0 px-lg-2">
                            <div class="menu_area alt-font">
                                <nav class="navbar navbar-expand-lg navbar-light p-0">
                                    <div class="navbar-header navbar-header-custom">
                                        <a href="index.php" class="navbar-brand logochange">
                                            <img id="logo" class="home-logo" src="img/logos/logo-w.png" alt="logo" />
                                            <img id="logo" class="other-logo" src="img/logos/logo-b.png" alt="logo" />
                                        </a>
                                    </div>
                                    <div class="navbar-toggler bg-primary"></div>
                                    <ul class="navbar-nav" id="nav" style="display: none;">
                                        <li
                                            >
                                            <a href="https://interportglobal.com/index.php">Home</a></li>
                                        <li >
                                            <a href="about.php">About Us</a>
                                        </li>
                                        <li
                                            class="d-none d-lg-block d-xl-block 
                                            ">
                                            <a href="https://interportglobal.com/services.php">Services</a>
                                            <ul class="row megamenu">
                                                <li class="col-lg-4 col-sm-12">
                                                    <ul>
                                                        <li><a href="freight-forwarding.php">Freight Forwarding</a></li>
                                                        <li><a href="ocean-freight.php">Ocean Freight</a></li>
                                                        <li><a href="air-freight.php">Air Freight</a></li>
                                                        <li><a href="rail-freight.php">Rail Freight</a></li>
                                                        <li><a href="road-freight.php">Road Freight</a></li>
                                                        <li><a href="3pl-warehousing.php">3PL Warehousing</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <ul>
                                                        <li><a href="custom-brokerage.php">Custom Brokerage</a></li>
                                                        <li><a href="hazardous-cargo.php">Hazardous Cargo</a></li>
                                                        <li><a href="project-cargo.php">Project Cargo</a></li>
                                                        <li><a href="heavy-lift.php">Heavy Lift</a></li>
                                                        <li><a href="door-to-door-program.php">Door To Door
                                                                Program</a></li>
                                                        <li><a href="vessel-handling.php">Vessel Handling</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <ul >
                                                        <li><a href="turnkey-projects.php">Turnkey Projects</a></li>
                                                        <li><a href="iso-flexi-tanks.php">ISO Tanks / Flexi Tanks</a>
                                                        </li>
                                                        <li><a href="cargo-insurance.php">Cargo Insurance</a></li>
                                                        <li><a href="nvocc.php">NVOCC</a></li>
                                                        <li><a href="import-export-consolidation.php">Import / Export
                                                                Consolidation</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                        <li
                                            class="d-block d-lg-none d-xl-none 
                                            ">
                                            <a href="services.php">Services</a>
                                            <ul class="scrollable-list" >
                                                <li><a href="services.php">Services</a></li>
                                                <li><a href="freight-forwarding.php">Freight Forwarding</a></li>
                                                <li><a href="ocean-freight.php">Ocean Freight</a></li>
                                                <li><a href="air-freight.php">Air Freight</a></li>
                                                <li><a href="rail-freight.php">Rail Freight</a></li>
                                                <li><a href="road-freight.php">Road Freight</a></li>
                                                <li><a href="3pl-warehousing.php">3PL Warehousing</a>
                                                </li>
                                                
                                                <li><a href="custom-brokerage.php">Custom Brokerage</a></li>
                                                <li><a href="hazardous-cargo.php">Hazardous Cargo</a></li>
                                                <li><a href="project-cargo.php">Project Cargo</a></li>
                                                <li><a href="heavy-lift.php">Heavy Lift</a></li>
                                                <li><a href="door-to-door-program.php">Door To Door
                                                        Program</a></li>
                                                <li><a href="vessel-handling.php">Vessel Handling</a></li>
                                                <li><a href="turnkey-projects.php">Turnkey Projects</a></li>
                                                <li><a href="iso-flexi-tanks.php">ISO Tanks / Flexi Tanks</a>
                                                </li>
                                                
                                                <li><a href="cargo-insurance.php">Cargo Insurance</a></li>
                                                <li><a href="nvocc.php">NVOCC</a></li>
                                                <li><a href="import-export-consolidation.php">Import / Export
                                                        Consolidation</a></li>
                                            </ul>
                                        </li>
                                        
                                        <li
                                            >
                                            <a href="javascript:void(0)">Resources</a>
                                            <ul class="row megamenu">

                                                <li class="col-lg-4 col-sm-12">
                                                    <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Other
                                                        Links</span>
                                                    <ul>
                                                        <li><a href="airlines.php">Airlines</a></li>
                                                        <li><a href="bankers.php">Bankers</a></li>
                                                        <li><a href="2023-holiday-list.php">2024 Holiday List</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Important
                                                        Info</span>
                                                    <ul  class="">
                                                    <!-- scrollable-list -->
                                                        <li><a href="india-info.php">India Info</a></li>
                                                        <li><a href="container-specification-sea.php">Container
                                                                Specification-Sea</a></li>
                                                        <li><a href="container-specification-air.php">Container
                                                                Specification-Air</a></li>
                                                        <li><a href="hazmat-definitions.php">Hazmat Definifitons</a>
                                                        </li>
                                                        <li><a href="shipping-glossary.php">Shipping Glossary</a></li>
                                                        <li><a href="iata-codes.php">IATA Codes</a></li>
                                                        <li><a href="usa-port-codes.php">USA Port Codes</a></li>
                                                        <li><a href="print-your-bill-of-lading.php">Print Your Bill Of
                                                                Lading</a></li>
                                                    </ul>
                                                </li>


                                                <li class="col-lg-4 col-sm-12">
                                                    <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Important
                                                        Links</span>
                                                    <ul>
                                                        <li><a href="industry-links.php">Industry Links</a></li>
                                                        <li><a href="inco-terms.php">INCO Terms</a></li>
                                                    </ul>
                                                </li>

                                              
                                            <li class="col-lg-4 col-sm-12">
                                                <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Payments</span>
                                            <ul>
                                                <!-- <li>
                                                   <a href="#">For India</a>     
                                                   <li> -->
                                                <li>
                                                    <a href="https://app.paycargo.com/shipandpay?region=US&vendorld=281793" target="_blank">For USA</a>
                                                </li>
                                            </ul>
                                        </li>   

                                            </ul>
                                        </li>
                                        <li >
                                            <a href="careers.php">Careers</a>
                                        </li>
                                        <li >
                                            <a href="network.php">Network</a>
                                        </li>
                                        <li 
                                            class="active">
                                            <a href="contact.php">Contact</a>
                                            <ul class="">
                                            <!-- scroll-ul -->
                                                <li 
                                                    class="d-block d-lg-none  ">
                                                    <a href="contact.php">Contact</a>
                                                </li>
                                                <li >
                                                    <a href="enquiry-form.php">Enquiry Form</a>
                                                </li>
                                                <li >
                                                    <a href="feedback-form.php">Feedback Form</a>
                                                </li>
                                                <li >
                                                    <a href="air-shipment.php">Air Shipment Bookings</a>
                                                </li>
                                                <li class="active">
                                                    <a href="sea-shipment.php">Sea Shipment Bookings</a>
                                                </li>
                                    
                                            </ul>
                                        </li>
                                 

                                        <li
                                            class=" d-block d-lg-none">
                                            <a href="get-a-quote.php">Get a Quote</a>
                                        </li>
                                        <li class="d-block d-lg-none">
                                            <a target="_blank"
                                                href="http://www.interportglobal.net/Logisys/customervisibility/login.aspx">Track
                                                your shipment</a>
                                        </li>
                                        <li class="d-block d-lg-none">
                                                <select class="language-dropdown" onchange="doGTranslate(this);">
                                                    <option value="">Select a language</option>
                                                    <option value="en|af">Af</option>
                                                    <option value="en|sq">sq</option>
                                                    <option value="en|am">am</option>
                                                    <option value="en|ar">ar</option>
                                                    <option value="en|hy">hy</option>
                                                    <option value="en|az">az</option>
                                                    <option value="en|eu">eu</option>
                                                    <option value="en|be">be</option>
                                                    <option value="en|bn">bn</option>
                                                    <option value="en|bs">bs</option>
                                                    <option value="en|bg">bg</option>
                                                    <option value="en|ca">ca</option>
                                                    <option value="en|ceb">ceb</option>
                                                    <option value="en|ny">ny</option>
                                                    <option value="en|zh-CN">zh-CN</option>
                                                    <option value="en|zh-TW">zh-TW</option>
                                                    <option value="en|co">co</option>
                                                    <option value="en|hr">hr</option>
                                                    <option value="en|cs">cs</option>
                                                    <option value="en|da">da</option>
                                                    <option value="en|nl">nl</option>
                                                    <option value="en|en">en</option>
                                                    <option value="en|eo">eo</option>
                                                    <option value="en|et">et</option>
                                                    <option value="en|tl">tl</option>
                                                    <option value="en|fi">fi</option>
                                                    <option value="en|fr">fr</option>
                                                    <option value="en|fy">fy</option>
                                                    <option value="en|gl">gl </option>
                                                    <option value="en|ka">ka </option>
                                                    <option value="en|de">de </option>
                                                    <option value="en|el">el </option>
                                                    <option value="en|gu">gu </option>
                                                    <option value="en|ht">ht</option>
                                                    <option value="en|ha">ha </option>
                                                    <option value="en|haw">haw</option>
                                                    <option value="en|iw">iw </option>
                                                    <option value="en|hi">hi </option>
                                                    <option value="en|hmn">hmn</option>
                                                    <option value="en|hu">hu</option>
                                                    <option value="en|is">is</option>
                                                    <option value="en|ig">ig </option>
                                                    <option value="en|id">id</option>
                                                    <option value="en|ga">ga </option>
                                                    <option value="en|it">it </option>
                                                    <option value="en|ja">ja </option>
                                                    <option value="en|jw">jw </option>
                                                    <option value="en|kn">kn </option>
                                                    <option value="en|kk">kk </option>
                                                    <option value="en|km">km </option>
                                                    <option value="en|ko">ko </option>
                                                    <option value="en|ku">ku </option>
                                                    <option value="en|ky">ky </option>
                                                    <option value="en|lo">lo </option>
                                                    <option value="en|la">la </option>
                                                    <option value="en|lv">lv </option>
                                                    <option value="en|lt">lt </option>
                                                    <option value="en|lb">lb </option>
                                                    <option value="en|mk">mk </option>
                                                    <option value="en|mg">mg </option>
                                                    <option value="en|ms">ms </option>
                                                    <option value="en|ml">ml </option>
                                                    <option value="en|mt">mt </option>
                                                    <option value="en|mi">mi </option>
                                                    <option value="en|mr">mr </option>
                                                    <option value="en|mn">mn </option>
                                                    <option value="en|my">my </option>
                                                    <option value="en|ne">ne </option>
                                                    <option value="en|no">no </option>
                                                    <option value="en|ps">ps </option>
                                                    <option value="en|fa">fa </option>
                                                    <option value="en|pl">pl </option>
                                                    <option value="en|pt">pt </option>
                                                    <option value="en|pa">pa </option>
                                                    <option value="en|ro">ro </option>
                                                    <option value="en|ru">ru </option>
                                                    <option value="en|sm">sm </option>
                                                    <option value="en|gd">gd </option>
                                                    <option value="en|sr">sr </option>
                                                    <option value="en|st">st </option>
                                                    <option value="en|sn">sn </option>
                                                    <option value="en|sd">sd </option>
                                                    <option value="en|si">si </option>
                                                    <option value="en|sk">sk </option>
                                                    <option value="en|sl">sl </option>
                                                    <option value="en|so">so </option>
                                                    <option value="en|es">es </option>
                                                    <option value="en|su">su </option>
                                                    <option value="en|sw">sw </option>
                                                    <option value="en|sv">sv </option>
                                                    <option value="en|tg">tg </option>
                                                    <option value="en|ta">ta </option>
                                                    <option value="en|te">te </option>
                                                    <option value="en|th">th </option>
                                                    <option value="en|tr">tr </option>
                                                    <option value="en|uk">uk </option>
                                                    <option value="en|ur">ur </option>
                                                    <option value="en|uz">uz </option>
                                                    <option value="en|vi">vi </option>
                                                    <option value="en|cy">cy </option>
                                                    <option value="en|xh">xh </option>
                                                    <option value="en|yi">yi </option>
                                                    <option value="en|yo">yo </option>
                                                    <option value="en|zu">zu </option>
                                                </select>
                                                <div id="google_translate_element2"></div>

                                        </li>
                                    </ul>
                                    <div class="attr-nav align-items-xl-center main-font">
                                        <ul>
                                            <li class="d-none d-xl-inline-block">
                                                <a target="_blank"
                                                    href="https://app.fieldproxy.com/public/proxy-f329b4dc-1384-4812-b392-d3278cb60ba1/igital_visibility/igtaltrack"
                                                    class="butn outline me-3">
                                                    <span>Track a shipment</span>
                                                </a>
                                            </li>
                                            <li class="d-none d-xl-inline-block">
                                                <a href="get-a-quote.php" class="butn primary">
                                                    <span>Get a Quote</span>
                                                </a>
                                            </li>
                                            <li class="d-none d-xl-inline-block">
                                                <select class="language-dropdown" onchange="doGTranslate(this);">
                                                    <option value="">en</option>
                                                    <option value="en|af">Af</option>
                                                    <option value="en|sq">sq</option>
                                                    <option value="en|am">am</option>
                                                    <option value="en|ar">ar</option>
                                                    <option value="en|hy">hy</option>
                                                    <option value="en|az">az</option>
                                                    <option value="en|eu">eu</option>
                                                    <option value="en|be">be</option>
                                                    <option value="en|bn">bn</option>
                                                    <option value="en|bs">bs</option>
                                                    <option value="en|bg">bg</option>
                                                    <option value="en|ca">ca</option>
                                                    <option value="en|ceb">ceb</option>
                                                    <option value="en|ny">ny</option>
                                                    <option value="en|zh-CN">zh-CN</option>
                                                    <option value="en|zh-TW">zh-TW</option>
                                                    <option value="en|co">co</option>
                                                    <option value="en|hr">hr</option>
                                                    <option value="en|cs">cs</option>
                                                    <option value="en|da">da</option>
                                                    <option value="en|nl">nl</option>
                                                    <option value="en|en">en</option>
                                                    <option value="en|eo">eo</option>
                                                    <option value="en|et">et</option>
                                                    <option value="en|tl">tl</option>
                                                    <option value="en|fi">fi</option>
                                                    <option value="en|fr">fr</option>
                                                    <option value="en|fy">fy</option>
                                                    <option value="en|gl">gl </option>
                                                    <option value="en|ka">ka </option>
                                                    <option value="en|de">de </option>
                                                    <option value="en|el">el </option>
                                                    <option value="en|gu">gu </option>
                                                    <option value="en|ht">ht</option>
                                                    <option value="en|ha">ha </option>
                                                    <option value="en|haw">haw</option>
                                                    <option value="en|iw">iw </option>
                                                    <option value="en|hi">hi </option>
                                                    <option value="en|hmn">hmn</option>
                                                    <option value="en|hu">hu</option>
                                                    <option value="en|is">is</option>
                                                    <option value="en|ig">ig </option>
                                                    <option value="en|id">id</option>
                                                    <option value="en|ga">ga </option>
                                                    <option value="en|it">it </option>
                                                    <option value="en|ja">ja </option>
                                                    <option value="en|jw">jw </option>
                                                    <option value="en|kn">kn </option>
                                                    <option value="en|kk">kk </option>
                                                    <option value="en|km">km </option>
                                                    <option value="en|ko">ko </option>
                                                    <option value="en|ku">ku </option>
                                                    <option value="en|ky">ky </option>
                                                    <option value="en|lo">lo </option>
                                                    <option value="en|la">la </option>
                                                    <option value="en|lv">lv </option>
                                                    <option value="en|lt">lt </option>
                                                    <option value="en|lb">lb </option>
                                                    <option value="en|mk">mk </option>
                                                    <option value="en|mg">mg </option>
                                                    <option value="en|ms">ms </option>
                                                    <option value="en|ml">ml </option>
                                                    <option value="en|mt">mt </option>
                                                    <option value="en|mi">mi </option>
                                                    <option value="en|mr">mr </option>
                                                    <option value="en|mn">mn </option>
                                                    <option value="en|my">my </option>
                                                    <option value="en|ne">ne </option>
                                                    <option value="en|no">no </option>
                                                    <option value="en|ps">ps </option>
                                                    <option value="en|fa">fa </option>
                                                    <option value="en|pl">pl </option>
                                                    <option value="en|pt">pt </option>
                                                    <option value="en|pa">pa </option>
                                                    <option value="en|ro">ro </option>
                                                    <option value="en|ru">ru </option>
                                                    <option value="en|sm">sm </option>
                                                    <option value="en|gd">gd </option>
                                                    <option value="en|sr">sr </option>
                                                    <option value="en|st">st </option>
                                                    <option value="en|sn">sn </option>
                                                    <option value="en|sd">sd </option>
                                                    <option value="en|si">si </option>
                                                    <option value="en|sk">sk </option>
                                                    <option value="en|sl">sl </option>
                                                    <option value="en|so">so </option>
                                                    <option value="en|es">es </option>
                                                    <option value="en|su">su </option>
                                                    <option value="en|sw">sw </option>
                                                    <option value="en|sv">sv </option>
                                                    <option value="en|tg">tg </option>
                                                    <option value="en|ta">ta </option>
                                                    <option value="en|te">te </option>
                                                    <option value="en|th">th </option>
                                                    <option value="en|tr">tr </option>
                                                    <option value="en|uk">uk </option>
                                                    <option value="en|ur">ur </option>
                                                    <option value="en|uz">uz </option>
                                                    <option value="en|vi">vi </option>
                                                    <option value="en|cy">cy </option>
                                                    <option value="en|xh">xh </option>
                                                    <option value="en|yi">yi </option>
                                                    <option value="en|yo">yo </option>
                                                    <option value="en|zu">zu </option>
                                                </select>
                                                <div id="google_translate_element2"></div>
                                            </li>
                                        </ul>
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <div class="modal fade" id="getaquote_modal" tabindex="-1" aria-labelledby="centeredLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title" id="centeredLabel">Get a Quote</h3>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <form class="row g-3">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_name" placeholder="Name">
                                            <label for="quote_name">Name</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-1">
                                            <input type="email" class="form-control" id="quote_email"
                                                placeholder="Email">
                                            <label for="quote_email">Email</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_phone"
                                                placeholder="Phone">
                                            <label for="quote_phone">Phone</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected>Freight Type</option>
                                                <option value="1">Freight Type 1</option>
                                                <option value="2">Freight Type 2</option>
                                                <option value="3">Freight Type 3</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_city_of_departure"
                                                placeholder="City of Departure">
                                            <label for="quote_city_of_departure">City of Departure</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_delivery_city"
                                                placeholder="Delivery City">
                                            <label for="quote_delivery_city">Delivery City</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected>Incoterms</option>
                                                <option value="1">Incoterms 1</option>
                                                <option value="2">Incoterms 2</option>
                                                <option value="3">Incoterms 3</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_weight"
                                                placeholder="Weight (kg)">
                                            <label for="quote_weight">Weight (kg)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_height"
                                                placeholder="Height (cm)">
                                            <label for="quote_height">Height (cm)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_width"
                                                placeholder="Width (cm)">
                                            <label for="quote_width">Width (cm)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_length"
                                                placeholder="Length (cm)">
                                            <label for="quote_length">Length (cm)</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="quote_fragile">
                                            <label class="form-check-label" for="quote_fragile">
                                                Fragile
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="quote_express_delivery">
                                            <label class="form-check-label" for="quote_express_delivery">
                                                Express Delivery
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="quote_insurance">
                                            <label class="form-check-label" for="quote_insurance">
                                                Insurance
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="quote_packaging">
                                            <label class="form-check-label" for="quote_packaging">
                                                Packaging
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>
                    <div class="modal-footer justify-content-center">
                        <button type="button" class="butn primary">Save</button>
                    </div>
                </div>
            </div>
        </div><style>
    .error {
        color: red;
    }
</style>
<section class="page-title-section main-title-section bg-light">
    <div class="container title-container">
        <div class="row">
            <div class="col-lg-12">
                <ul class="wow fadeInUp breadcrump-list" data-wow-delay="400ms">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li>Sea Shipment</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section class="contact-form py-5">
    <div class="container">
        <div class="contact-wrapper-box">
            <div class="row">
                <div class="col-lg-12">
                    <div class="contact-form-area">
                        <div class="alert alert-danger errmsg text-center" id="sea_shipment_err"></div>
                        <div class="clearfix" style="margin-top:10px;">
                            <div class="alert alert-success text-center" role="alert" id="success_alert"
                                style="display:none;margin-bottom: 20px;">

                            </div>
                            <div class="alert alert-success text-center" role="alert" id="fail_alert"
                                style="display:none;margin-bottom: 20px;">

                            </div>
                        </div>
                        <form class="book_sea_ship_form" id="book_sea_ship_form" name="book_sea_ship_form">

                            <div class="quform-elements">

                                <div class="row">

                                    <div class="col-lg-12">
                                        <h5 class="h5 mb-3 form-heading">Contact Details</h5>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="company_name"
                                                name="company_name"
                                                placeholder="Company Name / Organisation (if applicable)">
                                            <label for="organisation_name" class="float-space">Company Name /
                                                Organisation (if applicable)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="contact_name"
                                                name="contact_name" placeholder="Contact Name">
                                            <label for="contact_name" class="float-space">Contact Name</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="email" name="email"
                                                placeholder="Email Id">
                                            <label for="email_id" class="float-space">Email Id</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="contact_number"
                                                name="contact_number" placeholder="Contact Details"
                                                oninput="numberOnly(this.id);" maxlength="10">
                                            <label for="contact_details" class="float-space">Contact Details</label>
                                        </div>
                                    </div>

                                    <div class="col-lg-12">
                                        <h5 class="h5 mb-3 mt-4 form-heading">Shipment Details</h5>
                                    </div>

                                    <div class="col-lg-12">
                                        <div class="form-floating mb-3">
                                            <textarea class="form-control float-border"
                                                placeholder="Shipper: Origin / Location of Goods" id="shipperOrgin"
                                                name="shipperOrgin" style="height: 100px"></textarea>
                                            <label for="shipperOrgin" class="float-space">Shipper: Origin / Location of
                                                Goods</label>
                                        </div>
                                    </div>

                                    <div class="col-lg-12">
                                        <div class="form-floating mb-3">
                                            <textarea class="form-control float-border"
                                                placeholder="Consignee location (and address if known)"
                                                id="consigneeLocation" name="consigneeLocation"
                                                style="height: 100px"></textarea>
                                            <label for="consigneeLocation" class="float-space">Consignee location (and
                                                address if known)</label>
                                        </div>
                                    </div>

                                    <div class="col-lg-12">
                                        <div class="form-floating mb-3">
                                            <textarea class="form-control float-border" placeholder="notify-party"
                                                id="notifyParty" name="notifyParty" style="height: 100px"></textarea>
                                            <label for="notifyParty" class="float-space">Notify Party</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="zip_code"
                                                name="zip_code" placeholder="Post / Zip Code (if known)"
                                                oninput="numberOnly(this.id);" maxlength="10">
                                            <label for="zip_code" class="float-space">Post / Zip Code (if known)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="vessel" id="vessel"
                                                placeholder="Vessel (if known)">
                                            <label for="vesselIf" class="float-space">Vessel (if known)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="voyage_number"
                                                name="voyage_number" placeholder="Voyage No (if known)"
                                                oninput="numberOnly(this.id);" maxlength="10">
                                            <label for="voyage_number" class="float-space">Voyage No (if known)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="port_loading"
                                                name="port_loading" placeholder="Port of Loading (if known)">
                                            <label for="port_loading" class="float-space">Port of Loading (if
                                                known)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="port_discharge"
                                                name="port_discharge" placeholder="Port of Discharge (if known)">
                                            <label for="port_discharge" class="float-space">Port of Discharge (if
                                                known)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="col-lg-12">
                                            <select class="form-select insurance-required mb-3" name="insurance_required"
                                                id="insurance_required" aria-label="Default select example">
                                                <option value="">Insurance required</option>
                                                <option value="Yes">Yes</option>
                                                <option value="No">No</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="insurance_yes"
                                                name="insurance_yes" placeholder="If Yes, Value AUD">
                                            <label for="yes_value" class="float-space">If Yes, Value AUD</label>
                                        </div>
                                    </div>
                                    <!-- new column -->
                                    <div class="col-lg-4 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="invoice_cargo"
                                                name="invoice_cargo" placeholder="Invoice/ cargo">
                                            <label for="invoice_cargo" class="float-space">Invoice/ cargo</label>
                                        </div>
                                    </div>
                                    <!-- new column -->
                                    <div class="col-lg-4 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="hscode"
                                                name="hscode" placeholder="HS code">
                                            <label for="hscode" class="float-space">HS code</label>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-floating mb-3">
                                            <textarea class="form-control float-border" name="goods_description"
                                                id="goods_description"
                                                placeholder="Marks & Numbers(anything that identifies the shipped goods) - (optional)" style="height: 100px"></textarea>
                                            <label for="goods_description" class="float-space">Description of
                                                goods</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-3">
                                            <textarea class="form-control float-border" name="marksNumbers"
                                                id="marksNumbers"
                                                placeholder="Marks & Numbers(anything that identifies the shipped goods) - (optional)"
                                                id="marks-numbers" style="height: 100px"></textarea>
                                            <label for="marksNumbers" class="float-space">Marks & Numbers(anything that
                                                identifies the shipped goods) - (optional)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="ahecc_number"
                                                name="ahecc_number" placeholder="AHECC No: (optional)"
                                                oninput="numberOnly(this.id);" maxlength="10">
                                            <label for="ahecc_number" class="float-space">AHECC No: (optional)</label>
                                        </div>
                                    </div>

                                    <div class="col-lg-12">
                                        <h5 class="h5 mb-3 mt-4 form-heading">Number of bills required</h5>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="originals"
                                                name="originals" placeholder="Originals: (optional)">
                                            <label for="originals_optionals" class="float-space">Originals:
                                                (optional)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="copies"
                                                name="copies" placeholder="Copies: (optional)">
                                            <label for="copies_optionals" class="float-space">Copies: (optional)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <select class="form-select insurance-required mb-3  mb-3"
                                            aria-label="Default select example" id="type_of_shipment"
                                            name="type_of_shipment">
                                            <option value="">Type of shipment</option>
                                            <option value="LCL - Less than container load">LCL - Less than container
                                                load</option>
                                            <option value="20FCL - 20' Full Container Load">20FCL - 20' Full Container
                                                Load</option>
                                            <option value="40FCL - 40' Full Container Load">40FCL - 40' Full Container
                                                Load</option>
                                            <option value="20’FR">20’FR</option>
                                            <option value="40’FR">40’FR</option>
                                            <option value="20’OPEN TOP">20’OPEN TOP</option>
                                            <option value="40’OPEN TOP">40’OPEN TOP</option>
                                            <option value="OTH - Other">OTH - Other</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <select class="form-select insurance-required mb-3  mb-3"
                                            aria-label="Default select example" id="freight_charges"
                                            name="freight_charges">
                                            <option value="">Freight Charges</option>
                                            <option value="Prepaid">Prepaid</option>
                                            <option value="Collect">Collect</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <select class="form-select insurance-required mb-3"
                                            aria-label="Default select example" id="delivery_terms"
                                            name="delivery_terms">
                                            <option value="">Delivery Terms</option>
                                            <option value="EXW - Ex Works">EXW - Ex Works</option>
                                            <option value="FOB - Free On Board">FOB - Free On Board</option>
                                            <option value="CFR - Cost & Freight">CFR - Cost & Freight</option>
                                            <option value="CIF - Cost, Insurance & Freight">CIF - Cost, Insurance &
                                                Freight</option>
                                            <option value="DDU - Delivery, duty unpaid">DDU - Delivery, duty unpaid
                                            </option>
                                            <option value="DDD - Delivered Duty Paid">DDD - Delivered Duty Paid</option>
                                            <option value="OTH - Other (Please specify above)">OTH - Other (Please
                                                specify above)</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="gross_weight"
                                                name="gross_weight" placeholder="Gross Weight">
                                            <label for="gross_weight" class="float-space">Gross Weight</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="type_packaging"
                                                name="type_packaging" placeholder="Type of packaging">
                                            <label for="type_packaging" class="float-space">Type of packaging</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <select class="form-select insurance-required mb-3"
                                            aria-label="Default select example" id="including_service"
                                            name="including_service">
                                            <option value="">Including Service: (optional)</option>
                                            <option value="First available">First available</option>
                                            <option value="Express">Express</option>
                                            <option value="Time Definite">Time Definite</option>
                                            <option value="Deferred">Deferred</option>
                                            <option value="Transshipment">Transshipment</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-12">
                                        <h5 class="h5 mb-3 mt-4 form-heading">Dimensions</h5>
                                    </div>
                                    <div class="col-lg-3 col-md-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="pieces"
                                                name="pieces" placeholder="Pieces" oninput="numberOnly(this.id);"
                                                maxlength="10">
                                            <label for="pieces" class="float-space">Pieces</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 col-md-4 col-8">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="length"
                                                name="length" placeholder="L x" oninput="numberOnly(this.id);"
                                                maxlength="10">
                                            <label for="l_x" class="float-space">L x</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-1 col-md-2 col-4">
                                        <select class="form-select insurance-required mb-3" id="l_suffix" name="l_suffix"
                                            aria-label="l_suffix">
                                            <option value="cm">cm</option>
                                            <option value="mm">mm</option>
                                            <option value="inches">inches</option>
                                            <option value="ft">ft</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-2 col-md-4 col-8">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="width" name="width"
                                                placeholder="W x" oninput="numberOnly(this.id);" maxlength="10">
                                            <label for="w_x" class="float-space">W x</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-1 col-md-2 col-4">
                                        <select class="form-select insurance-required mb-3" id="w_suffix" name="w_suffix"
                                            aria-label="w_suffix">
                                            <option value="cm">cm</option>
                                            <option value="mm">mm</option>
                                            <option value="inches">inches</option>
                                            <option value="ft">ft</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-2 col-md-4 col-8">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control float-border" id="height"
                                                name="height" placeholder="H x" oninput="numberOnly(this.id);"
                                                maxlength="10">
                                            <label for="h_x" class="float-space">H x</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-1 col-md-2 col-4">
                                        <select class="form-select insurance-required mb-3" id="h_suffix" name="h_suffix"
                                            aria-label="h_suffix">
                                            <option value="cm">cm</option>
                                            <option value="mm">mm</option>
                                            <option value="inches">inches</option>
                                            <option value="ft">ft</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-12">
                                        <h5 class="h5 mb-3 mt-4 form-heading">Others</h5>
                                    </div>

                                    <div class="col-lg-12">
                                        <div class="form-floating mb-3">
                                            <textarea class="form-control float-border"
                                                placeholder="Special instructions: multiple pcs. & dimensions:(optional)"
                                                id="special_instructions" name="special_instructions"
                                                style="height: 100px"></textarea>
                                            <label for="specialInstructions" class="float-space">Special instructions:
                                                multiple pcs. & dimensions:(optional)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="col-lg-12">
                                            <select class="form-select insurance-required mb-3" name="dangerous_goods"
                                                id="dangerous_goods" aria-label="Default select example">
                                                <option value="">Does the shipment contain dangerous goods?: (IATA DGR)
                                                </option>
                                                <option value="Yes">Yes</option>
                                                <option value="No">No</option>
                                            </select>
                                        </div>
                                    </div>
                                    <!-- new column -->
                                    <div class="col-lg-6">
                                        <div class="col-lg-12">
                                            <select class="form-select insurance-required mb-3" name="additional_services"
                                                id="additional_services" aria-label="Default select example">
                                                <option value="">Additional services required with Insurance
                                                </option>
                                                <option value="palletization">Palletization</option>
                                                <option value="transportation">Transportation</option>
                                                <option value="clearance">Clearance</option>
                                                <option value="lashing-choking">Lashing Choking</option>
                                                <option value="survey">Survey</option>
                                                <option value="detention-free-period">Detention free period</option>
                                            </select>
                                        </div>
                                        
                                        
                                    </div>
                                    <!-- new column -->
                                    <div class="col-lg-12 mt-4">
                                        <div class="quform-submit-inner text-center">
                                            <button class="butn primary" id="sea_shipment_save">Submit</button>
                                        </div>
                                        <div class="quform-loading-wrap text-start"><span class="quform-loading"></span>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="p-0 mb-n10 bg-transparent cta-overlay mt-1">
    <div class="row">
        <div class="col-lg-1 col-xl-3">
        </div>
        <div class="col-lg-11 col-xl-9">
            <div class="px-1-9 px-sm-6 px-lg-9 py-5 py-sm-8 z-index-3 bg-primary contact-block half-border-radius">
                <div class="row align-items-center position-relative z-index-3">
                    <div class="col-lg-7 col-xxl-7 mb-lg-0">
                        <h3 class="text-white mb-0">Let's make your supply chain easy
                        </h3>
                    </div>
                    <div class="col-lg-5 col-xxl-5 mt-3 text-lg-end">
                        <h5 class="text-white mb-3">If you have any questions.</h5>
                        <a href="contact.php" class="butn transparent"><span>Get In Touch</span></a>
                    </div>
                </div>
                <img src="img/bg/bg-03.png" class="position-absolute top-0 left-n5" alt="...">
            </div>
        </div>
    </div>
</section>
<div class="footer-light footer-new">
    <div class="ftr-bg">
        <div class="footer-top">
            <div class="container">
                <div class="row">

                    <div class="col-lg-4 col-md-12">

                        <div class="widget widget_about">
                            <div>
                                <h3 class="widget-title">Interport Global Logistics</h3>
                            </div>
                            <p>Today, IGL has established offices in major cities and ports in India with
                                warehousing facilities and transport equipment to handle any cargo
                                independently. The company also has access to major international ports through
                                its branch offices.</p>
                            <ul class="social-icon-style1 mb-0">

                                <li>
                                    <a target="_blank" href="https://www.linkedin.com/company/1897064"><i
                                            class="fab fa-linkedin-in"></i></a>
                                </li>

                            </ul>
                        </div>

                    </div>

                    <div class="col-lg-2 col-md-6 col-6">
                        <div class="widget widget_services ftr-list-center">
                            <h3 class="widget-title">Contact Us</h3>
                            <ul>
                                <li><a href="contact.php">Contact</a></li>
                                <li><a href="enquiry-form.php">Enquiry Form</a></li>
                                <li><a href="feedback-form.php">Feedback Form</a></li>
                                <li><a href="air-shipment.php">Air Shipment Bookings</a></li>
                                <li><a href="sea-shipment.php">Sea Shipment Bookings</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6 col-6">
                        <div class="widget widget_services ftr-list-center">
                            <h3 class="widget-title">Important Links</h3>
                            <ul>
                                <li><a href="about.php">About</a></li>
                                <li><a href="careers.php">Careers</a></li>
                                <li><a href="terms-and-conditions.php">Terms & Conditions</a></li>
                                <li><a href="certifications.php">Certifications</a></li>
                                <li><a href="advertisements.php">Advertisements</a></li>
                                <li><a href="sitemap.php">Sitemap</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-12">
                        <div class="widget widget_services ftr-list-center connect-details">
                            <h3 class="widget-title">Online Support</h3>
                            <ul>
                                <p>Everyday is a new day for us and we work really hard to satisfy
                                    our customers everywhere.</p>
                                <li><a href="tel:+91-22 6951 6951"><i class="fa fa-phone"></i><strong> India: T-
                                        </strong> +91-22 6951 6951</a></li>
                                <li><a href="tel:+1 (732) 422-3870"><i class="fa fa-phone"></i><strong> USA: T-
                                        </strong> +1 (732) 422-3870</a></li>
                            </ul>
                            <ul class="mt-md-3">
                                <li><a href="tel:+91-22 6951 6800"><i class="fa fa-fax"></i><strong> India: F-
                                        </strong> +91-22 6951 6800</a></li>
                                <li><a href="tel:+1 (732) 422-3878"><i class="fa fa-fax"></i><strong> USA: F- </strong>
                                        +1 (732) 422-3878</a></li>
                            </ul>
                            <ul class="mt-md-3">
                                <li><a href="mailto:info@interportglobal.com"><i class="fa fa-envelope"></i><strong>
                                            India: E- </strong>info@interportglobal.com</a></li>
                                <li><a href="mailto:usa@interportglobal.com"><i class="fa fa-envelope"></i><strong>
                                            USA: E- </strong>usa@interportglobal.com</a></li>
                            </ul>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <div class="footer-bottom-info">
                    <div class="footer-copy-right">
                        <span class="copyrights-text cpt-txt">Interport Global Logistics &copy; 2023. All rights reserved.
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

</div>
<a href="javascript:void(0)" class="scroll-to-top"><i class="fas fa-angle-up" aria-hidden="true"></i></a>
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/core.min.js"></script>
<script src="js/main.js"></script>
<script>
    $(document).ready(function () {
        $(".hide").click(function () {
            $(".hide-show-block").hide();
        });
        $(".show").click(function () {
            $(".hide-show-block").show();
        });
    });

    $(document).ready(function () {
        $(".hide-one").click(function () {
            $(".hide-show-block-one").hide();
        });
        $(".show-one").click(function () {
            $(".hide-show-block-one").show();
        });
    });
</script>
</body>

</html><script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.js"></script>

<script type="text/javascript">
    function numberOnly(id) {
        var element = document.getElementById(id);
        element.value = element.value.replace(/[^0-9]/gi, "");
    }

    $("#sea_shipment_save").click(function () {

        var r = validataion();
        if (r == 3) {
            return false;
        }
        var formdata = $('#book_sea_ship_form').serialize();
        var action_url = "sea-shipment-save.php";
        $("#sea_shipment_save").attr("disabled", true);
        $.ajax({
            url: action_url,
            type: 'post',
            dataType: 'json',
            data: formdata,
            beforeSend: function () {
                $("#sea_shipment_save").attr('disabled', true);
                $('#sea_shipment_save').html('Please Wait...');
            },
            success: function (response) {
                $("#sea_shipment_save").attr('disabled', false);
                $('#sea_shipment_save').html('Submit');
                console.log(response);
                $("#sea_shipment_save").attr("disabled", false);

                if (response.status == "1" || response.status == 1) {
                    $('#book_sea_ship_form').trigger("reset");

                    $("#success_alert").text(response.message).show();
                    document.getElementById("success_alert").scrollIntoView();
                    setTimeout(function () {
                        $("#success_alert").text(response.message).hide();

                    }, 4000);
                } else {
                    $("#fail_alert").text(response.message).show();
                    document.getElementById("fail_alert").scrollIntoView();
                    setTimeout(function () {
                        $("#fail_alert").text(response.message).hide();

                    }, 3000);
                }
            },

        });
    });

    function validataion() {

        var error = 0;
        var filter = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
        if ($("#contact_name").val() == "") {
            error = 2;
            $('#contact_name').focus();
            $('#sea_shipment_err').html("Please enter Contact Name");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
        } else if ($("#email").val() == "") {
            error = 2;
            $('#email').focus();
            $('#sea_shipment_err').html("Please enter email");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
        } else if ($("#email").val() != "" && !filter.test($("#email").val())) {
            error = 2;
            $('#email').focus();
            $('#sea_shipment_err').html("Please enter valid email");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
        } else if ($("#contact_number").val() == "") {
            error = 2;
            $('#contact_number').focus();
            $('#sea_shipment_err').html("Please enter Contact Details");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
        } else if ($("#shipperOrgin").val() == "") {
            error = 2;
            $('#shipperOrgin').focus();
            $('#sea_shipment_err').html("Please enter Shipper: Origin / Location of Goods");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
        } else if ($("#notifyParty").val() == "") {
            error = 2;
            $('#notifyParty').focus();
            $('#sea_shipment_err').html("Please enter Notify Party");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
        } else if ($("#insurance_required").val() == "") {
            error = 2;
            $('#insurance_required').focus();
            $('#sea_shipment_err').html("Please select Insurance required");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
            $("#insurance_required option:selected").text("Please select Insurance required");

        }
        else if ($("#invoice_cargo").val() == "") {
            error = 2;
            $('#invoice_cargo').focus();
            $('#sea_shipment_err').html("Please enter invoice cargo");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
        }
        else if ($("#hscode").val() == "") {
            error = 2;
            $('#hscode').focus();
            $('#sea_shipment_err').html("Please enter HS code");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
        }
        else if ($("#description_goods").val() == "") {
            error = 2;
            $('#description_goods').focus();
            $('#sea_shipment_err').html("Please enter Description of goods");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
        } else if ($("#type_of_shipment").val() == "") {
            error = 2;
            $('#type_of_shipment').focus();
            $('#sea_shipment_err').html("Please select Type of shipment");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
            $("#type_of_shipment option:selected").text("Please select Type of shipment");
        } else if ($("#freight_charges").val() == "") {
            error = 2;
            $('#freight_charges').focus();
            $('#sea_shipment_err').html("Please select Freight Charges");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
            $("#freight_charges option:selected").text("Please select Freight Charges");
        } else if ($("#delivery_terms").val() == "") {
            error = 2;
            $('#delivery_terms').focus();
            $('#sea_shipment_err').html("Please select Delivery Terms");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
            $("#delivery_terms option:selected").text("Please select Delivery Terms");
        } else if ($("#gross_weight").val() == "") {
            error = 2;
            $('#gross_weight').focus();
            $('#sea_shipment_err').html("Please enter Gross Weight");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
        } else if ($("#type_packaging").val() == "") {
            error = 2;
            $('#type_packaging').focus();
            $('#sea_shipment_err').html("Please enter Type of packaging");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
        } else if ($("#pieces").val() == "") {
            error = 2;
            $('#pieces').focus();
            $('#sea_shipment_err').html("Please enter Pieces");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
        } else if ($("#length").val() == "") {
            error = 2;
            $('#length').focus();
            $('#sea_shipment_err').html("Please enter length");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
        } else if ($("#width").val() == "") {
            error = 2;
            $('#width').focus();
            $('#sea_shipment_err').html("Please enter width");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
        } else if ($("#height").val() == "") {
            error = 2;
            $('#height').focus();
            $('#sea_shipment_err').html("Please enter height");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
        } else if ($("#dangerous_goods").val() == "") {
            error = 2;
            $('#dangerous_goods').focus();
            $('#sea_shipment_err').html("Please select Does the shipment contain dangerous goods");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
            $("#dangerous_goods option:selected").text("Please select Does the shipment contain dangerous goods");
        }
        else if ($("#additional_services").val() == "") {
            error = 2;
            $('#additional_services').focus();
            $('#sea_shipment_err').html("Please select Additional services required with Insurance");
            $('#sea_shipment_err').slideDown('slow').delay(5000).slideUp();
            
        }
        

        if (error == 2) {
            return 3;
        } else {
            return 2;
        }

    }
</script>
<!DOCTYPE html>
<html lang="en">

		
 
<head>
    <meta charset="utf-8" />
    <meta name="author" content="Interport Global Logistics" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="keywords" content="Interport Global Logistics" />
    <meta name="description" content="Interport Global Logistics" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;900&display=swap" rel="stylesheet">
    <title>Shipping glossary - Interport Global Logistics</title>
    <meta name="description" content="Interport Global Logistics - Total Logistics Solutions Provider">
    <meta name="keywords" content="logistics, cargo, solutions, addons, sea freight, air freight, rail freight, cargo insurance, container freight station, custom clearance, import export consolidation, nvocc, door to door delivery, iso flexi tanks, project logistics, heavy lift, break bulk, warehousing, our packing, transportation and distribution, rfid solutions, warehouse management, turnkey projects, logistic solutions, exhibition cargo, hazardous cargo, project cargo, ivrs phone track, airlines, bankers, india info, container specification sea, container specification air, hazmat definitions, shipping glossary, iata codes, usa port codes, print your bill of lading, industry links, inco terms, air shipment, sea shipment" />
    <meta property="og:description" content="Interport Global Logistics - Total Logistics Solutions Provider">
    <meta property="og:site_name" content="Interport Global Logistics">
    <meta property="og:title" content="Interport Global Logistics">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://interportglobal.com/new/">
    <meta property="og:image" content="https://interportglobal.com/new/img/logos/logo-old.png" />
    <meta property="og:image:secure_url" content="https://interportglobal.com/new/img/logos/logo-old.png" />
    <meta property="og:image:width" content="1800" />
    <meta property="og:image:height" content="945" />
    <meta property="og:image:alt" content="Interport Global Logistics" />
    <meta property="og:image:type" content="image/png" />
    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="Interport Global Logistics">
    <meta name="twitter:creator" content="Interport Global Logistics">
    <meta name="twitter:title" content="Interport Global Logistics">
    <meta name="twitter:description" content="Interport Global Logistics - Total Logistics Solutions Provider">
    <link rel="shortcut icon" href="img/logos/logo-old.png" />
    <link rel="apple-touch-icon" href="img/logos/logo-old.png" />
    <link rel="apple-touch-icon" sizes="72x72" href="img/logos/logo-old.png" />
    <link rel="apple-touch-icon" sizes="114x114" href="img/logos/logo-old.png" />
    <link rel="stylesheet" href="css/plugins.css">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="css/mystyle.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link href="css/new-responsive.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/f70dd43e17.js" crossorigin="anonymous"></script>
    <script type="text/javascript">
        function googleTranslateElementInit2() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                autoDisplay: false
            }, 'google_translate_element2');
        }
    </script>
    <script type="text/javascript"
        src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2">
    </script>
    <script type="text/javascript">
        eval(function (p, a, c, k, e, r) {
            e = function (c) {
                return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) :
                    c
                    .toString(36))
            };
            if (!''.replace(/^/, String)) {
                while (c--) r[e(c)] = k[c] || e(c);
                k = [function (e) {
                    return r[e]
                }];
                e = function () {
                    return '\\w+'
                };
                c = 1
            };
            while (c--)
                if (k[c]) p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]);
            return p
        }('6 7(a,b){n{4(2.9){3 c=2.9("o");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s(\'t\'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a==\'\')v;3 b=a.w(\'|\')[1];3 c;3 d=2.x(\'y\');z(3 i=0;i<d.5;i++)4(d[i].A==\'B-C-D\')c=d[i];4(2.j(\'k\')==E||2.j(\'k\').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,\'m\');7(c,\'m\')}}',
            43, 43,
            '||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500'
            .split('|'), 0, {}))
    </script>
    <script>
        (function (w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-M9TZHXX');
    </script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-179148496-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-179148496-1');
    </script>
    <script>
        ! function (f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function () {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '420989926550304');
        fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
            src="https://www.facebook.com/tr?id=420989926550304&ev=PageView&noscript=1" /></noscript>
</head>

<body>
    <div id="preloader"></div>
    <div class="main-wrapper ">
        <header class="header-style1 menu_area-light">
            <div class="navbar-default">
                <div class="top-search bg-secondary">
                    <div class="container-fluid px-lg-1-6 px-xl-2-5 px-xxl-2-9">
                        <form class="search-form" action="" method="GET" accept-charset="utf-8">
                            <div class="input-group">
                                <span class="input-group-addon cursor-pointer">
                                    <button class="search-form_submit fas fa-search text-white" type="submit"></button>
                                </span>
                                <input type="text" class="search-form_input form-control" name="s" autocomplete="off"
                                    placeholder="Type &amp; hit enter...">
                                <span class="input-group-addon close-search mt-1"><i class="fas fa-times"></i></span>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="container-fluid px-lg-1-6 px-xl-2-5 px-xxl-2-9">
                    <div class="row align-items-center">
                        <div class="col-12 col-lg-12 p-0 px-lg-2">
                            <div class="menu_area alt-font">
                                <nav class="navbar navbar-expand-lg navbar-light p-0">
                                    <div class="navbar-header navbar-header-custom">
                                        <a href="index.php" class="navbar-brand logochange">
                                            <img id="logo" class="home-logo" src="img/logos/logo-w.png" alt="logo" />
                                            <img id="logo" class="other-logo" src="img/logos/logo-b.png" alt="logo" />
                                        </a>
                                    </div>
                                    <div class="navbar-toggler bg-primary"></div>
                                    <ul class="navbar-nav" id="nav" style="display: none;">
                                        <li
                                            >
                                            <a href="https://interportglobal.com/index.php">Home</a></li>
                                        <li >
                                            <a href="about.php">About Us</a>
                                        </li>
                                        <li
                                            class="d-none d-lg-block d-xl-block 
                                            ">
                                            <a href="https://interportglobal.com/services.php">Services</a>
                                            <ul class="row megamenu">
                                                <li class="col-lg-4 col-sm-12">
                                                    <ul>
                                                        <li><a href="freight-forwarding.php">Freight Forwarding</a></li>
                                                        <li><a href="ocean-freight.php">Ocean Freight</a></li>
                                                        <li><a href="air-freight.php">Air Freight</a></li>
                                                        <li><a href="rail-freight.php">Rail Freight</a></li>
                                                        <li><a href="road-freight.php">Road Freight</a></li>
                                                        <li><a href="3pl-warehousing.php">3PL Warehousing</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <ul>
                                                        <li><a href="custom-brokerage.php">Custom Brokerage</a></li>
                                                        <li><a href="hazardous-cargo.php">Hazardous Cargo</a></li>
                                                        <li><a href="project-cargo.php">Project Cargo</a></li>
                                                        <li><a href="heavy-lift.php">Heavy Lift</a></li>
                                                        <li><a href="door-to-door-program.php">Door To Door
                                                                Program</a></li>
                                                        <li><a href="vessel-handling.php">Vessel Handling</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <ul >
                                                        <li><a href="turnkey-projects.php">Turnkey Projects</a></li>
                                                        <li><a href="iso-flexi-tanks.php">ISO Tanks / Flexi Tanks</a>
                                                        </li>
                                                        <li><a href="cargo-insurance.php">Cargo Insurance</a></li>
                                                        <li><a href="nvocc.php">NVOCC</a></li>
                                                        <li><a href="import-export-consolidation.php">Import / Export
                                                                Consolidation</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                        <li
                                            class="d-block d-lg-none d-xl-none 
                                            ">
                                            <a href="services.php">Services</a>
                                            <ul class="scrollable-list" >
                                                <li><a href="services.php">Services</a></li>
                                                <li><a href="freight-forwarding.php">Freight Forwarding</a></li>
                                                <li><a href="ocean-freight.php">Ocean Freight</a></li>
                                                <li><a href="air-freight.php">Air Freight</a></li>
                                                <li><a href="rail-freight.php">Rail Freight</a></li>
                                                <li><a href="road-freight.php">Road Freight</a></li>
                                                <li><a href="3pl-warehousing.php">3PL Warehousing</a>
                                                </li>
                                                
                                                <li><a href="custom-brokerage.php">Custom Brokerage</a></li>
                                                <li><a href="hazardous-cargo.php">Hazardous Cargo</a></li>
                                                <li><a href="project-cargo.php">Project Cargo</a></li>
                                                <li><a href="heavy-lift.php">Heavy Lift</a></li>
                                                <li><a href="door-to-door-program.php">Door To Door
                                                        Program</a></li>
                                                <li><a href="vessel-handling.php">Vessel Handling</a></li>
                                                <li><a href="turnkey-projects.php">Turnkey Projects</a></li>
                                                <li><a href="iso-flexi-tanks.php">ISO Tanks / Flexi Tanks</a>
                                                </li>
                                                
                                                <li><a href="cargo-insurance.php">Cargo Insurance</a></li>
                                                <li><a href="nvocc.php">NVOCC</a></li>
                                                <li><a href="import-export-consolidation.php">Import / Export
                                                        Consolidation</a></li>
                                            </ul>
                                        </li>
                                        
                                        <li
                                            class="active">
                                            <a href="javascript:void(0)">Resources</a>
                                            <ul class="row megamenu">

                                                <li class="col-lg-4 col-sm-12">
                                                    <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Other
                                                        Links</span>
                                                    <ul>
                                                        <li><a href="airlines.php">Airlines</a></li>
                                                        <li><a href="bankers.php">Bankers</a></li>
                                                        <li><a href="2023-holiday-list.php">2024 Holiday List</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-4 col-sm-12">
                                                    <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Important
                                                        Info</span>
                                                    <ul  class="">
                                                    <!-- scrollable-list -->
                                                        <li><a href="india-info.php">India Info</a></li>
                                                        <li><a href="container-specification-sea.php">Container
                                                                Specification-Sea</a></li>
                                                        <li><a href="container-specification-air.php">Container
                                                                Specification-Air</a></li>
                                                        <li><a href="hazmat-definitions.php">Hazmat Definifitons</a>
                                                        </li>
                                                        <li><a href="shipping-glossary.php">Shipping Glossary</a></li>
                                                        <li><a href="iata-codes.php">IATA Codes</a></li>
                                                        <li><a href="usa-port-codes.php">USA Port Codes</a></li>
                                                        <li><a href="print-your-bill-of-lading.php">Print Your Bill Of
                                                                Lading</a></li>
                                                    </ul>
                                                </li>


                                                <li class="col-lg-4 col-sm-12">
                                                    <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Important
                                                        Links</span>
                                                    <ul>
                                                        <li><a href="industry-links.php">Industry Links</a></li>
                                                        <li><a href="inco-terms.php">INCO Terms</a></li>
                                                    </ul>
                                                </li>

                                              
                                            <li class="col-lg-4 col-sm-12">
                                                <span
                                                        class="mb-0 mb-lg-1 d-block py-2 p-lg-0 px-4 px-lg-0 sub-title font-weight-700 display-27">Payments</span>
                                            <ul>
                                                <!-- <li>
                                                   <a href="#">For India</a>     
                                                   <li> -->
                                                <li>
                                                    <a href="https://app.paycargo.com/shipandpay?region=US&vendorld=281793" target="_blank">For USA</a>
                                                </li>
                                            </ul>
                                        </li>   

                                            </ul>
                                        </li>
                                        <li >
                                            <a href="careers.php">Careers</a>
                                        </li>
                                        <li >
                                            <a href="network.php">Network</a>
                                        </li>
                                        <li 
                                            >
                                            <a href="contact.php">Contact</a>
                                            <ul class="">
                                            <!-- scroll-ul -->
                                                <li 
                                                    class="d-block d-lg-none  ">
                                                    <a href="contact.php">Contact</a>
                                                </li>
                                                <li >
                                                    <a href="enquiry-form.php">Enquiry Form</a>
                                                </li>
                                                <li >
                                                    <a href="feedback-form.php">Feedback Form</a>
                                                </li>
                                                <li >
                                                    <a href="air-shipment.php">Air Shipment Bookings</a>
                                                </li>
                                                <li >
                                                    <a href="sea-shipment.php">Sea Shipment Bookings</a>
                                                </li>
                                    
                                            </ul>
                                        </li>
                                 

                                        <li
                                            class=" d-block d-lg-none">
                                            <a href="get-a-quote.php">Get a Quote</a>
                                        </li>
                                        <li class="d-block d-lg-none">
                                            <a target="_blank"
                                                href="http://www.interportglobal.net/Logisys/customervisibility/login.aspx">Track
                                                your shipment</a>
                                        </li>
                                        <li class="d-block d-lg-none">
                                                <select class="language-dropdown" onchange="doGTranslate(this);">
                                                    <option value="">Select a language</option>
                                                    <option value="en|af">Af</option>
                                                    <option value="en|sq">sq</option>
                                                    <option value="en|am">am</option>
                                                    <option value="en|ar">ar</option>
                                                    <option value="en|hy">hy</option>
                                                    <option value="en|az">az</option>
                                                    <option value="en|eu">eu</option>
                                                    <option value="en|be">be</option>
                                                    <option value="en|bn">bn</option>
                                                    <option value="en|bs">bs</option>
                                                    <option value="en|bg">bg</option>
                                                    <option value="en|ca">ca</option>
                                                    <option value="en|ceb">ceb</option>
                                                    <option value="en|ny">ny</option>
                                                    <option value="en|zh-CN">zh-CN</option>
                                                    <option value="en|zh-TW">zh-TW</option>
                                                    <option value="en|co">co</option>
                                                    <option value="en|hr">hr</option>
                                                    <option value="en|cs">cs</option>
                                                    <option value="en|da">da</option>
                                                    <option value="en|nl">nl</option>
                                                    <option value="en|en">en</option>
                                                    <option value="en|eo">eo</option>
                                                    <option value="en|et">et</option>
                                                    <option value="en|tl">tl</option>
                                                    <option value="en|fi">fi</option>
                                                    <option value="en|fr">fr</option>
                                                    <option value="en|fy">fy</option>
                                                    <option value="en|gl">gl </option>
                                                    <option value="en|ka">ka </option>
                                                    <option value="en|de">de </option>
                                                    <option value="en|el">el </option>
                                                    <option value="en|gu">gu </option>
                                                    <option value="en|ht">ht</option>
                                                    <option value="en|ha">ha </option>
                                                    <option value="en|haw">haw</option>
                                                    <option value="en|iw">iw </option>
                                                    <option value="en|hi">hi </option>
                                                    <option value="en|hmn">hmn</option>
                                                    <option value="en|hu">hu</option>
                                                    <option value="en|is">is</option>
                                                    <option value="en|ig">ig </option>
                                                    <option value="en|id">id</option>
                                                    <option value="en|ga">ga </option>
                                                    <option value="en|it">it </option>
                                                    <option value="en|ja">ja </option>
                                                    <option value="en|jw">jw </option>
                                                    <option value="en|kn">kn </option>
                                                    <option value="en|kk">kk </option>
                                                    <option value="en|km">km </option>
                                                    <option value="en|ko">ko </option>
                                                    <option value="en|ku">ku </option>
                                                    <option value="en|ky">ky </option>
                                                    <option value="en|lo">lo </option>
                                                    <option value="en|la">la </option>
                                                    <option value="en|lv">lv </option>
                                                    <option value="en|lt">lt </option>
                                                    <option value="en|lb">lb </option>
                                                    <option value="en|mk">mk </option>
                                                    <option value="en|mg">mg </option>
                                                    <option value="en|ms">ms </option>
                                                    <option value="en|ml">ml </option>
                                                    <option value="en|mt">mt </option>
                                                    <option value="en|mi">mi </option>
                                                    <option value="en|mr">mr </option>
                                                    <option value="en|mn">mn </option>
                                                    <option value="en|my">my </option>
                                                    <option value="en|ne">ne </option>
                                                    <option value="en|no">no </option>
                                                    <option value="en|ps">ps </option>
                                                    <option value="en|fa">fa </option>
                                                    <option value="en|pl">pl </option>
                                                    <option value="en|pt">pt </option>
                                                    <option value="en|pa">pa </option>
                                                    <option value="en|ro">ro </option>
                                                    <option value="en|ru">ru </option>
                                                    <option value="en|sm">sm </option>
                                                    <option value="en|gd">gd </option>
                                                    <option value="en|sr">sr </option>
                                                    <option value="en|st">st </option>
                                                    <option value="en|sn">sn </option>
                                                    <option value="en|sd">sd </option>
                                                    <option value="en|si">si </option>
                                                    <option value="en|sk">sk </option>
                                                    <option value="en|sl">sl </option>
                                                    <option value="en|so">so </option>
                                                    <option value="en|es">es </option>
                                                    <option value="en|su">su </option>
                                                    <option value="en|sw">sw </option>
                                                    <option value="en|sv">sv </option>
                                                    <option value="en|tg">tg </option>
                                                    <option value="en|ta">ta </option>
                                                    <option value="en|te">te </option>
                                                    <option value="en|th">th </option>
                                                    <option value="en|tr">tr </option>
                                                    <option value="en|uk">uk </option>
                                                    <option value="en|ur">ur </option>
                                                    <option value="en|uz">uz </option>
                                                    <option value="en|vi">vi </option>
                                                    <option value="en|cy">cy </option>
                                                    <option value="en|xh">xh </option>
                                                    <option value="en|yi">yi </option>
                                                    <option value="en|yo">yo </option>
                                                    <option value="en|zu">zu </option>
                                                </select>
                                                <div id="google_translate_element2"></div>

                                        </li>
                                    </ul>
                                    <div class="attr-nav align-items-xl-center main-font">
                                        <ul>
                                            <li class="d-none d-xl-inline-block">
                                                <a target="_blank"
                                                    href="https://app.fieldproxy.com/public/proxy-f329b4dc-1384-4812-b392-d3278cb60ba1/igital_visibility/igtaltrack"
                                                    class="butn outline me-3">
                                                    <span>Track a shipment</span>
                                                </a>
                                            </li>
                                            <li class="d-none d-xl-inline-block">
                                                <a href="get-a-quote.php" class="butn primary">
                                                    <span>Get a Quote</span>
                                                </a>
                                            </li>
                                            <li class="d-none d-xl-inline-block">
                                                <select class="language-dropdown" onchange="doGTranslate(this);">
                                                    <option value="">en</option>
                                                    <option value="en|af">Af</option>
                                                    <option value="en|sq">sq</option>
                                                    <option value="en|am">am</option>
                                                    <option value="en|ar">ar</option>
                                                    <option value="en|hy">hy</option>
                                                    <option value="en|az">az</option>
                                                    <option value="en|eu">eu</option>
                                                    <option value="en|be">be</option>
                                                    <option value="en|bn">bn</option>
                                                    <option value="en|bs">bs</option>
                                                    <option value="en|bg">bg</option>
                                                    <option value="en|ca">ca</option>
                                                    <option value="en|ceb">ceb</option>
                                                    <option value="en|ny">ny</option>
                                                    <option value="en|zh-CN">zh-CN</option>
                                                    <option value="en|zh-TW">zh-TW</option>
                                                    <option value="en|co">co</option>
                                                    <option value="en|hr">hr</option>
                                                    <option value="en|cs">cs</option>
                                                    <option value="en|da">da</option>
                                                    <option value="en|nl">nl</option>
                                                    <option value="en|en">en</option>
                                                    <option value="en|eo">eo</option>
                                                    <option value="en|et">et</option>
                                                    <option value="en|tl">tl</option>
                                                    <option value="en|fi">fi</option>
                                                    <option value="en|fr">fr</option>
                                                    <option value="en|fy">fy</option>
                                                    <option value="en|gl">gl </option>
                                                    <option value="en|ka">ka </option>
                                                    <option value="en|de">de </option>
                                                    <option value="en|el">el </option>
                                                    <option value="en|gu">gu </option>
                                                    <option value="en|ht">ht</option>
                                                    <option value="en|ha">ha </option>
                                                    <option value="en|haw">haw</option>
                                                    <option value="en|iw">iw </option>
                                                    <option value="en|hi">hi </option>
                                                    <option value="en|hmn">hmn</option>
                                                    <option value="en|hu">hu</option>
                                                    <option value="en|is">is</option>
                                                    <option value="en|ig">ig </option>
                                                    <option value="en|id">id</option>
                                                    <option value="en|ga">ga </option>
                                                    <option value="en|it">it </option>
                                                    <option value="en|ja">ja </option>
                                                    <option value="en|jw">jw </option>
                                                    <option value="en|kn">kn </option>
                                                    <option value="en|kk">kk </option>
                                                    <option value="en|km">km </option>
                                                    <option value="en|ko">ko </option>
                                                    <option value="en|ku">ku </option>
                                                    <option value="en|ky">ky </option>
                                                    <option value="en|lo">lo </option>
                                                    <option value="en|la">la </option>
                                                    <option value="en|lv">lv </option>
                                                    <option value="en|lt">lt </option>
                                                    <option value="en|lb">lb </option>
                                                    <option value="en|mk">mk </option>
                                                    <option value="en|mg">mg </option>
                                                    <option value="en|ms">ms </option>
                                                    <option value="en|ml">ml </option>
                                                    <option value="en|mt">mt </option>
                                                    <option value="en|mi">mi </option>
                                                    <option value="en|mr">mr </option>
                                                    <option value="en|mn">mn </option>
                                                    <option value="en|my">my </option>
                                                    <option value="en|ne">ne </option>
                                                    <option value="en|no">no </option>
                                                    <option value="en|ps">ps </option>
                                                    <option value="en|fa">fa </option>
                                                    <option value="en|pl">pl </option>
                                                    <option value="en|pt">pt </option>
                                                    <option value="en|pa">pa </option>
                                                    <option value="en|ro">ro </option>
                                                    <option value="en|ru">ru </option>
                                                    <option value="en|sm">sm </option>
                                                    <option value="en|gd">gd </option>
                                                    <option value="en|sr">sr </option>
                                                    <option value="en|st">st </option>
                                                    <option value="en|sn">sn </option>
                                                    <option value="en|sd">sd </option>
                                                    <option value="en|si">si </option>
                                                    <option value="en|sk">sk </option>
                                                    <option value="en|sl">sl </option>
                                                    <option value="en|so">so </option>
                                                    <option value="en|es">es </option>
                                                    <option value="en|su">su </option>
                                                    <option value="en|sw">sw </option>
                                                    <option value="en|sv">sv </option>
                                                    <option value="en|tg">tg </option>
                                                    <option value="en|ta">ta </option>
                                                    <option value="en|te">te </option>
                                                    <option value="en|th">th </option>
                                                    <option value="en|tr">tr </option>
                                                    <option value="en|uk">uk </option>
                                                    <option value="en|ur">ur </option>
                                                    <option value="en|uz">uz </option>
                                                    <option value="en|vi">vi </option>
                                                    <option value="en|cy">cy </option>
                                                    <option value="en|xh">xh </option>
                                                    <option value="en|yi">yi </option>
                                                    <option value="en|yo">yo </option>
                                                    <option value="en|zu">zu </option>
                                                </select>
                                                <div id="google_translate_element2"></div>
                                            </li>
                                        </ul>
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <div class="modal fade" id="getaquote_modal" tabindex="-1" aria-labelledby="centeredLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title" id="centeredLabel">Get a Quote</h3>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <form class="row g-3">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_name" placeholder="Name">
                                            <label for="quote_name">Name</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-1">
                                            <input type="email" class="form-control" id="quote_email"
                                                placeholder="Email">
                                            <label for="quote_email">Email</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_phone"
                                                placeholder="Phone">
                                            <label for="quote_phone">Phone</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected>Freight Type</option>
                                                <option value="1">Freight Type 1</option>
                                                <option value="2">Freight Type 2</option>
                                                <option value="3">Freight Type 3</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_city_of_departure"
                                                placeholder="City of Departure">
                                            <label for="quote_city_of_departure">City of Departure</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_delivery_city"
                                                placeholder="Delivery City">
                                            <label for="quote_delivery_city">Delivery City</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-floating mb-1">
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected>Incoterms</option>
                                                <option value="1">Incoterms 1</option>
                                                <option value="2">Incoterms 2</option>
                                                <option value="3">Incoterms 3</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_weight"
                                                placeholder="Weight (kg)">
                                            <label for="quote_weight">Weight (kg)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_height"
                                                placeholder="Height (cm)">
                                            <label for="quote_height">Height (cm)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_width"
                                                placeholder="Width (cm)">
                                            <label for="quote_width">Width (cm)</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-floating mb-1">
                                            <input type="text" class="form-control" id="quote_length"
                                                placeholder="Length (cm)">
                                            <label for="quote_length">Length (cm)</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="quote_fragile">
                                            <label class="form-check-label" for="quote_fragile">
                                                Fragile
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="quote_express_delivery">
                                            <label class="form-check-label" for="quote_express_delivery">
                                                Express Delivery
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="quote_insurance">
                                            <label class="form-check-label" for="quote_insurance">
                                                Insurance
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="quote_packaging">
                                            <label class="form-check-label" for="quote_packaging">
                                                Packaging
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>
                    <div class="modal-footer justify-content-center">
                        <button type="button" class="butn primary">Save</button>
                    </div>
                </div>
            </div>
        </div>
<section class="page-title-section main-title-section bg-light">
    <div class="container title-container">
        <div class="row">
            <div class="col-md-12">
                <ul class="wow fadeInUp breadcrump-list" data-wow-delay="400ms">
                    <li><a href="index.php">Home</a></li>
                    <li><a>Resources</a></li>
                    <li><a>Shipping Glossary</a></li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <ul class="nav nav-tabs" id="shippinggolssaryTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="a-tab" data-bs-toggle="tab" data-bs-target="#a" type="button"
                    role="tab" aria-controls="a" aria-selected="true">A</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="b-tab" data-bs-toggle="tab" data-bs-target="#b" type="button" role="tab"
                    aria-controls="b" aria-selected="false">B</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="c-tab" data-bs-toggle="tab" data-bs-target="#c" type="button" role="tab"
                    aria-controls="c" aria-selected="false">C</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="d-tab" data-bs-toggle="tab" data-bs-target="#d" type="button" role="tab"
                    aria-controls="d" aria-selected="false">D</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="e-tab" data-bs-toggle="tab" data-bs-target="#e" type="button" role="tab"
                    aria-controls="e" aria-selected="false">E</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="f-tab" data-bs-toggle="tab" data-bs-target="#f" type="button" role="tab"
                    aria-controls="f" aria-selected="false">F</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="g-tab" data-bs-toggle="tab" data-bs-target="#g" type="button" role="tab"
                    aria-controls="g" aria-selected="false">G</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="h-tab" data-bs-toggle="tab" data-bs-target="#h" type="button" role="tab"
                    aria-controls="h" aria-selected="false">H</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="i-tab" data-bs-toggle="tab" data-bs-target="#i" type="button" role="tab"
                    aria-controls="i" aria-selected="false">I</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="j-tab" data-bs-toggle="tab" data-bs-target="#j" type="button" role="tab"
                    aria-controls="j" aria-selected="false">J</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="k-tab" data-bs-toggle="tab" data-bs-target="#k" type="button" role="tab"
                    aria-controls="k" aria-selected="false">K</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="l-tab" data-bs-toggle="tab" data-bs-target="#l" type="button" role="tab"
                    aria-controls="l" aria-selected="false">L</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="m-tab" data-bs-toggle="tab" data-bs-target="#m" type="button" role="tab"
                    aria-controls="m" aria-selected="false">M</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="n-tab" data-bs-toggle="tab" data-bs-target="#n" type="button" role="tab"
                    aria-controls="n" aria-selected="false">N</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="o-tab" data-bs-toggle="tab" data-bs-target="#o" type="button" role="tab"
                    aria-controls="o" aria-selected="false">O</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="p-tab" data-bs-toggle="tab" data-bs-target="#p" type="button" role="tab"
                    aria-controls="p" aria-selected="false">P</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="q-tab" data-bs-toggle="tab" data-bs-target="#q" type="button" role="tab"
                    aria-controls="q" aria-selected="false">Q</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="r-tab" data-bs-toggle="tab" data-bs-target="#r" type="button" role="tab"
                    aria-controls="r" aria-selected="false">R</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="s-tab" data-bs-toggle="tab" data-bs-target="#s" type="button" role="tab"
                    aria-controls="s" aria-selected="false">S</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="t-tab" data-bs-toggle="tab" data-bs-target="#t" type="button" role="tab"
                    aria-controls="t" aria-selected="false">T</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="u-tab" data-bs-toggle="tab" data-bs-target="#u" type="button" role="tab"
                    aria-controls="u" aria-selected="false">U</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="v-tab" data-bs-toggle="tab" data-bs-target="#v" type="button" role="tab"
                    aria-controls="v" aria-selected="false">V</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="w-tab" data-bs-toggle="tab" data-bs-target="#w" type="button" role="tab"
                    aria-controls="w" aria-selected="false">W</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="x-tab" data-bs-toggle="tab" data-bs-target="#x" type="button" role="tab"
                    aria-controls="x" aria-selected="false">X</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="y-tab" data-bs-toggle="tab" data-bs-target="#y" type="button" role="tab"
                    aria-controls="y" aria-selected="false">Y</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="z-tab" data-bs-toggle="tab" data-bs-target="#z" type="button" role="tab"
                    aria-controls="z" aria-selected="false">Z</button>
            </li>
        </ul>
        <div class="tab-content" id="shippinggolssaryTabContent">
            <div class="tab-pane fade show active" id="a" role="tabpanel" aria-labelledby="a-tab">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tbody>
                        <tr>
                            <td height="20" align="left" valign="middle">
                                <img src="img/icons/list-icon.svg" alt="list" class="list-icon">
                            </td>
                            <td height="20" align="left" valign="main-txtdle"><strong>Abandonment</strong></td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle">&nbsp;</td>
                            <td height="20" align="left" valign="main-txtdle">The right a marine assured has to abandon
                                property in order to establish a constructive total loss. An underwriter is not obliged
                                to accept abandonment, but if he does he accepts responsibility for the property and
                                liabilities attaching thereto, in addition to being liable for the full sum insured.
                            </td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle">&nbsp;</td>
                            <td height="20" align="left" valign="main-txtdle">&nbsp;</td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                    class="list-icon"></td>
                            <td height="20" align="left" valign="main-txtdle"><strong>ABI &#8211; (Automated Broker
                                    Interface)</strong></td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle">&nbsp;</td>
                            <td height="20" align="left" valign="main-txtdle">A computer system that allows a Customs
                                Broker to interface directly with U.S. Customs&#8217; computer system.</td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle">&nbsp;</td>
                            <td height="20" align="left" valign="main-txtdle">&nbsp;</td>
                        </tr>
                        <tr>
                            <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                    alt="list" class="list-icon"></td>
                            <td height="20" align="left" valign="main-txtdle"><strong>Acceptance of Goods</strong></td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td>The process of receiving a consignment
                                from a consignor, usually against the issue of a receipt. As from this moment
                                and on this place the carrier&#8217;s responsibility for the consignment begins.
                            </td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                    class="list-icon"></td>
                            <td><strong>Account Party</strong></td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td>The buyer under a letter of credit. The party ultimately responsible for reimbursing the
                                issuing bank for all payments extended on its behalf.</td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                    class="list-icon"></td>
                            <td height="20"><span><strong> Act of God</strong></span></td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td>Accidents of a nature beyond human control
                                such as flood, lightning or hurricane usually quoted as &#8216;force majeure&#8217;.
                            </td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                    class="list-icon"></td>
                            <td height="20" align="left" valign="main-txtdle"><span><strong>Ad Valorem</strong></span>
                            </td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="justify">In proportion to the value: A phrase applied to certain freight or
                                customs duties levied on goods, property, etc. set as a percentage of their value.
                            </td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="justify">&nbsp;</td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                    class="list-icon"></td>
                            <td height="20" align="justify"><span><strong> Advice Note</strong></span></td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="justify">A written piece of information e.g. about the status of the
                                goods.
                            </td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="justify">&nbsp;</td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                    class="list-icon"></td>
                            <td height="20" align="justify"><strong>Affreightment</strong></td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle">&nbsp;</td>
                            <td height="20" align="justify">A contract to carry goods by ship. Charter-parties and Bills
                                of Lading are contracts of affreightment</td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle">&nbsp;</td>
                            <td height="20" align="justify">&nbsp;</td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                    class="list-icon"></td>
                            <td height="20" align="justify"><strong>After Sight</strong></td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle">&nbsp;</td>
                            <td height="20" align="justify">When a draft bears this phrase, the time begins to run from
                                its acceptance date.</td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle">&nbsp;</td>
                            <td height="20" align="justify">&nbsp;</td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                    class="list-icon"></td>
                            <td height="20" align="justify"><strong> <span>Agency Fee</span></strong></td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td>Fee payable by a ship owner or ship operator to a port
                                agent.
                            </td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                    class="list-icon"></td>
                            <td height="20" align="justify"><strong> <span>Agent</span></strong></td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="justify">A person or organization authorized to act for or on behalf
                                of another person or organization
                            </td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="justify">An Agent is a corporate body with, which there is an
                                agreement to perform particular functions on behalf of them at an agreed payment. An
                                Agent is either a part of the organisation or an independent body.
                            </td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="justify">&nbsp;</td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                    class="list-icon"></td>
                            <td align="left" valign="middle"><strong>AGR Imports</strong></td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="left" valign="middle">American goods returned.</td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="justify">&nbsp;</td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                    class="list-icon"></td>
                            <td height="20" align="justify"><strong><span>Air Waybill</span></strong></td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="justify">Abbreviation: AWB<br />
                                A document made out by or on behalf of the carrier(s) confirming receipt of the
                                goods by the carrier and evidencing the contract between the shipper and the
                                carrier(s) for the carriage of goods as described therein.
                            </td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="justify">&nbsp;</td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                    class="list-icon"></td>
                            <td height="20" align="justify"><strong><span>Allotment</span></strong></td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="justify">A share of the capacity of a means of transport assigned to
                                a certain party, e.g. a carrier or an agent, for the purpose of the booking of cargo
                                for a specific voyage.
                            </td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="justify">&nbsp;</td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                    class="list-icon"></td>
                            <td align="left" valign="middle"><strong>All-in</strong></td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="left" valign="middle">A freight quotation including all charges, often in one
                                lump sum rather than broken down.</td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="justify">&nbsp;</td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                    class="list-icon"></td>
                            <td align="left" valign="middle"><strong>All-risk Insurance</strong></td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="left" valign="middle">The broadest form of coverage available, providing
                                protection against all risk of physical loss or damage from any external cause. Does not
                                cover loss or damage due to delay, inherent vice, inadequate packaging, or loss of
                                market.</td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="justify">&nbsp;</td>
                        </tr>
                        <tr>
                            <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                    class="list-icon"></td>
                            <td height="20" align="justify"><strong><span>American Bureau of Shipping</span></strong>
                            </td>
                        </tr>
                        <tr>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td>Abbreviation: ABS<br />
                                American classification society which has established rules and regulations for
                                the classification of seagoing vessels or equipment
            </div>
            </td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list" class="list-icon"></td>
                <td><strong>Antidumping Duty</strong></td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td>A duty assessed on imported merchandise that is subject to an antidumping duty order.
                    The antidumping duty is assessed on an entry-by-entry basis in an amount equal to the
                    difference between the United States price of that entry and the foreign market value of
                    such or similar merchandise at the time the merchandise was sold to the United States.
                </td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                        class="list-icon"></td>
                <td height="20" align="justify"><strong><span>Arbitration</span></strong></td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td align="justify">The process of referring to an agreed person for judgement
                    on issues of dispute, without requiring the use of courts.
                </td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td align="justify">&nbsp;</td>
            </tr>
            <tr>
                <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                        class="list-icon"></td>
                <td height="20" align="justify"><strong><span>Arrival Date</span></strong></td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td align="justify">The date on which goods or a means of transport is due to
                    arrive at the delivery site of the transport.
                </td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td align="justify">&nbsp;</td>
            </tr>
            <tr>
                <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                        class="list-icon"></td>
                <td height="20" align="justify"><strong><span>Arrival Notice</span></strong></td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td align="justify">A notice sent by a carrier to a nominated notify party advising of the
                    arrival of a certain shipment or consignment.</td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td align="justify">&nbsp;</td>
            </tr>
            <tr>
                <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                        class="list-icon"></td>
                <td height="20" align="justify"><strong><span>Assignment</span></strong></td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td align="justify"> The transfer of certain rights from one party to another.</td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td align="justify">&nbsp;</td>
            </tr>
            <tr>
                <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                        class="list-icon"></td>
                <td height="20" align="justify"><strong>Authorised Consignee / Consignor</strong></td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td align="justify">A trader authorized by the European Commission (regulation 2454/93) to
                    receive or dispatch consignments under transit procedures without having to present
                    goods and documents directly at the customs office.</td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td align="justify">&nbsp;</td>
            </tr>
            <tr>
                <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                        class="list-icon"></td>
                <td height="20" align="justify"><strong>Authorization</strong></td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td>The commission to a certain person or body to act on behalf of another person or body.
                    The person or body can be authorized e.g. to issue Bills of Lading or to collect
                    freight.</td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                        class="list-icon"></td>
                <td height="20" align="justify"><strong>Average</strong></td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td align="justify">In marine insurance: a loss or damage to or in respect of goods or
                    equipment<br />
                    The numerical result obtained by dividing the sum of two or more quantities by the
                    number of quantities</td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td align="justify">&nbsp;</td>
            </tr>
            <tr>
                <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                        class="list-icon"></td>
                <td height="20" align="justify"><span class="main-txttext6"><strong>Average
                            Adjusters</strong></span><strong><span class="main-txttext6"></span></strong>
                </td>
            </tr>
            <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td align="justify">In general average affairs average adjusters are entrusted with the task
                    of apportioning the loss and expenditure over the parties interested in the maritime
                    venture and to determine which expenses are to be regarded as average or general
                    average.</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td> <img src="img/icons/list-icon.svg" alt="list" class="list-icon"></td>
                <td align="left" valign="middle"><strong>Average Bond</strong></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td align="left" valign="middle">An agreement signed by all interested parties acknowledging
                    their liability to pay a share of the loss under General Average.</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td align="left" valign="middle">&nbsp;</td>
            </tr>
            <tr>
                <td> <img src="img/icons/list-icon.svg" alt="list" class="list-icon"></td>
                <td align="left" valign="middle"><strong>Award</strong></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td align="left" valign="middle">The decision given by an arbitrator, to whom a matter in
                    dispute has been referred. An arbitrator states only the effect of his decision, without
                    reasons thus differing from a judge, who usually states the grounds of his judgment.
                </td>
            </tr>
            </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="b" role="tabpanel" aria-labelledby="b-tab">
            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td valign="middle" height="20" align="left"><strong>B / L</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">A particular article, stipulation or single proviso in a Bill of Lading.
                            A clause can be standard and can be pre-printed on the B / L.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span class="main-txt"><strong>BSI Container
                                    Specification</strong></span></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">Accidents of a nature beyond human control such as flood, lightning or
                            hurricane usually quoted as &#8216;force majeure&#8217;.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="justify"><span class="main-txt"><strong>Bank Guarantee</strong></span></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">An undertaking by a bank to be answerable for payment of a sum of money
                            in the event of non performance by the party on whose behalf the guarantee is issued.
                        </td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span class="main-txt"><strong>Bar Coding</strong></span>
                        </td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">A method of encoding data for fast and accurate electronic readability.
                            Bar codes are a series of alternating bars and spaces printed or stamped on products,
                            labels, or other media, representing encoded information which can be read by electronic
                            readers, used to facilitate timely and accurate input of data to a computer system. Bar
                            codes represent letters and/or numbers and special characters like +, /, -, etc.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><span class="main-txt"><strong>Bay</strong></span></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">A vertical division of a vessel from stem to stern, used as a part of
                            the indication of a stowage place for containers. The numbers run from stem to stern;
                            odd numbers indicate a 20 foot position, even numbers indicate a 40 foot position.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span class="main-txt"><strong>Bay
                                    Plan</strong></span><strong><span class="main-txt"></span></strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">A stowage plan which shows the locations of all the containers on the
                            vessel.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span class="main-txt"><strong>Berth</strong></span></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">A location in a port where a vessel can be moored often indicated by a
                            code or name.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Bilateral Transport Agreement</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">Agreement between two nations concerning their transport relations.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Bill of Exchange</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">An unconditional order in writing to pay a certain sum of money to a
                            named person.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><span class="main-txttext6"><strong>Bill of
                                    Health</strong></span><strong><span class="orangenormal style19"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">The Bill of Health is the certificate issued by local medical
                            authorities indicating the general health conditions in the port of departure or in the
                            ports of call. The Bill of Health must have been visaed before departure by the Consul
                            of the country of destination.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">When a vessel has free pratique, this means that the vessel has a clean
                            Bill of Health certifying that there is no question of contagious disease and that all
                            quarantine regulations have been complied with, so that people may embark and disembark.
                        </td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Bill of Lading</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">Abbreviation: B/L, plural Bs/L<br />
                            A document which evidences a contract of carriage by sea.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>The document has the following functions: </strong>
                        </td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">A receipt for goods, signed by a duly authorised person on behalf of the
                            carriers</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">A document of title to the goods described therein<span
                                class="normal1 style21"> </span></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">Evidence of the terms and conditions of carriage agreed upon between the
                            two parties<span class="normal1 style21"></span></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="justify"><strong>At the moment 3 different models are used:</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">A document for either Combined Transport or Port to Port shipments
                            depending whether the relevant spaces for place of receipt and/or place of delivery are
                            indicated on the face of the document.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">A classic marine Bill of Lading in which the carrier is also responsible
                            for the part of the transport actually performed by himself</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">Sea Waybill: A non-negotiable document, which can only be made out to a
                            named consignee. No surrender of the document by the consignee is required</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Bill of Lading Clause</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">A particular article, stipulation or single proviso in a Bill of Lading.
                            A clause can be standard and can be pre-printed on the B/L.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Bill of Material</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">A list of all parts, sub-assemblies and raw materials that constitute a
                            particular assembly, showing the quantity of each required item.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong> Block Train</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td class="main-txt">A number of railway wagons (loaded with containers), departing from a
                            certain place and running straight to a place of destination, without marshalling,
                            transhipping or any coupling or de-coupling of wagons.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Bona Fide</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td class="main-txt">In good faith; without dishonesty, fraud or deceit.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Bonded</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">The storage of certain goods under charge of customs viz. customs seal
                            until the import duties are paid or until the goods are taken out of the country.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">Bonded warehouse (place where goods can be placed under bond)<span
                                class="normal1 style21"> </span></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">Bonded store (place on a vessel where goods are placed behind seal until
                            the time that the vessel leaves the port or country again)</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">Bonded goods (dutiable goods upon which duties have not been paid i.e.
                            goods in transit or warehoused pending customs clearance)<span
                                class="normal1 style21"></span></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Booking</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">The offering by a shipper of cargo for transport and the acceptance of
                            the offering by the carrier or his agent.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span class="main-txttext6"><strong>Booking Reference
                                    Numbe</strong></span><strong><span class="orangenormal style19">r</span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">The number assigned to a certain booking by the carrier or his agent.
                        </td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Break Bulk</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">To commence discharge<span class="normal1 style21"> </span></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">To strip unitised cargo</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span class="main-txttext6"><strong>Break Bulk
                                    Cargo</strong></span><strong><span class="orangenormal style19"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">General cargo conventionally stowed as opposed to unitised,
                            containerised and Roll On-Roll Off cargo.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Broker</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">Person who acts as an agent or intermediary in negotiating contracts.
                        </td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Brussels Tariff Nomenclature</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">The old Customs Co-operation Council Nomenclature for the classification
                            of goods. Now replaced by the Harmonised System.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Buffer Stock</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">A quantity of goods or articles kept in store to safeguard against
                            unforeseen shortages or demands.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify"><span class="style59"></span></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="justify"><strong>Bulk Cargo</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">Unpacked homogeneous cargo poured loose in a certain space of a vessel
                            or container e.g. oil and grain.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Bulk Carrier</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">Single deck vessel designed to carry homogeneous unpacked dry cargoes
                            such as grain, iron ore and coal.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify"><span class="style59"></span></td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Bulk Container</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">A container designed for the carriage of free-flowing dry cargoes, which
                            are loaded through hatchways in the roof of the container and discharged through
                            hatchways at one end of the container.</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="21" align="left">&nbsp;</td>
                        <td height="21" align="justify"><span class="style59"></span></td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span class="main-txttext6"><strong>Bunker Adjustment
                                    Factor</strong></span><strong><span class="orangenormal style19"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">Abbreviation: BAF<br />
                            Adjustment applied by liner or liner conferences to offset the effect of fluctuations in
                            the cost of bunkers.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span
                                class="main-txttext6"><strong>Bunkers</strong></span><strong><span
                                    class="orangenormal style19"></span></strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">Quantity of fuel on board a vessel.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify"><span class="style59"></span></td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Bureau Veritas</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">French classification society.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify"><span class="style59"></span></td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Business Process</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">A business process is the action taken to respond to particular events,
                            convert inputs into outputs, and produce particular results. Business processes are what
                            the enterprise must do to conduct its business successfully.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Business Process Model</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td class="main-txt">The business process model provides a breakdown (process decomposition)
                            of all levels of business processes within the scope of a business area. It also shows
                            process dynamics, lower-level process interrelationships. In Summary it includes all
                            diagrams related to a process definition that allows for understanding what the business
                            process is doing (and not how).</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td><span class="style59"></span></td>
                    </tr>
                    <tr>
                        <td valign="middle" height="20" align="left"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Buyer</strong></td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td class="main-txt">Party to which merchandise is sold.</td>
                    </tr>
                    <tr>
                        <td valign="middle" align="left">&nbsp;</td>
                        <td class="main-txt">The process of receiving a consignment from a consignor, usually
                            against the issue of a receipt. As from this moment and on this place the
                            carrier&#8217;s responsibility for the consignment begins.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="c" role="tabpanel" aria-labelledby="c-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>CAD</strong><strong></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Terms of payment: if the buyer of goods pays for the goods against
                            transfer of the documents, entitling him to obtain delivery of the goods from the
                            carrier.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>CAF</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Adjustment applied by P&amp;O Nedlloyd lines or liner conferences on
                            freight rates to offset losses or gains for carriers resulting from fluctuations in
                            exchange rates of tariff currencies.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>CENSA</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Council of European and Japanese National Shipowner&#8217;s
                            Associations.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Cabotage</strong><strong></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Transport of goods between two ports or places located in the same
                            country</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Transport of cargo in a country other than the country where the vehicle
                            is registered road-cargo)</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The carriage of a container from a surplus area to an area specified by
                            the Owner of that container, in exchange of which and during which the operator can use
                            this container</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Call</strong><strong></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The visit of a vessel to a port.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Call Sign</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A code published by the International Telecommunication Union in its
                            annual List of Ships&#8217; Stations to be used for the information interchange between
                            vessels, port authorities and other relevant participants in international trade.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td class="style21" align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"><strong>Note:</strong> The code structure is based on a three digit
                            designation series assigned by the ITU and a one digit assigned by the country of
                            registration.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Capacity</strong><strong></strong><strong></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The ability, in a given time, of a resource measured in quality and
                            quantity</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The quantity of goods which can be stored in or loaded into a warehouse,
                            store and/or loaded into a means of transport at a particular time</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify" class="main-txttext6">
                            <strong>Cargo</strong><strong></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Goods transported or to be transported, all goods carried on a ship
                            covered by a B/L.<br />
                            Any goods, wares, merchandise, and articles of every kind whatsoever carried on a ship,
                            other than mail, ship&#8217;s stores, ship&#8217;s spare parts, ship&#8217;s equipment,
                            stowage material, crew&#8217;s effects and passengers&#8217; accompanied baggage
                            (IMO)<br />
                            Any property carried on an aircraft, other than mail, stores and accompanied or
                            mishandled baggage Also referred to as &#8216;goods&#8217; (ICAO)</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Cargo Handling</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">All procedures necessary to enable the physical handling of goods.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Cargo Tracer</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A document sent by the agent to all relevant parties, stating that
                            certain cargo is either missing or over-landed.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Cargo Unit</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A vehicle, container, pallet, flat, portable tank or any other entity or
                            any part thereof which belongs to the ship but is not permanently attached to that ship.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify" class="main-txttext6">
                            <strong>Carriage</strong><strong></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The process of transporting (conveying) cargo, from one point to
                            another.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Carriage Paid To</strong> (&#8230;named place of destination)</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>Abbreviation: CPT</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Carriage and Insurance Paid To</strong> (&#8230;named place of
                            destination)</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>Abbreviation: CIP</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Carrier </strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>The party undertaking transport of goods from one point to another.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong> Carrier Haulage</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>The inland transport service, which is performed by the sea-carrier under the terms and
                            conditions of the tariff and of the relevant transport document.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Carriers Bill of Lading Ports</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>Terminal, Pre-terminal port or Post-terminal Port as per tariff, indicated on the Bill
                            of Lading and which is not the port physically called at by Carriers&#8217; ocean
                            vessels.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td><strong> Note: </strong>Under normal circumstances in the B/L only ports should be
                            mentioned which are actually called at.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Carriers Lien</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>When the shipper ships goods &#8216;collect&#8217;, the carrier has a possessory claim
                            on these goods, which means that the carrier can retain possession of the goods as
                            security for the charges due</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Cartage</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>Abbreviation: CAD</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>Terms of payment: if the buyer of goods pays for the goods against transfer of the
                            documents, entitling him to obtain delivery of the goods from the carrier.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Cash On Delivery</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: COD</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Terms of payment: if the carrier collects a payment from the consignee
                            and remits the amount to the shipper (air cargo).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Caveat Emptor</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Let the buyer beware, purchaser must ascertain the condition of the
                            goods to be purchased prior to the purchase.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Cellular Vessel</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A vessel, specially designed and equipped for the carriage of
                            containers.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Certificate of Classification </strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A certificate, issued by the classification society and stating the
                            class under which a vessel is registered.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Certificate of Origin</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A certificate, showing the country of original production of goods.
                            Frequently used by customs in ascertaining duties under preferential tariff programmes
                            or in connection with regulating imports from specific sources.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Charge</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">An amount to be paid for carriage of goods based on the applicable rate
                            of such carriage, or an amount to be paid for a special or incidental service in
                            connection with the carriage of goods.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Charge Type</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A separate, identifiable element of charges to be used in the
                            pricing/rating of common services rendered to customers.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Charter Party </strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A contract in which the ship owner agrees to place his vessel or a part
                            of it at the disposal of a third party, the charterer, for the carriage of goods for
                            which he receives a freight per ton cargo, or to let his vessel for a definite period or
                            trip for which a hire is paid</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">synonym: Charter Contract</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"><span class="style67"></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Charterer</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The legal person who has signed a charter party with the owner of a
                            vessel or an aircraft and thus hires or leases a vessel or an aircraft or a part of the
                            capacity thereof.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify" class="main-txttext6">
                            <strong>Chassis</strong><strong></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A wheeled carriage onto which an ocean container is mounted for inland
                            conveyance<br />
                            The part of a motor vehicle that includes the engine, the frame, suspension system,
                            wheels, steering mechanism etc., but not the body</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify" class="main-txttext6">
                            <strong>Claim</strong><strong></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A charge made against a carrier for loss, damage or delay.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"><span class="style67"></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify" class="main-txttext6">
                            <strong>Classification</strong><strong></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Arrangement according to a systematic division of a number of objects
                            into groups, based on some likeness or some common traits.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"><span class="style67"></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Classification Society</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">An Organisation, whose main function is to carry out surveys of vessels,
                            its purpose being to set and maintain standards of construction and upkeep for vessels,
                            their engines and their safety equipment. A classification society also inspects and
                            approves the construction of containers.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Clean Bill of Lading</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>A Bill of Lading which does not contain any qualification about the apparent order and
                            condition of the goods to be transported (it bears no stamped clauses on the front of
                            the B/L). It bears no superimposed clauses expressly declaring a defective condition of
                            the goods or packaging (resolution of the ICS 1951).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Clean on Board</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>When goods are loaded on board and the document issued in respect to these goods is
                            clean.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td><strong> Note:</strong> Through the usage of the UCP 500 rules the term has now become
                            superfluous.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Client</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>A party with which a company has a commercial relationship concerning the transport of
                            e.g. cargo or concerning certain services of the company concerned, either directly or
                            through an agent.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Co-loading</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>The loading, on the way, of cargo from another shipper, having the same final
                            destination as the cargo loaded earlier.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Combined Transport</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>Intermodal transport where the major part of the journey is by one mode such as rail,
                            inland waterway or sea and any initial and/or final leg carried out by another mode such
                            as road.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Combined Transport Document</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>Abbreviation: CTD</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>Negotiable or non-negotiable document evidencing a contract for the performance and/or
                            procurement of performance of combined transport of goods.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>Thus a combined transport document is a document issued by a Carrier who contracts as a
                            principal with the Merchant to effect a combined transport often on a door-to-door
                            basis.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Combined Transport Operator</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: CTO</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A party who undertakes to carry goods with different modes of transport.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Commercial Invoice</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A document showing commercial values of the transaction between the
                            buyer and seller.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify" class="main-txttext6">
                            <strong>Commodity</strong><strong></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Indication of the type of goods. Commodities are coded according to the
                            harmonised system.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Conditions </strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Anything called for as requirements before the performance or completion
                            of something else</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Contractual stipulations which are printed on a document or provided
                            separately</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Conditions of Carriage</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The general terms and conditions established by a carrier in respect of
                            the carriage (air cargo).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Conditions of Contract</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Terms and conditions shown on the Air Waybill (air cargo).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Conference</strong><strong></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Accumulation of vessels at a port to the extent that vessels arriving to
                            load or discharge are obliged to wait for a vacant berth.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Consignee</strong><strong></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The party such as mentioned in the transport document by whom the goods,
                            cargo or containers are to be received.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Consignment</strong><strong></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A separate identifiable number of goods (available to be) transported
                            from one consignor to one consignee via one or more than one modes of transport and
                            specified in one single transport document.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Consignment Instructions</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Instructions from either the seller/consignor or the buyer/consignee to
                            a freight forwarder, carrier or his agent, or other provider of a service, enabling the
                            movement of goods and associated activities. The following functions can be covered:
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="d" role="tabpanel" aria-labelledby="d-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Damaged Cargo Report</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Written statement concerning established damages to cargo and/or
                            equipment.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Dangerous Goods</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"> Goods are to be considered dangerous if the transport of such goods
                            might cause harm, risk, peril, or other evil to people, environment, equipment or any
                            property whatsoever.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Dangerous Goods Declaration</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Document issued by a consignor in accordance with applicable conventions
                            or regulations, describing hazardous goods or materials for transport purposes, and
                            stating that the latter have been packed and labelled in accordance with the provisions
                            of the relevant conventions or regulations.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Dangerous Goods Packing Certificate</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"> A document as part of the dangerous goods declaration in which the
                            responsible party declares that the cargo has been stowed in accordance with the rules
                            in a clean container in compliance with the IMDG regulations and properly secured.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong> Date Draft </strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A draft that matures in a specified number of days after
                            issuance without regard to date of acceptance.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>DAF (Delivered At Frontier)</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Delivered At Frontier (DAF) The seller (exporter) is
                            responsible for all costs involved in delivering the goods to the named point and place
                            at the frontier. Risk of loss transfers at the frontier. The buyer must pay the costs
                            and bear the risk of unloading the goods, clearing Customs, and transporting the goods
                            to the final destination. If FOB is the Customs valuation basis, the international
                            insurance and freight costs must be deducted from the DAF price.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>DDU (Delivered Duty Unpaid) </strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The seller (exporter) is responsible for all costs involved
                            in delivering the goods to a named place of destination where the goods are placed at
                            the disposal of the buyer. The buyer (importer) assumes risk of loss at that point and
                            must clear Customs and pay duties and provide inland transportation &amp; insurance to
                            the final destination.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>DDP (Delivered Duty Paid)</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The seller (exporter) is responsible for all costs involved
                            in delivering the goods to a named place of destination and for clearing Customs in the
                            country of import. Under a DDP Incoterm, the seller provides literally door-to-door
                            delivery, including Customs clearance in the port of export and the port of destination.
                            Thus the seller bears the entire risk of loss until goods are delivered to the
                            buyer&#8217;s premises. A DDP transaction will read &#8220;DDP named place of
                            destination&#8221;. For example, assuming goods imported through Baltimore are delivered
                            to Silver Spring , the Incoterm would read &#8220;DDP, Silver Spring &#8220;. If CIF is
                            the Customs valuation basis, the costs of unloading the vessel, clearing Customs, and
                            delivery to the buyer&#8217;s premises in the country of destination including inland
                            insurance, must be deducted to arrive at the CIF value.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Deadfreight</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Slots paid for but not used.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong
                                    class="main-txttext6">Deadweight</strong></span><strong
                                class="main-txttext6"></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"> Abbreviation: DWT</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"> The total weight of cargo, cargo equipment, bunkers, provisions, water,
                            stores and spare parts which a vessel can lift when loaded to her maximum draught as
                            applicable under the circumstances. The dead-weight is expressed in tons.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Degroupage</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The ability, in a given time, of a resource measured in quality and
                            quantity</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The quantity of goods which can be stored in or loaded into a warehouse,
                            store and/or loaded into a means of transport at a particular time</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span class="main-txttext6"><strong>Delivered Duty
                                    Paid</strong></span><strong> </strong>(&#8230;named place of destination)</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: DDP</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span class="main-txttext6"><strong>Delivered Duty
                                    Unpaid</strong></span><strong> </strong>(&#8230;named place of destination)</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: DDU</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span class="main-txttext6"><strong>Delivered Ex
                                    Quay</strong></span><strong> </strong>(&#8230;named port of destination)</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: DEQ</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong class="main-txttext6">Delivered Ex
                                Ship</strong>(&#8230;named port of destination)</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: DES</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Delivery Instruction</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Document issued by a buyer giving instructions regarding the details of
                            the delivery of goods ordered.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Delivery Note</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A document recording the delivery of products to a consignee (customer).
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Delivery Order </strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>A carrier&#8217;s delivery order (negotiable document) is used for splitting a B/L
                            (after surrender) in different parcels and have the same function as a B/L.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td> The authorisation of the entitled party for the shipment to a party other than the
                            consignee showed on the Air Waybill (air cargo)</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify">
                            <p><strong> Demurrage</strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"> A variable fee charged to carriers and/or customers for the use of Unit
                            Load Devices (ULD&#8217;s) owned by a carrier beyond the free time of shipment</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Additional charge imposed for exceeding the free time, which is included
                            in the rate and allowed for the use of certain equipment at the terminal</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>DEQ (Delivered Ex-quay)</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The seller (exporter) is responsible for all costs involved
                            in transporting the goods to the wharf (quay) at the port of destination. The buyer must
                            pay duties, clear Customs, and pay the cost/bear the risk of loss from that point
                            forward. If FOB is the Customs valuation basis, the international insurance and freight
                            costs, in addition to unloading costs, must be deducted from the DEQ price.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>DES (Delivered Ex-ship)</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The seller (exporter) is responsible for all costs involved
                            in delivering the goods to a named port of destination. Upon arrival, the goods are made
                            available to the buyer (importer) on-board the vessel. Therefore, the seller is
                            responsible for all costs/risk of loss prior to unloading at the port of destination.
                            The buyer (importer) must have the goods unloaded, pay duties, clear Customs and provide
                            inland transportation &amp; insurance to the final destination.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Despatch Advice</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"> Information send by shippers to the recipient of goods informing that
                            specified goods are sent or ready to be sent advising the detailed contents of the
                            consignment.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"><span class="style67"></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Destination</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"> Place for which goods or a vehicle is bound
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td class="normal1" align="justify">The ultimate stopping place according to the contract of
                            carriage (air cargo)
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong
                                    class="main-txttext6">Detention</strong></span><strong
                                class="main-txttext6"></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Keeping equipment beyond the time allowed.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Detention Charge</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"> Charges levied on usage of equipment exceeding free time period as
                            stipulated in the pertinent inland rules and conditions.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong
                                    class="main-txttext6">Devanning</strong></span><strong
                                class="main-txttext6"></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">See Stripping, UnpackingDeviation from a Route</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>A divergence from the agreed or customary route.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><span><strong class="main-txttext6">Dimensions</strong></span><strong
                                class="main-txttext6"></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>Measurements in length, width and height, regarding cargo.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Direct Delivery</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td> The conveyance of goods directly from the vendor to the buyer. Frequently used if a
                            third party acts as intermediary agent between vendor and buyer</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td> Direct discharge from vessel onto railroad car, road vehicle or barge with the purpose
                            of immediate transport from the port area (usually occurs when ports lack adequate
                            storage space or when ports are not equipped to handle a specific cargo)</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td><strong>Direct Interchange </strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>Transfer of leased equipment from one lessee to another (container).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Direct Route</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>The shortest operated route between two points.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><span><strong class="main-txttext6">Discharge</strong></span><strong
                                class="main-txttext6"></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>The unloading of a vehicle, a vessel or an aircraft</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>The landing of cargo</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Discrepancy</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>Difference between the particulars given and the particulars found.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td><span class="style67"></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Distribution Centre</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>A warehouse for the receipt, the storage and the dispersal of goods among customers.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Distribution Channel</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The route by which a company distributes goods.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"><span class="style67"></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Door to Door Transport</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"> The transport of cargo from the premises of the consignor to the
                            premises of the consignee.<br />
                            Note: In the United States the term &#8216;Point to Point Transport&#8217; is used
                            instead of the term &#8216;Door to Door Transport&#8217;, because the term
                            &#8216;house&#8217; may mean &#8216;customs house&#8217; or &#8216;brokers house&#8217;,
                            which are usually located in the port.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"><span class="style67"></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Double Stack Train</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A number of railway wagons, usually a block train, on which containers
                            can be stacked two- high.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"><span class="style67"></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong class="main-txttext6">Draft</strong></span><strong
                                class="main-txttext6"></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"> The draft of a vessel is the vertical distance between the waterline
                            and the underside of the keel of the vessel. During the construction of a vessel the
                            marks showing the draft are welded on each side of the vessel near the stem, the stern
                            and amain-txtships.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong
                                    class="main-txttext6">Drawback</strong></span><strong
                                class="main-txttext6"></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"> Repayment of any part of customs or excise duties previously collected
                            on imported goods, when those goods are exported again.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"><span class="style67"></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Drayage</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The hauling of a load by a cart with detachable sides (dray)</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Road transportation between the nearest railway terminal and the
                            stuffing place</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Drop off Charge</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"> Charge made by container owner and/or terminal operators for delivery
                            of a leased, or pool container into depot stock. The drop-off charge may be a
                            combination of actual handling and storage charges with surcharges.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Dunnage</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Stowage material, mainly timber or board, used to prevent damage to
                            cargo during carriage.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Duty Free Zone</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"> An area where goods or cargo can be stored without paying import
                            customs duties awaiting further transport or manufacturing.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="e" role="tabpanel" aria-labelledby="e-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>EDI For Administration, Commerce and
                                Transport</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: UN/EDIFACT</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The ISO application level syntax rules for the structuring of user data
                            and of the associated service data in the interchange of messages in an open
                            environment.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Electronic Data Interchange</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: EDI
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The transfer of structured data, by agreed standards from applications
                            on the computer of one party to the applications on the computer of another party by
                            electronic means.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Electronic Data Processing</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: EDP</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The computerised handling of information (e.g. business data).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Embargo </strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A government order prohibiting the entry or departure of commercial
                            vessels or goods at its ports</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The refusal by a carrier, for a limited period, to accept for transport
                            over any route or segment thereof, and to or from any area or point, of a connecting
                            carrier, any commodity, type of class of cargo duly tendered (air cargo)</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Emergency Medical Service</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: EMS</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Medical procedures in case of emergencies on board of vessels.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Endorsement</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The transfer of the right to obtain delivery of the goods of the carrier
                            by means of the consignee&#8217;s signature on the reverse side of a bill of lading. If
                            the name of the new consignee (transferee) is not stated, the endorsement is an open one
                            which means that every holder of the document is entitled to obtain delivery of the
                            goods.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Equipment Interchange Receipt</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: EIR</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Physical inspection and transfer receipt.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Estimated Time of Arrival</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: ETA</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The expected date and time of arrival in a certain (air)port.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Estimated Time of Departure</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: ETD</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The expected date and time when a certain (air)port is left.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Ex Works</strong></span><strong> (&#8230;named
                                place)</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: EXW</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong
                                    class="main-txttext6">Export</strong></span><strong class="main-txttext6"></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The process of carrying or sending goods to another country or
                            countries, especially for purposes of use or sale in the country of destination. The
                            sale of products to clients abroad.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Export Licence</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Document granting permission to export as detailed within a specified
                            time.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Exporter</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The party responsible for the export of goods.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="main-txtdle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="main-txtdle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>EXW (Ex-works)</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="main-txtdle">&nbsp;</td>
                        <td align="left" valign="middle">The seller (exporter) makes the goods available to the
                            buyer (importer) at the seller&#8217;s premises. The buyer is responsible for all
                            transportation costs, duties, and insurance, and accepts risk of loss of goods
                            immediately after the goods are purchased and placed outside the factory door. The Ex
                            Works price does not include the price of loading goods onto a truck or vessel, and no
                            allowance is made for clearing customs. If FOB is the Customs valuation basis of the
                            goods in the country of destination, the transportation and insurance costs from the
                            seller&#8217;s premises to the port of export must be added to the Ex Works price.</td>
                    </tr>
                </tbody>
            </table>

        </div>
        <div class="tab-pane fade" id="f" role="tabpanel" aria-labelledby="f-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>FAS (Free Alongside Ship)</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">The seller transports the goods from his place
                            of business, clears the goods for export and places them alongside the vessel at the
                            port of export, where the risk of loss shifts to the buyer. The buyer is responsible for
                            loading the goods onto the vessel (unless specified otherwise) and for paying all costs
                            involved in shipping the goods to the final destination.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>FCA (Free Carrier)</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">The seller (exporter) clears the goods for
                            export and delivers them to the carrier and place specified by the buyer. If the place
                            chosen is the seller&#8217;s place of business, the seller must load the goods onto the
                            transport vehicle; otherwise, the buyer is responsible for loading the goods. Buyer
                            assumes risk of loss from that point forward and must pay for all costs associated with
                            transporting the goods to the final destination.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>FCL </strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">Full Container Load, Full Car Load.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Federal Maritime Commission
                                (FMC)</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">The U.S. Federal agency responsible for
                            overseeing Ocean Carriers, Conferences, NVOCC&#8217;s and Ocean Freight Forwarders (now
                            called OTI&#8217;s &#8211; Ocean Transportation Intermediaries) at ocean ports and
                            inland waterways.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Feeder Vessel</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">A vessel that connects with a line vessel to
                            service a port not directly served by that line vessel.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>FEU</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">(Forty foot equivalent) Term normally used in
                            ocean freight rate negotiations referring to the equivalent of two twenty foot ocean
                            containers.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>FIATA</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">International Federation of Freight Forwarders
                            Associations.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Flag Carrier</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">An airline or vessel of one national registry
                            whose government gives it partial or total monopoly over international routes.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Flat Bed Chassis</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">A semi-trailer with a level bed and no sides or
                            tops. The floor is a standard height from the ground.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Flat Rack</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">A platform designed with the flexibility to
                            carry oversized cargo on board container vessels. It can be loaded from the sides and
                            top, usually having adjustable or removable bulkheads at the front and back.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>FMC</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Federal Maritime Commission (Control of Shipping acts USA)
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>FOB (Free On Board)</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The seller (exporter) is responsible for delivering the
                            goods from his place of business and loading them onto the vessel of at the port of
                            export as well as clearing customs in the country of export. As soon as the goods cross
                            the &#8220;ships-rails&#8221; (the ship&#8217;s threshold) the risk of loss transfers to
                            the buyer (importer). The buyer must pay for all transportation and insurance costs from
                            that point, and must clear customs in the country of import. An FOB transaction will
                            read &#8220;FOB, port of export&#8221;. For example, assuming the port of export is
                            Boston , an FOB transaction would read &#8220;FOB Boston &#8220;. If CIF is the Customs
                            valuation basis, international freight and insurance must be added to the FOB value.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Foreign Trade Zone ( FTZ )</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A port designated by the government for duty-free entry of
                            any non-prohibited goods. Merchandise may be stored, displayed, and used for
                            manufacturing within the zone and re-exported without duties being paid. Duties are
                            imposed only when the original goods or items manufactured from those goods pass from
                            the zone into an area of the country subject to customs authority. Also called a Free
                            Trade Zone.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Foreign Trade Zone Entry</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A form declaring goods which are brought duty free into a
                            Foreign Trade Zone for further processing or storage and subsequent exportation from the
                            zone into the commerce of another country.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Forwarder</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">An independent business that dispatches shipments for
                            exporters for a fee. The firm may ship by land, air, or sea, or it may specialize.
                            Usually it handles all the services connected with an export shipment, including
                            preparation of documents, booking cargo space, warehousing, pier delivery, and export
                            clearance. The firm may also handle banking and insurance services on behalf of a
                            client.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Free Of Particular Average (FPA )</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A marine insurance clause relating to the recoverability of
                            partial and total losses from perils of the sea. The American and English
                            coverage&#8217;s vary as follows:<br />
                            American Conditions (FPAAC) &#8211; The underwriter does not assume responsibility for
                            partial losses unless caused by sinking, stranding, burning, or colliding with another
                            vessel.<br />
                            English Conditions (FPAEC) &#8211; The underwriter assumes responsibility for partial
                            losses if the vessel is sunk, stranded, burned, on fire, or in collision, even though
                            such an event did not actually cause the damage suffered by the goods.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle" class="main-txttext6">
                            <span><strong>FTL</strong></span><strong></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Full Truck Load, an indication for a truck transporting
                            cargo directly from supplier to receiver.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Factory Delivery</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The delivery of goods by a factory whereby the goods are
                            put at the disposal of another (internal) party such as a commercial department.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Feeder </strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A vessel normally used for local or coastal transport (for
                            carriage of cargo and/or containers) to and from ports not scheduled to be called by the
                            main (ocean) vessel, directly connecting these ports to the main (ocean) vessel.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong
                                    class="main-txttext6">Flag</strong></span><strong class="main-txttext6"></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">An indication of the country in which a means of transport
                            is registered through a reference to the ensign of this country.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong
                                    class="main-txttext6">Flammable</strong></span><strong
                                class="main-txttext6"></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Capable to be set on fire under given circumstances.
                            (Amendment 25 IMO DGS).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Flash Point</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The lowest temperature at which a good produces enough
                            vapour to form a flammable mixture with air.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Flat Rack Container</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A container with two end walls and open sides.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle" class="orangenormal style31 style32">
                            <span><strong class="main-txttext6">Fleet</strong></span><strong
                                class="main-txttext6"></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Any group of means of transport acting together or under
                            one control.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> <span class="main-txttext6">Force
                                    Majeure</span></strong><span class="main-txttext6"> </span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Circumstance which is beyond the control of one of the
                            parties to a contract and which may, according to the terms and conditions, relieve that
                            party of liability for failing to execute the contract.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Fork Lift Truck</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A three or four wheeled mechanical truck with forks at the
                            front designed for lifting, carrying and stowing cargo.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Forty Foot Equivalent Unit</strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: FEU</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Unit of measurement equivalent to one forty foot container.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong
                                    class="main-txttext6">Forwarder</strong></span><strong
                                class="main-txttext6"></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The party arranging the carriage of goods including
                            connected services and/or associated formalities on behalf of a shipper or consignee.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> Forwarding Charge</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Charges paid or to be paid for preliminary surface or air
                            transport to the airport of departure by a forwarder, but not by a carrier under an Air
                            Waybill (air cargo).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Forwarding Instruction</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Document issued to a freight forwarder, giving instructions
                            to the forwarder for the forwarding of goods described therein.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="g" role="tabpanel" aria-labelledby="g-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Gang</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"><span>A number of workmen acting together especially for
                                loading and/or discharging operations of a vessel in combination with the necessary
                                gear. (On a vessel for instance 6 gangs can be ordered to discharge or load.)</span>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Garments On Hangers</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Clothes in containers on hangers and hung from rails
                            during transit, reducing the handling required for the garments.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Gateway</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> A point at which cargo is interchanged between carriers or
                            modes of transport
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A means of access, an entry
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>GATT</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">(General Agreement on Tariffs and Trade) &#8211; A
                            multilateral treaty intended to help reduce trade barriers and promote tariff
                            concessions.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>General Agreement on Tariffs and
                                Trade</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: GATT</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Major international agreement on trade and tariffs between
                            many nations all over the world. The discussions are now held by the WTO.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>General Average</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: G/A</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Intentional act or sacrifice which is carried out to
                            safeguard vessel and cargo. When a vessel is in danger, the master has the right to
                            sacrifice property and/or to incur reasonable expenditure. Measures taken for the sole
                            benefit of any particular interest are not considered general average.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>General Average Act (York-Antwerp
                                Rules)</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">There is a general average act when, and only when any
                            extraordinary sacrifice or expenditure is intentionally and reasonably made or incurred
                            for the common safety for the purpose of preserving from peril the property involved in
                            a common maritime adventure.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>General Cargo</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Cargo, consisting of goods, unpacked or packed, for example
                            in cartons, crates, bags or bales, often palletised. General cargo can be shipped either
                            in breakbulk or containerised</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Any consignment other than a consignment containing
                            valuable cargo and charged for transport at general cargo rates (air cargo)</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"><span class="style67"></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>General Purpose Container</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A Container with two end walls and open sides.A container
                            used for the carriage of general cargo without any special requirements for the
                            transport and or the conditioning of the goods.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Goods</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Common term indicating movable property, merchandise or
                            wares<br />
                            All materials which can be used to satisfy demands<br />
                            Whole or part of the cargo received from the shipper, including any equipment supplied
                            by the shipper</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> Goods Receipt</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Document issued by a port, warehouse, shed, or terminal
                            operator acknowledging receipt of goods specified therein on conditions stated or
                            referred to in the document.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Goods in Transit</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">he goods which have departed from the initial loading point
                            and not yet arrived at the final unloading point.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Groupage</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The collection of several small consignments and the
                            formation of one large shipment thereof (road cargo).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="main-txtdle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="main-txtdle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Gross Weight (GR WT./GW)</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="main-txtdle">&nbsp;</td>
                        <td align="left" valign="middle">The full weight of a shipment, including containers and
                            packaging materials.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="h" role="tabpanel" aria-labelledby="h-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Hague Rules</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> International convention for the unification of certain
                            rules, relating to Bills of Lading (1924). These Rules include the description of
                            responsibilities of Shipping Lines.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Hague-Visby Rules</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Set of rules, published in 1968, amending the Hague Rules.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Hamburg Rules</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">United Nations Convention on the carriage of goods by sea
                            of 1978 adopted in 1992.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Harmonized System</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: HS</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> It is a numeric multi purpose system, the international
                            convention on the HS was established under auspices of the World Customs Organisation in
                            1983, for the classification of goods with its six digits covering about 5000
                            descriptions of the products or groups of products most commonly produced and traded. It
                            is designed for customs services, but can also be used for statistics, transport
                            purposes, export, import and manufacturing.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Haulage</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> The inland carriage of cargo or containers between named
                            locations/points.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Merchant inspired Carrier Haulage or customer nominated
                            Carrier Haulage or shipper preferred Carrier Haulage service performed by a
                            sub-contractor of the merchant</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Carrier inspired Merchant Haulage means Haulage service
                            performed by a sub- contractor of the Carrier</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Haulier</strong><strong
                                class="main-txttext6"></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Road carrier.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Hi (Or High) Cube</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Any container exceeding 102 inches in height.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>House Air Waybill</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">An air waybill issued by an airfreight consolidator.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>House to House Transport</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> The transport of cargo from the premises of the consignor
                            to the premises of the consignee.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Note: In the United States the term &#8216;Point to Point
                            Transport&#8217; is used instead of the term &#8216;Door to Door Transport&#8217;,
                            because the term &#8216;house&#8217; may mean &#8216;customs house&#8217; or
                            &#8216;brokers house&#8217;, which are usually located in the port.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Hub</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> The central transhipment point in a transport structure,
                            serving a number of consignees and/or consignors by means of spokes. The stretches
                            between hubs mutually are referred to as trunks.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="i" role="tabpanel" aria-labelledby="i-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>IATA</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">International Air Transport Association.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>ICAO</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">(International Civil Aviation Organization)
                            &#8211; A specialized agency of the United Nations headquartered in Montreal . It
                            promotes general development of civil aviation such as aircraft design and operation,
                            safety procedures, and contractual agreements.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>ICC (International Chamber Of
                                Commerce)</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">A non-governmental organization serving as a
                            policy advocate on world business.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Idle Time</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> The amount of ineffective time whereby the available
                            resources are not used e.g. a container in a yard.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>IGLOO</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A contoured structural container designed for use in
                            main-deck carriage on narrow body aircraft.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Import License</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A certificate issued by countries exercising import
                            controls that permits importation of the articles stated in the license and often
                            authorizes and/or releases the funds in payment of the importation.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Inducement</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">When steamship lines publish in their schedules the name of
                            a port and the words &#8220;by inducement&#8221; in parentheses, this means the vessel
                            will call at the port if there is a sufficient amount of profitable cargo available and
                            booked.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Inland Carrier</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A transportation line which hauls export or import cargo
                            between ports and inland points.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Inspection Certificate</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A document certifying that merchandise was in good
                            condition, or in accordance with certain specifications immediately prior to shipment.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Integrated Carrier</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A forwarder that uses its own aircraft, whether owned or
                            leased, rather than scheduled airlines.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Interline</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A mutual agreement between airlines to link their route
                            network.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Intermodal</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">This refers to the capacity to go from ship to train to
                            truck or the like. The term generally refers to containerized shipping or the capacity
                            to handle containers across different modes of transport.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>In Transit</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The status of goods or persons between the
                            outwards customs clearance and inwards customs clearance.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>INCO Terms</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Trade terms in coded form as established by the
                            International Chamber of Commerce in 1953, whereafter they have been regularly updated.
                            (Last update 2000). The terms represent a set of international rules for the
                            interpretation of the principal terms of delivery used in trade contracts.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Inland Waterways Bill of
                                Lading</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Transport document made out to a named person, to order or
                            to bearer, signed by the carrier and handed to the sender after receipt of the goods.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Insurance</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> A system of protection against loss under which a party
                            agrees to pay a certain sum (premiums) for a guarantee that they will be compensated
                            under certain conditions for loss or damage.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Insurance Certificate</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Proof of an insurance contract.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Insurance Company</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The party covering the risks of the issued goods and/or
                            services that are insured.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Intermodal Transport</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> The movement of goods (containers) in one and the same
                            loading unit or vehicle which uses successively several modes of transport without
                            handling of the goods themselves in changing modes.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td height="19" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>International Air Transport
                                Association</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Abbreviation: IATA</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> An international organisation of airlines, founded in
                            1945, with the aim of promoting the commercial air traffic. Parties should achieve this
                            by co-operation between the parties concerned and by performance of certain rules,
                            procedures and tariffs, regarding both cargo and passengers.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>International Association of
                                Classification Societies</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Abbreviation: IACS</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> An organisation in which the major classification
                            societies, among others American Bureau of Shipping, Lloyd&#8217;s Register of Shipping
                            and Germanischer Lloyd, are joined, whose principal aim is the improvement of standards
                            concerning safety at sea.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle" class="orangenormal style31 style32">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>International Chamber of
                                Shipping</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Abbreviation: ICS</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> A voluntary organisation of national shipowner&#8217;
                            associations with the objective to promote interests of its members, primarily in the
                            technical and legal fields of shipping operations.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>International Maritime Dangerous Goods
                                Code</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Abbreviation: IMDG Code</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> A code, representing the classification of dangerous goods
                            as defined by the International Maritime Organisation (IMO) in compliance with
                            international legal requirements.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>International Maritime
                                Organisation</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: IMO</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> An United Nations agency concerned with safety at sea. Its
                            work includes codes and rules relating to tonnage measurement of vessels, load lines,
                            pollution and the carriage of dangerous goods.<br />
                            Its previous name was the Inter-Governmental Maritime Consultative Organisation (IMCO).
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong
                                    class="main-txttext6">Invoice</strong></span><strong class="main-txttext6"></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> An account from the supplier, for goods and/or services
                            supplied by him.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="j" role="tabpanel" aria-labelledby="j-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20"><strong>Jetsam</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Goods thrown or lost.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Jettison</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The act of intentionally throwing cargo overboard e.g. with the
                            objective of lightening a vessel, which has run aground, such for the common good of all
                            interests: vessel, crew and remaining cargo.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Jetty</strong></span><span
                                class="main-txttext6"><strong></strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A mole or breakwater, running out into the sea to protect harbours or
                            coasts. It is sometimes used as a landing-pier.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Jib</strong></span><strong><span
                                    class="main-txttext6"></span></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Projecting arm of a crane</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Attachment connected to the top of a crane boom</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Job</strong></span><strong><span
                                    class="main-txttext6"></span></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">That work which is undertaken to meet a customer or production order
                            and, for production control purposes, has a unique identification.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Joint Venture</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A joint activity of two or more companies usually performed under a
                            common name.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify" class="orangenormal style31 style32">
                            <span><strong>Journey</strong></span><strong><span class="main-txttext6"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A voyage from one place, port or country to another one, in case of a
                            round trip, to the same one.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20"><strong>Jurisprudence</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Juridical decisions used for explanation and meaning of law.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Just In Time</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: JIT</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The movement of material/goods at the necessary place at the necessary
                            time.<br />
                            The implication is that each operation is closely synchronised with the subsequent ones
                            to make that possible.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A method of inventory control that brings stock into the production
                            process, warehouse or to the customer just in time to be used, thus reducing stock
                            piling.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="k" role="tabpanel" aria-labelledby="k-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>KNOT, NAUTICAL</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">The unit of speed equivalent to one nautical
                            mile: 6,080.20 feet per hour or 1.85 kilometers per hour.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Kyoto Convention</strong><strong><span
                                    class="orangenormal style19"></span></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle" class="main-txttext">&nbsp;</td>
                        <td align="left" valign="middle">The convention for the International Customs Co-operation
                            Council held in Kyoto in 1974 for the simplification and harmonisation of national
                            customs procedures.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle" class="main-txttext">&nbsp;</td>
                        <td align="left" valign="middle" class="main-txttext"><span
                                class="orangenormal style19"><strong><span class="orangenormal"></span></strong></span>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle" class="main-txttext">&nbsp;</td>
                        <td align="left" valign="middle">On 25th of June 1999 the updated and restructured
                            International Convention on the simplification and harmonisation of Customs Procedures
                            (Kyoto Convention) was unanimously adopted by 114 customs administrations.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle" class="main-txttext">&nbsp;</td>
                        <td align="justify" class="main-txttext">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle" class="main-txttext">&nbsp;</td>
                        <td>This convention was restructured to deal with computerised controls and to ensure better
                            co- operation between customs authorities mutually and with trade in general.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="l" role="tabpanel" aria-labelledby="l-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong
                                    class="main-txttext6">Label</strong></span><strong class="main-txttext6"></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> A slip of e.g. paper or metal attached to an object to
                            indicate the nature, ownership, destination, contents and/or other particulars of the
                            object.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle" class="main-txttext6">
                            <span><strong>Lash</strong></span><strong></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> To hold goods in position by the use of, e.g., wires,
                            ropes, chains and straps.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>ShipLeasing Company</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The company from which property or equipment is taken on
                            lease.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Legal Weight</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The weight of the goods plus any immediate wrappings or
                            packagings that are sold along with the goods, e.g., the weight of a tin can as well as
                            its contents.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Less than Container Load</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Abbreviation: LCL</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> A general reference for identifying cargo in any quantity
                            intended for carriage in a container, where the Carrier is responsible for packing</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">and/or unpacking the container</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> For operational purposes a LCL (Less than full container
                            load) container is considered a container in which multiple consignments or</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"><span>parts thereof are shipped </span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Abbreviation: LTL</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> A term used if the quantity or volume of one or more
                            consignment(s) does not fill a standard truck.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Lessee</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> The party to whom the possession of specified property has
                            been conveyed for a period of time in return for rental payments.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Lessor<span
                                    class="main-txttext6"><strong></strong></span><strong></strong></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The party who conveys specified property to another for a
                            period of time in return for the receipt of rent.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Letter of Credit</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Abbreviation: L/C</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> A written undertaking by a bank (issuing bank) given to
                            the seller (beneficiary) at the request, and on the instructions of the buyer
                            (applicant) to pay at sight or at a determinable future date up to a stated sum of
                            money, within a prescribed time limit and against stipulated documents.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Letter Of Credit, Confirmed</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A letter of credit containing a guarantee on the part of
                            both the issuing and advising banks of payment to the seller, provided the
                            seller&#8217;s documentation is in order and the terms of the letter of credit are met.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Letter of Indemnity</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Written statement in which one party undertakes to
                            compensate another for the costs and consequences of carrying out a certain act. The
                            issue of a letter of indemnity is sometimes used for cases when a shipper likes
                            receiving a clean Bill of Lading while a carrier is not allowed to do so.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Liability</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Legal responsibility for the consequences of certain acts
                            or omissions.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>Lien</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> A legal claim upon real or personal property to pay a debt
                            or duty.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Lighter</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">An open or covered barge equipped with a crane and towed by
                            a tugboat. Used mostly in harbors and inland waterways.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Liner</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The word &#8220;liner&#8221; is derived from the term
                            &#8220;line traffic,&#8221; which denotes operation along definite routes on the basis
                            of definite, fixed schedules. A liner thus is a vessel that engages in this kind of
                            transportation, which usually involves the haulage of general cargo as distinct from
                            bulk cargo.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Liner Conference</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A group of two or more vessel-operating carriers, which
                            provides international liner services for the carriage of cargo on a particular trade
                            route and which has an agreement or arrangement to operate under uniform or common
                            freight rates and any other agreed conditions (e.g. FEFC = Far Eastern Freight
                            Conference).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Liner In Free Out</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: LIFO</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Transport condition denoting that the freight rate is
                            inclusive of the sea carriage and the cost of loading, the latter as per the custom of
                            the port. It excludes the cost of discharging.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Liner Terms</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Condition of carriage denoting that costs for loading and
                            unloading are borne by the carrier subject the custom of the port concerned.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Lloyd&#8217;s Register of
                                Shipping</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">British classification society.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>LO / LO (LIFT-ON/LIFT-OFF)</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Denotes the method by which cargo is loaded onto and
                            discharged from an ocean vessel, which in this case is by the use of a crane.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Load Factor</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Capacity used as against capacity available and expressed
                            as a percentage.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Logistics Management</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The efficient and cost-effective management of the physical
                            movement of goods from supply points to final sale and the associated transfer and
                            holding of such goods at various intermediate storage points.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="m" role="tabpanel" aria-labelledby="m-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Main-line Operator</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: MLO</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A carrier employing vessel(s) in the main or principal
                            routes in a trade but not participating within a consortium.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong><span class="orangenormal"><span
                                            class="main-txttext6">Manifest</span></span></strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Document, which lists the specifications of goods, loaded
                            in a means of transport or equipment for transportation purposes.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">As a rule cargo the agents in the place of loading draw up
                            manifests</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Note: For P&amp;O Nedlloyd a manifest represents a
                            cumulation of Bills of Lading for official and administrative purposes</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong><span class="orangenormal"><span
                                            class="normal1"><span class="main-txttext6">Marine Insurance
                                                Policy</span></span></span></strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">An insurance policy protecting the insured against loss or
                            damage to his goods occurred during ocean transport.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong><span
                                        class="orangenormal style31 style32"><span class="orangenormal"><span
                                                class="main-txttext6">Mate&#8217;s
                                                Receipt</span></span></span></strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A document signed by the chief officer of a vessel
                            acknowledging the receipt of a certain consignment on board of that vessel. On this
                            document, remarks can be made as to the order and condition of the consignment.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Measurement Ton</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The measurement ton (also known as the cargo ton or freight
                            ton) is a space measurement, usually 40 cubic feet or one cubic meter. Cargo is assessed
                            a certain rate for every 40 cubic feet or one cubic meter it occupies.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Mercosur</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A trade alliance between Argentina, Brazil , Paraguay and
                            Uruguay , with Chile and Bolivia as associate members.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong><span class="orangenormal"><span
                                            class="main-txttext6">Medical First Aid
                                            Guide</span></span></strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: MFAG</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Instructions to be consulted in case of accidents involving
                            dangerous goods.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong><span class="orangenormal"><span
                                            class="normal1"><span class="main-txttext6">Merchant
                                                Haulage</span></span></span></strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Inland transport of cargo in containers arranged by the
                            Merchant.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">It includes empty container-moves to and from hand-over
                            points in respect of containers released by the Carrier to Merchants.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">
                            <p align="justify"> <strong>Note:</strong> Carrier&#8217;s responsibility under the Bill
                                of Lading does not include the inland transport stretch under Merchant Haulage.</p>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span class="main-txttext6"><strong>Multimodal
                                    Transport</strong></span><span class="normal1"><strong><span
                                        class="orangenormal style31 style32"><span class="orangenormal"><span
                                                class="orangebold"></span></span></span></strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The carriage of goods (containers) by at least two
                            different modes of transport.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong><span class="orangenormal"><span
                                            class="main-txttext6">Multimodal Transport
                                            Document</span></span></strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Negotiable or non-negotiable document evidencing a contract
                            for the performance and/or procurement of performance of combined transport of goods.
                            <span class="normal1 style21"> </span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Thus a combined transport document is a document issued by
                            a Carrier who contracts as a principal with the Merchant to effect a combined transport
                            often on a door-to-door basis.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong><span class="orangenormal"><span
                                            class="normal1"><span class="orangebold">Multimodal Transport
                                                Operator/Carrier</span></span></span></strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: MTO/Carrier</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The person on whose behalf the transport document or any
                            document evidencing a contract of multimodal carriage of goods is issued and who is
                            responsible for the carriage of goods pursuant to the contract of carriage.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="n" role="tabpanel" aria-labelledby="n-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>NAFTA</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">(North American Free Trade Agreement) &#8211; A
                            free trade agreement comprising the U.S.A. , Canada , and Mexico .</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>National Carrier</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">A flag carrier owned or controlled by the
                            state.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Net Terms</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">Free of charters&#8217; commission.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Net Weight (Actual Net Weight)</strong>
                        </td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">The weight of the goods alone without any
                            immediate wrappings; e.g., the weight of the contents of a tin can without the weight of
                            the can.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Non Vessel Operating Common
                                Carrier</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: NVOCC</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A party who undertakes to carry goods and issues in his own
                            name a Bill of Lading for such carriage, without having the availability of any own
                            means of transport.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> Notify Address</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Address of the party other than the consignee to be advised
                            of the arrival of the goods.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> Notify Party</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The party to be notified of arrival of goods.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="o" role="tabpanel" aria-labelledby="o-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>OD</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">Outside Diameter.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Open Account</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">A trade arrangement in which goods are shipped
                            to a foreign buyer without guarantee of payment such as a note, L/C, or other formal
                            written evidence of indebtedness.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Open Policy</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">A cargo insurance policy that is an open
                            contract; e.g., it provides protection for all shipments in transit within a specified
                            geographic trade area for a limited period of time. It is referred to as
                            &#8220;open&#8221; because it does not require reporting of individual shipments.
                            Summary or grouped reporting requirements vary with different policies.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="left" valign="middle">
                            <span><strong>Oncarriage</strong></span><strong><span class="main-txttext6"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The carriage of goods (containers) by any mode of transport
                            to the place of delivery after discharge from the ocean vessel (main means of transport)
                            at the port (place) of discharge.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>One Stop Shop</strong></span>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">An organisation, which provides all needed
                            requirements in one location.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>Open Top
                                    Container</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A freight container similar in all respects to a general
                            purpose container except that it has no rigid roof but may have a flexible and movable
                            or removable cover, for example one made of canvas or plastic or reinforced plastic
                            material normally supported on movable or removable roof bows.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>O/R</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Owner&#8217;s Risk.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Out of Gauge Cargo</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Cargo which dimensions are exceeding the normal dimensions
                            of a 20 or 40 feet container, e.g. overlength, overwidth, overheight, or combinations
                            thereof.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>Outturn Report</strong></span>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Written statement by a stevedoring company
                            in which the condition of cargo discharged from a vessel is noted along with any
                            discrepancies in the quantity compared with the vessel&#8217;s manifest.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>Overheight Cargo</strong></span>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Cargo, exceeding the standard height.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Overlength Cargo</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Cargo, exceeding the standard length.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span class="main"><strong>Overwidth
                                    Cargo</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Cargo, exceeding the standard width.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>Owner</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The legal owner of cargo, equipment or means
                            of transport.
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="p" role="tabpanel" aria-labelledby="p-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Part Charter </strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">Where part of an airline&#8217;s scheduled
                            flight is sold as if it were a charter in its own right. Often incorrectly used as a
                            synonym for split charter.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Part Load Charter</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">Where a part of an aircraft&#8217;s load is
                            discharged at one destination and a part of it at another. This is distinct from a split
                            charter where a number of consignments are carried to the same destination. Inbound,
                            part loads are treated as single entity charters under the regulations in most
                            countries.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Particular Average (PA)</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">Partial loss or damage to goods.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Perils Of The Sea</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">Fortuitous accidents or casualties peculiar to
                            transportation on navigable water, such as sinking, collision of vessel, striking a
                            submerged object, or encountering heavy weather or other unusual forces of nature.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Perishables</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">Any cargo that loses considerable value if it
                            is delayed in transportation. This usually refers to fresh fruit and vegetables.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Phytosanitary Inspection Certificate
                            </strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">A certificate issued by an exporting
                            countries&#8217; Department of Agriculture indicating that a shipment has been inspected
                            and is free of harmful pests and plant diseases.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Pilferage </strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">As used in marine insurance policies, the term
                            denotes petty thievery-the taking of small parts of a shipment-as opposed to the theft
                            of a whole shipment or large unit. Many ordinary marine insurance policies do not cover
                            against pilferage, and when this coverage is desired it must be added to the policy.
                        </td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Port Marks</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">An identifying set of letters, numbers, or
                            geometric symbols followed by the name of the port of destination that are placed on
                            export shipments. Foreign government requirements may be exceedingly strict in the
                            matter of port marks.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Port Of Discharge</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">A port where a vessel is off-loaded and cargo
                            discharged.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Port Of Entry</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">A port at which foreign goods are admitted into
                            the receiving country.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Port Of Loading</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">A port where cargo is loaded aboard the vessel,
                            lashed, and stowed.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Prepaid Freight</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">Generally speaking, freight charges both in
                            ocean and air transport may be either prepaid in the currency of the country of export
                            or they may be billed collect for payment by the consignee in his local currency. On
                            shipments to some countries, however, freight charges must be prepaid because of foreign
                            exchange regulations of the country of import or rules of steamship companies or
                            airlines.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Prima Facie</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">A Latin term frequently encountered in foreign
                            trade that means &#8220;on first appearance.&#8221; When a steamship company issues a
                            clean bill of lading, it acknowledges that the goods were received &#8220;in apparent
                            good order and condition&#8221; and this is said by the courts to constitute prima facie
                            evidence of the conditions of the containers; that is, if nothing to the contrary
                            appears, it must be inferred that the cargo was in good condition when received by the
                            carrier.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>P &amp; I Club</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A mutual association of shipowners who provide protection
                            against liabilities by means of contributions.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Any physical piece of cargo in relation to transport
                            consisting of the contents and its packing for the purpose of ease of handling by manual
                            or mechanical means</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The final product of the packing operation consisting of
                            the packing and its contents to facilitate manual or mechanical handling</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>Packaging</strong></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Materials used for the containment, protection, handling,
                            delivery and presentation of goods and the activities of placing and securing goods in
                            those materials.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>Packing
                                    Instruction</strong></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Document issued within an enterprise giving instructions on
                            how goods are to be packed.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>Packing List</strong></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Document specifying the contents of each individual
                            package.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Pallet</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A platform on which goods can be stacked in order to
                            facilitate the movement by a fork lift or sling.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Panamax Size</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The maximum measurements and dimensions of a vessel capable
                            to pass the Panama Canal.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle">
                            <span><strong>Payload</strong></span><strong><span class="main-txttext6"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The revenue-producing load carried by a means of transport.
                        </td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Payment Against Documents</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Instructions given by a seller to a bank to the effect that
                            the buyer may collect the documents necessary to obtain delivery of the goods only upon
                            actual payment of the invoice.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Physical Distribution</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Those activities related to the flow of goods from the end
                            of conversion to the customer.&nbsp;
                        </td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>Pier</strong></span><strong><span
                                    class="main-txttext6"></span></strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">That part of a wharf which is intended for the mooring of
                            vessels.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Pilferage</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Petty stealing of goods from a ship&#8217;s hold, cargo
                            shed or warehouse.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Place of Acceptance</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The location where a consignment (shipment) is received by
                            the carrier from the shipper viz. the place where the carrier&#8217;s liability for
                            transport venture commences.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Place of Delivery</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The location where a consignment (shipment) is delivered to
                            the consignee viz. the place where the carrier&#8217;s liability ends for the transport
                            venture.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Place of Despatch</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Name and address specifying where goods are collected or
                            taken over by the carrier (i.e. if other than consignor).</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Place of Receipt</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The location where a consignment (shipment) is received by
                            the carrier from the shipper viz. the place where the carrier&#8217;s liability for
                            transport venture commences.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Port of Call</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Place where a vessel actually drops anchor or moors during
                            a certain voyage.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Port of Discharge</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The port where the cargo is actually loaded on board the
                            sea (ocean) going vessel.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle">
                            <span><strong>Precarriage</strong></span><strong><span
                                    class="main-txttext6"></span></strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The carriage of goods (containers) by any mode of transport
                            from the place of receipt to the port (place) of loading into the ocean vessel (main
                            means of transport).</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Precarrier</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The carrier by which the goods are moved prior to the main
                            transport.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Preshipment Inspection</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: PSI</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The checking of goods before shipment for the purpose of
                            determining the quantity and/or quality of said goods by an independent surveyor
                            (inspection company) for phytosanitary, sanitary and veterinary controls.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Presently there is a tendency by developing countries to
                            use the inspection also for the purpose of determining whether the price charged for
                            certain goods is correct.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle">
                            <span><strong>Principal</strong></span><strong><span class="main-txttext6"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Person for whom another acts as agent.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Pro Forma Invoice</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Draft invoice sent to an importer by the exporter prior to
                            order confirmation and shipment to assist in matters relating to obtaining import
                            licences or foreign exchange allocations, or simply to advise the value of a consignment
                            so that letters of credit can be opened.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Project Cargo</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Quantity of goods connected to the same project and often
                            carried on different moments and from various places.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Proof of Delivery</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The receipt signed by the consignee upon delivery.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> Proper Shipping Name</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A name to be used to describe particular goods on all
                            documents and notifications and, if appropriate, on the goods. basis (air cargo).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"><span class="style34"></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> Protection and Indemnity Club</strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: P &amp; I club</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A mutual association of shipowners who provide protection
                            against liabilities by means of contributions</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="q" role="tabpanel" aria-labelledby="q-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Quarantine</strong></span><strong><span
                                    class="main-txttext6"></span></strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The period during which an arriving
                            vessel, including its equipment, cargo, crew or passengers, suspected to carry
                            or carrying a contagious disease is detained in strict isolation to prevent the
                            spread of such a disease.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Quay</strong></span><span
                                class="main-txttext6"><strong></strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>That part of a wharf which is intended for
                            the mooring of vessels.
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="r" role="tabpanel" aria-labelledby="r-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Rate</strong></span><strong><span
                                    class="orangenormal style19"> </span></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"><span>The price of a transport service</span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Quantity, amount or degree measured or applied</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Rebate</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">That part of a transport charge which the carrier agrees to return.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Receipt</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A written acknowledgement, that something has been received.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Reefer Cargo</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Cargo requiring temperature control.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Reefer Container</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A thermal container with refrigerating appliances (mechanical compressor
                            unit, absorption unit etc.) to control the temperature of cargo.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Regroupage</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The process of splitting up shipments into various consignments
                            (degroupage) and combining these small consignments into other shipments (groupage).
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Release Order</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A document issued by or on behalf of the carrier authorising the release
                            of import cargo identified thereon and manifested under a single Bill of Lading.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="justify"><span><strong>Roll-on Roll-off</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify"><span> Abbreviation: RoRo<br />
                                System of loading and discharging a vessel whereby the cargo is driven on and off by
                                means of a ramp.</span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Route</strong></span><span
                                class="main-txttext6"><strong></strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The track along which goods are (to be) transported.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Routing</strong></span><span
                                class="main-txttext6"><strong></strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify" height="24">The determination of the most efficient route(s) that
                            people, goods, materials and or means of transport have to follow</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The process of determining how a shipment will be moved between
                            consignor and consignee or between place of acceptance by the carrier and place of
                            delivery to the consignee</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The process of aiding a vessel&#8217;s navigation by supplying long
                            range weather forecasts and indicating the most economic and save sailing route.</td>
                    </tr>
                </tbody>
            </table>

        </div>
        <div class="tab-pane fade" id="s" role="tabpanel" aria-labelledby="s-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span class="main-txttext6"><strong>Said to
                                    Contain</strong></span><strong><span class="orangenormal style19"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: STC</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Term in a Bill of Lading signifying that the master and the
                            carrier are unaware of the nature or quantity of the contents of e.g. a carton, crate,
                            container or bundle and are relying on the description furnished by the shipper.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>Salvage</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The saving or rescue of a vessel and/or the cargo from loss
                            and/or damage at sea.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>Schedule</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A timetable including arrival/departure times of ocean- and
                            feeder vessels and also inland transportation. It refers to named ports in a specific
                            voyage (journey) within a certain trade indicating the voyage number(s). In general: The
                            plan of times for starting and/or finishing activities.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>Seal</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A device used for containers, lockers, trucks or lorries to
                            proof relevant parties that they have remained closed during transport.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Seaworthiness</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Fitness of a vessel to travel in open sea mostly related to
                            a particular voyage with a particular cargo.<br />
                            Seller<br />
                            Party selling merchandise to a buyer.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle">
                            <span><strong>Sender</strong></span><strong><span class="main-txttext6">
                                </span></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A service Bill (of Lading) is a contract of carriage issued
                            by one carrier to another for documentary and internal control purposes</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">For internal documentary and control purposes a so-called
                            participating agent in a consortium uses some kind of document which, depending on the
                            trade, is referred to as &#8216;Memo Bill&#8217; which will among others state:</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Name of Carrier on whose behalf the original document (Way
                            Bill, Bill of Lading, etc.) was issued</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The original document number. The agent who issued the
                            original document and his opponent at the discharging side</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The number of packages, weight and measurement, marks and
                            numbers and goods description</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Further mandatory details in case of special cargo</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">No freight details will be mentioned and the Memo Bill is
                            not a contract of carriage.<br />
                            Acts as intermediary between shipowners or carriers by sea on the one hand and cargo
                            interests on the other. The functions are to act as forwarding agent or custom broker,
                            fixing of charters, and acting as chartering agent.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Ship Operator</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A ship operator is either the shipowner or the (legal)
                            person responsible for the actual management of the vessel and its crew.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Ship&#8217;s Protest</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Statement of the master of a vessel before (in the presence
                            of) competent authorities, concerning exceptional events which occurred during a voyage.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle">
                            <span><strong>Shipment</strong></span><strong><span class="main-txttext6"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A separately identifiable collection of goods to be
                            carried.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"><strong> <span
                                    class="orangenormal style19">Note:</span></strong>
                            <span class="style21"> </span>In
                            the United States of America the word shipment is used instead of the word consignment.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The (legal) person officially registered as such in the
                            certificate of registry where the following particulars are contained:</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Name of vessel and port of registry</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Details contained in surveyors certificate</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The particulars respecting the origin stated in the
                            declaration of ownership</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The name and description of the registered owner, if more
                            than one owner the proportionate share of each</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle">
                            <span><strong>Shipper</strong></span><strong><span class="main-txttext6"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The merchant (person) by whom, in whose name or on whose
                            behalf a contract of carriage of goods has been concluded with a carrier or any party by
                            whom, in whose name or on whose behalf the goods are actually delivered to the carrier
                            in relation to the contract of carriage.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Shipper&#8217;s Export
                                Declaration</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: SED<br />
                            A United States customs form to be completed for all exports to assist the government in
                            compiling export statistics.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Shipper&#8217;s Letter of
                                Instruction</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: SLI<br />
                            A document containing instructions given by the shipper or the shipper&#8217;s agent for
                            preparing documents and forwarding (air cargo).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Shipping Note</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Document provided by the shipper or his agent to the
                            carrier, multimodal transport operator, terminal or other receiving authority, giving
                            information about export consignments offered for transport, and providing for the
                            necessary receipts and declarations of liability.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Shipping Documents</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Documents required for the carriage of goods.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Shipping Instruction</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Document advising details of cargo and exporter&#8217;s
                            requirements of its physical movement.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Shipping Label</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A label attached to a unit, containing certain data.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Shipping Marks</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The identification shown on individual packages in order to
                            help in moving it without delay or confusion to its final destination and to enable the
                            checking of cargo against documents.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Shortage</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The negative difference between actual available or
                            delivered quantity and the required quantity.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Shrink Wrapping</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Heat treatment that shrinks an envelope of polyethylene or
                            similar substance around several units, thus forming one unit. It is used e.g. to secure
                            packages on a pallet.<br />
                            Go to top<br />
                            Slot<br />
                            The space on board a vessel, required by one TEU, mainly used for administrative
                            purposes.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Slot Charter</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A voyage charter whereby the shipowner agrees to place a
                            certain number of container slots (TEU and/or FEU) at the charterer&#8217;s disposal.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Special Drawing Rights</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: SDR<br />
                            Unit of account from the International Monetary Fund (IMF), i.a. used to express the
                            amount of the limitations of a carrier&#8217;s liability.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Special Rate</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A rate other than a normal rate.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> Stability</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The capacity of a vessel to return to its original position
                            after having been displaced by external forces. The stability of a vessel depends on the
                            meta-centric height.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle">
                            <span><strong>Stack</strong></span><strong><span class="main-txttext6"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">An identifiable amount of containers stowed in a orderly
                            way in one specified place on an (ocean) terminal, container freight station, container
                            yard or depot.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>STEAMSHIP AGENT</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A duly appointed and authorized representative in a
                            specified territory acting on behalf of a steamship line or lines and attending to all
                            matters relating to the vessels owned by his principals.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>STRIKES, RIOTS AND CIVIL COMMOTION&#8217;S</strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">An insurance clause referring to loss or damage directly
                            caused by strikers, locked-out workmen, persons&#8217; participation in labor
                            disturbances, and riots of various kinds. The ordinary marine insurance policy does not
                            cover this risk. Coverage against it can be added only by endorsement.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle">
                            <span><strong>Storage</strong></span><strong><span class="main-txttext6"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The activity of placing goods into a store or the state of
                            being in store (e.g. a warehouse).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> Storage Charge</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The fee for keeping goods in a warehouse.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> <span>Stowage</span><span
                                    class="main-txttext6"></span></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The placing and securing of cargo or containers on board a
                            vessel or an aircraft or of cargo in a container.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> Stowage Factor</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Ratio of a cargo&#8217;s cubic measurement to its weight,
                            expressed in cubic feet to the ton or cubic metres to the tonne, used in order to
                            determine the total quantity of cargo which can be loaded in a certain space.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> Stowage Instructions</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Imperative details about the way certain cargo is to be
                            stowed, given by the shipper or his agent.<br />
                            Go to top<br />
                            Stowage Plan<br />
                            A plan indicating the locations on the vessel of all the consignments for the benefit of
                            stevedores and vessel&#8217;s officers.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> Stripping</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The unloading of cargo out of a container.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Sue &amp; Labor Cause</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A provision in marine insurance obligating the assured to
                            do things necessary after a loss to prevent further loss and to act in the best
                            interests of the insurer.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> Stuffing</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The loading of cargo into a container.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"><span class="style33"></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> Supply Chain</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">A sequence of events in a goods flow which adds
                            to the value of a specific good. These events may include:</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Conversion</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Assembling and/or disassembling</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> Movements and placements</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"><span class="style33"></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> Supply Vessel</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Vessel which carries stock and stores to offshore drilling
                            rigs, platforms.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Surcharge</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">An additional charge added to the usual or customary
                            freight.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"><span class="style33"></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Survey<span
                                    class="main-txttext6"></span></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">An inspection of a certain item or object by a recognised
                            specialist.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"><span class="style33"></span></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong> Surveyor</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A specialist who carries out surveys.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"><strong> <span
                                    class="orangenormal style19">Note:</span></strong><span class="style21">
                            </span>A surveyor is often representing a classification bureau or a governmental body.
                        </td>
                    </tr>
                </tbody>
            </table>

        </div>
        <div class="tab-pane fade" id="t" role="tabpanel" aria-labelledby="t-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Tallyman / Clerk</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"> person who records the number of cargo items together with
                            the condition thereof at the time it is loaded into or discharged from a vessel.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>Tank Container</strong></span>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A tank, surrounded by a framework with the overall
                            dimensions of a container for the transport of liquids or gasses in bulk.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>Tanker</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A vessel designed for the carriage of liquid cargo in bulk.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>Tare Weight of
                                    Container</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Mass of an empty container including all fittings and
                            appliances associated with that particular type of container on its normal operating
                            condition.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle">
                            <span><strong>Tariff</strong></span><strong><span class="main-txttext6"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The schedule of rates, charges and related transport
                            conditions.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Temperature Controlled Cargo</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Any cargo requiring carriage under controlled temperature.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Terminal</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A location on either end of a transportation line including
                            servicing and handling facilities.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Terms of Delivery</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">All the conditions agreed upon between trading partners
                            regarding the delivery of goods and the related services.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"><strong><span
                                    class="orangenormal style19">Note:</span></strong>
                            <span class="normal1 style21"> </span>
                            Under normal circumstances the INCO terms are used to prevent any
                            misunderstandings.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Terms of Freight</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">All the conditions agreed upon between a carrier and a
                            merchant about the type of freight and charges due to the carrier and whether these are
                            prepaid or are to be collected.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"><strong><span
                                    class="orangenormal style19">Note:</span></strong>
                            The so-called Combi terms based on
                            the INCO terms do make a distinction what of the freight and related costs is to be paid
                            by the seller and what by the buyer. In the UN recommendation 23 a coding system is
                            recommended to recognise the various items.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>THC (Terminal Handling Charge)</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A charge for handling services performed at terminals.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Time Draft</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A draft that matures in a certain number of days, either
                            from acceptance or the date of the draft.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Ton</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Freight rates for liner cargo generally are quoted on the
                            basis of a certain rate per ton, depending on the nature of the commodity. This ton,
                            however, may be a weight ton or a measurement ton.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Ton-deadweight</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The carrying capacity of the ship in terms of the weight in
                            tons of the cargo, fuel, provisions, and passengers which a vessel can carry.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><span><strong>Tonnage</strong></span><strong></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Cubic capacity of a merchant vessel</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Total weight or amount of cargo expressed in tons</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Tracking</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">A system of recording movement intervals of
                            shipments from origin to destination.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle">
                            <span><strong>Tracing</strong></span><strong><span class="main-txttext6"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The action of retrieving information concerning the
                            whereabouts of cargo, cargo items, consignments or equipment.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Track &amp; Trace</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The pro-active tracking of the product along the supply
                            chain, and the paper information flow relating to the order.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Tracking</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The function of maintaining status information, including
                            current location, of cargo, cargo items, consignments or containers either full or
                            empty.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle">
                            <span><strong>Trailer</strong></span><strong><span class="main-txttext6"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A vehicle without motive power, designed for the carriage
                            of cargo and to be towed by a motor vehicle.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Trailer on Flat Car</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Abbreviation: TOFC<br />
                            Carriage of piggyback highway trailers on specially equipped railway wagons.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Tramp Vessel</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A vessel not operating under a regular schedule.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Transhipment</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A shipment under one Bill of Lading, whereby sea (ocean)
                            transport is &#8216;broken&#8217; into two or more parts. The port where the sea (ocean)
                            transport is &#8216;broken&#8217; is the transhipment port</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Transfer of cargo from one means of transport to another
                            for on-carriage during the course of one transport operation</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Customs: Customs procedure under which goods are
                            transferred under customs control from the importing means of transport to the exporting
                            means of transport within the area of one customs office which is the office of both
                            importation and exportation</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Transit Cargo</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Cargo between outwards customs clearance and inwards
                            customs clearance<br />
                            Cargo arriving at a point and departing there-from by the same through flight (air
                            cargo)</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle">
                            <span><strong>Transport</strong></span><strong><span class="main-txttext6"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The assisted movement of people and or goods.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"><strong><span class="orangenormal style19">Note:</span>
                            </strong>Transport is often used as a generic term for various means of transport, and
                            is distinguished from &#8216;movement&#8217; in that it requires such means.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Transport Document</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Document evidencing a contract of carriage between a
                            shipowner and a consignor, such as bill of lading, seawaybill or a multimodal transport
                            document. (IMO)<br />
                            See Shipping DocumentTwenty Foot Equivalent Unit<br />
                            Abbreviation: TEU<br />
                            Unit of measurement equivalent to one twenty foot container.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>TEU</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A twenty-foot equivalent unit (6.1m). A standard unit for
                            counting containers of various lengths and for describing container ship or terminal
                            capacity. A standard 40&#8242; container (FEU) equals 2 TEUs.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Type of Cargo</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">An indication of the sort of cargo to be transported, (e.g.
                            Break Bulk, Containerised, RoRo).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Type of Movement</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Description of the service for movement of containers.&nbsp;
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle"><strong><span
                                    class="orangenormal style19">Note:</span></strong>The following
                            type of movement can be indicated on B/L and Manifest all combinations of FCL and LCL
                            and break bulk and RoRo. Whilst only on the manifest combinations of House, Yard and CFS
                            can be mentioned.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Type of Packing</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Description of the packaging material used to wrap, contain
                            and protect goods to be transported.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="u" role="tabpanel" aria-labelledby="u-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="justify"><span class="main-txttext6"><strong>Ultimate
                                    Consignee</strong></span><strong><span class="orangenormal style19"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Party who has been designated on the invoice
                            or packing list as the final recipient of the stated merchandise.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Unaccompanied Baggage</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Luggage not accompanied by a passenger.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Unit Load</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A number of individual packages bonded,
                            palletised or strapped together to form a single unit for more efficient handling by
                            mechanical equipment.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>United Nations Conference on Trade and
                                    Development</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: UNCTAD<br />
                            A United Nations agency whose work in Shipping includes the liner code involving the
                            sharing of cargoes between the Shipping lines of the importing and exporting countries
                            and third countries in the ratio 40:40:20.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>United Nations Dangerous Goods Number</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: UNDG Number<br />
                            The four-digit number assigned by the United Nations Committee of Experts on the
                            Transport of Dangerous Goods to classify a substance or a particular groups of
                            substances.&nbsp;
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify" class="style8"><strong>Note:</strong> The prefix &#8216;UN&#8217; must
                            always be used in conjunction with these numbers.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="v" role="tabpanel" aria-labelledby="v-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="justify"><strong>Valuable Cargo</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="top">A consignment which contains one or more valuable articles.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Value Added Tax</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: VAT<br />
                            A form of indirect sales tax paid on products and services at each stage of production
                            or distribution, based on the value added at that stage and included in the cost to the
                            ultimate customer.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span class="main-txttext6"><strong>Vanning</strong></span><span
                                class="orangenormal style19"><strong> </strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>Buyer.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Vendor</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>Seller.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Very Large Crude Carrier</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="top">Abbreviation: VLCC<br />
                            A vessel designed for the carriage of liquid cargo in bulk with a loading capacity from
                            50.000 till 250.000 DWT.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Vessel</strong></span><strong><span
                                    class="main-txttext6"></span></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A floating structure designed for the transport of cargo and/or
                            passengers</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Boiler, drum</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Volume</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Size or measure of anything in three dimensions.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Volume Charge</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A charge for carriage of goods based on their volume (air cargo).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Voyage</strong></span><strong><span
                                    class="main-txttext6"></span></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A journey by sea from one port or country to another one or, in case of
                            a round trip, to the same port.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Voyage Charter</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A contract under which the shipowner agrees to carry an agreed quantity
                            of cargo from a specified port or ports to another port or ports for a remuneration
                            called freight, which is calculated according to the quantity of cargo loaded, or
                            sometimes at a lumpsum freight.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Voyage Number</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>Reference number assigned by the carrier or his agent to the voyage of the vessel.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="w" role="tabpanel" aria-labelledby="w-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>War Risk Insurance</strong></td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">Insurance issued by marine underwriters against
                            war-like operations specifically described in the policy. In former times, war risk
                            insurance was taken out only in times of war, but currently many exporters cover most of
                            their shipments with war risk insurance as a protection against losses from derelict
                            torpedoes and floating mines placed during former wars, and also as a safeguard against
                            unforeseen warlike developments. In the U.S.A. , war risk insurance is written in a
                            separate policy from the ordinary marine insurance; it is desirable to take out both
                            policies with the same underwriter in order to avoid the ill effects of a possible
                            dispute between underwriters as to the cause (marine peril or war peril) of a given
                            loss.</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                        <td height="20" align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><span><strong>Warehousing</strong></span><span
                                class="main-txttext6"><strong></strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Those activities of holding and handling goods in a
                            warehouse (store).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Warehouse-to-warehouse</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A clause in marine insurance policy whereby the underwriter
                            agrees to cover the goods while in transit between the initial point of shipment and the
                            point of destination with certain limitations, and also subject to the law of insurable
                            interest. The warehouse-to-warehouse clause was once extremely important, but marine
                            extension clauses now often override its provisions.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Warsaw Convention</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The Convention for the Unification of Certain Rules
                            Relating to International Carriage by Air, signed at Warsaw, 12 October 1929, or that
                            Convention as amended by the Hague Protocol, 1955, stipulating obligations or parties
                            and limitations and/or exonerations of carriers (air cargo).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle">
                            <span><strong>Waybill</strong></span><strong><span class="main-txttext6"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Non-negotiable document evidencing the contract for the
                            transport of cargo.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Weight Charge</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The charge for carriage of goods based on their weight (air
                            cargo).</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>Weight Load Factor</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">Payload achieved as against available capacity, expressed
                            as a percentage. Cargo is frequently limited by volume rather than weight; load factors
                            of 100 percent are rarely achieved.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle">
                            <span><strong>Wharf</strong></span><strong><span class="main-txttext6"></span></strong>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">A place for berthing vessels to facilitate loading and
                            discharging of cargo.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="left" valign="middle"><strong>Wharfage</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="left" valign="middle">The fee charged for the use of a wharf for mooring, loading
                            or discharging a vessel or for storing goods.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="main-txtdle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="main-txtdle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>With Average (WA)</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="main-txtdle">&nbsp;</td>
                        <td align="left" valign="middle">A marine insurance term meaning that shipment is protected
                            for partial damage whenever the damage exceeds a stated percentage.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="main-txtdle">&nbsp;</td>
                        <td align="left" valign="middle">&nbsp;</td>
                    </tr>
                    <tr>
                        <td align="left" valign="main-txtdle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td align="left" valign="middle"><strong>With Particular Average (WPA)</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="main-txtdle">&nbsp;</td>
                        <td align="left" valign="middle">An insurance term meaning that partial loss or damage of
                            goods is insured. The damage generally must be caused by sea water, and many terms
                            specify a minimum percentage of damage before payment. It may be extended to cover loss
                            by theft, pilferage, leakage and breakage, or other perils depending on the nature of
                            the cargo.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="x" role="tabpanel" aria-labelledby="x-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="justify"><strong>X-ray</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">High frequency electromagnetic ray of short
                            wave-length, capable of penetrating most solid substances.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>X.25</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">International standard of the CCITT for packet
                            switching.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>X.400</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A CCITT recommendation designed to facilitate
                            international message and information exchange between subscribers of computer based
                            store-and-forward services and office information systems in association with public
                            and private data networks.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>X.500</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The CCITT now ITU recommendations (ISO9594) for the structure of
                            directories for the maintenance of addresses used in electronic mail.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span
                                class="main-txttext6"><strong>XML</strong></span><strong><span
                                    class="orangenormal style19"></span></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Extensible mark-up language is an official recommendation by the World
                            Wide Web Consortium as a successor of HTML (Hyper Text Mark-up language) it can be used
                            to convey documents layout and contents from one computer application to another. XML is
                            a subset of SGML.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>XML / EDI</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>The exchange of structured information over the Internet using XML as the syntax.</td>
                    </tr>
                </tbody>
            </table>

        </div>
        <div class="tab-pane fade" id="y" role="tabpanel" aria-labelledby="y-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Yard</strong></span><strong><span
                                    class="main-txttext6"></span></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Fenced off, outdoor storage and repair area.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Yaw</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Variation of the course of a ship to port or
                            starboard caused by the action of waves or wind.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Yawl</strong></span><span
                                class="main-txttext6"><strong></strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A vessel&#8217;s small boat moved by one oar<br />
                            A small sailboat rigged fore-and-aft, with a short mizzenmast astern of the cockpit
                            &#8211; distinguished from ketch
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Yield Bucket</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The remaining slot capacity for a trade/voyage in a certain port of
                            loading after deduction of the allowance for specific contracts.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>Yield Management</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The process of maximising the contribution of every slot, vessel, trade
                            and network. Basically it should be seen as the process of allocating the right type of
                            capacity to the right kind of customer at the right price as to maximise revenue or
                            yield. The concept should be used in combination with load factor management.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><strong>York &#8211; Antwerp Rules</strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td>There is a general average act when, and only when any extraordinary sacrifice or
                            expenditure is intentionally and reasonably made or incurred for the common safety for
                            the purpose of preserving from peril the property involved in a common maritime
                            adventure.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="z" role="tabpanel" aria-labelledby="z-tab">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td width="16" height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg"
                                alt="list" class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Zodiac</strong></span><strong><span
                                    class="main-txttext6"></span></strong></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">A rubber dinghy. An inflatable craft for the
                            transport of people.<br />
                            Zone Area, belt or district extending about a certain point defined for transport
                            and/or charge purpose.
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span class="main-txttext6"><strong>Zone Haulage
                                    Rate</strong></span><span class="orangenormal style19"><strong></strong></span>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">The rate for which the carrier will undertake the haulage of goods or
                            containers between either the place of delivery and the carrier&#8217;s appropriate
                            terminal. Such haulage will be undertaken only subject to the terms and conditions of
                            the tariff and of the carrier&#8217;s Combined Transport Bill of Lading.</td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">&nbsp;</td>
                    </tr>
                    <tr>
                        <td height="20" align="left" valign="middle"><img src="img/icons/list-icon.svg" alt="list"
                                class="list-icon"></td>
                        <td height="20" align="justify"><span><strong>Zone Improvement Plan</strong></span></td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle">&nbsp;</td>
                        <td align="justify">Abbreviation: ZIP<br />
                            System to simplify sorting and delivery of mail, consisting of a number of five
                            digits (the so-called ZIP-code) for identification of the state, city or district,
                            and the postal zone in the U.S.A. delivery areas.
                        </td>
                    </tr>
                </tbody>
            </table>

        </div>
    </div>
    </div>
</section>

<section class="p-0 mb-n10 bg-transparent cta-overlay mt-1">
    <div class="row">
        <div class="col-lg-1 col-xl-3">
        </div>
        <div class="col-lg-11 col-xl-9">
            <div class="px-1-9 px-sm-6 px-lg-9 py-5 py-sm-8 z-index-3 bg-primary contact-block half-border-radius">
                <div class="row align-items-center position-relative z-index-3">
                    <div class="col-lg-7 col-xxl-7 mb-lg-0">
                        <h3 class="text-white mb-0">Let's make your supply chain easy
                        </h3>
                    </div>
                    <div class="col-lg-5 col-xxl-5 mt-3 text-lg-end">
                        <h5 class="text-white mb-3">If you have any questions.</h5>
                        <a href="contact.php" class="butn transparent"><span>Get In Touch</span></a>
                    </div>
                </div>
                <img src="img/bg/bg-03.png" class="position-absolute top-0 left-n5" alt="...">
            </div>
        </div>
    </div>
</section>
<div class="footer-light footer-new">
    <div class="ftr-bg">
        <div class="footer-top">
            <div class="container">
                <div class="row">

                    <div class="col-lg-4 col-md-12">

                        <div class="widget widget_about">
                            <div>
                                <h3 class="widget-title">Interport Global Logistics</h3>
                            </div>
                            <p>Today, IGL has established offices in major cities and ports in India with
                                warehousing facilities and transport equipment to handle any cargo
                                independently. The company also has access to major international ports through
                                its branch offices.</p>
                            <ul class="social-icon-style1 mb-0">

                                <li>
                                    <a target="_blank" href="https://www.linkedin.com/company/1897064"><i
                                            class="fab fa-linkedin-in"></i></a>
                                </li>

                            </ul>
                        </div>

                    </div>

                    <div class="col-lg-2 col-md-6 col-6">
                        <div class="widget widget_services ftr-list-center">
                            <h3 class="widget-title">Contact Us</h3>
                            <ul>
                                <li><a href="contact.php">Contact</a></li>
                                <li><a href="enquiry-form.php">Enquiry Form</a></li>
                                <li><a href="feedback-form.php">Feedback Form</a></li>
                                <li><a href="air-shipment.php">Air Shipment Bookings</a></li>
                                <li><a href="sea-shipment.php">Sea Shipment Bookings</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6 col-6">
                        <div class="widget widget_services ftr-list-center">
                            <h3 class="widget-title">Important Links</h3>
                            <ul>
                                <li><a href="about.php">About</a></li>
                                <li><a href="careers.php">Careers</a></li>
                                <li><a href="terms-and-conditions.php">Terms & Conditions</a></li>
                                <li><a href="certifications.php">Certifications</a></li>
                                <li><a href="advertisements.php">Advertisements</a></li>
                                <li><a href="sitemap.php">Sitemap</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-12">
                        <div class="widget widget_services ftr-list-center connect-details">
                            <h3 class="widget-title">Online Support</h3>
                            <ul>
                                <p>Everyday is a new day for us and we work really hard to satisfy
                                    our customers everywhere.</p>
                                <li><a href="tel:+91-22 6951 6951"><i class="fa fa-phone"></i><strong> India: T-
                                        </strong> +91-22 6951 6951</a></li>
                                <li><a href="tel:+1 (732) 422-3870"><i class="fa fa-phone"></i><strong> USA: T-
                                        </strong> +1 (732) 422-3870</a></li>
                            </ul>
                            <ul class="mt-md-3">
                                <li><a href="tel:+91-22 6951 6800"><i class="fa fa-fax"></i><strong> India: F-
                                        </strong> +91-22 6951 6800</a></li>
                                <li><a href="tel:+1 (732) 422-3878"><i class="fa fa-fax"></i><strong> USA: F- </strong>
                                        +1 (732) 422-3878</a></li>
                            </ul>
                            <ul class="mt-md-3">
                                <li><a href="mailto:info@interportglobal.com"><i class="fa fa-envelope"></i><strong>
                                            India: E- </strong>info@interportglobal.com</a></li>
                                <li><a href="mailto:usa@interportglobal.com"><i class="fa fa-envelope"></i><strong>
                                            USA: E- </strong>usa@interportglobal.com</a></li>
                            </ul>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <div class="footer-bottom-info">
                    <div class="footer-copy-right">
                        <span class="copyrights-text cpt-txt">Interport Global Logistics &copy; 2023. All rights reserved.
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

</div>
<a href="javascript:void(0)" class="scroll-to-top"><i class="fas fa-angle-up" aria-hidden="true"></i></a>
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/core.min.js"></script>
<script src="js/main.js"></script>
<script>
    $(document).ready(function () {
        $(".hide").click(function () {
            $(".hide-show-block").hide();
        });
        $(".show").click(function () {
            $(".hide-show-block").show();
        });
    });

    $(document).ready(function () {
        $(".hide-one").click(function () {
            $(".hide-show-block-one").hide();
        });
        $(".show-one").click(function () {
            $(".hide-show-block-one").show();
        });
    });
</script>
</body>

</html>